import AppKit
import RecBarCore
import SwiftUI

// Colours from the design preview.
private let boxFill = Color(red: 24 / 255, green: 24 / 255, blue: 27 / 255)
private let recRed = Color(red: 1, green: 69 / 255, blue: 58 / 255)
private let savedGreen = Color(red: 48 / 255, green: 209 / 255, blue: 88 / 255)
private let warnAmber = Color(red: 1, green: 214 / 255, blue: 10 / 255)
private let restartBlue = Color(red: 10 / 255, green: 132 / 255, blue: 1)

/// The 220 × 40 pt box. Everything is clipped to the capsule, so nothing
/// (including the recording button's glow) can spill past the edge.
struct BarView: View {
    @ObservedObject var model: RecorderModel

    var body: some View {
        ZStack {
            WindowDragArea()  // empty parts of the box drag it around
            row
        }
        .frame(width: 220, height: 40)
        .background(Capsule().fill(boxFill.opacity(0.88)))
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.12), lineWidth: 0.5))
        .clipShape(Capsule())
        .environment(\.colorScheme, .dark)
    }

    @ViewBuilder
    private var row: some View {
        switch model.phase {
        case .idle, .starting:
            // Widths: toggle ≈ 138 + record 28 + settings 24 + gaps 6 + padding 12 ≈ 208 of 220 pt.
            HStack(spacing: 2) {
                ModeToggle(mode: $model.mode)
                Spacer(minLength: 0)
                RecordButton(look: model.phase == .starting ? .starting : .idle) { model.recordButtonTapped() }
                SettingsMenu(model: model)
            }
            .padding(.horizontal, 6)

        case .recording(let since):
            HStack(spacing: 4) {
                ModeChip(mode: model.mode)
                Spacer(minLength: 0)
                TimelineView(.periodic(from: since, by: 1)) { context in
                    Text(elapsedText(from: since, to: context.date))
                        .font(.system(size: 13, weight: .semibold).monospacedDigit())
                        .foregroundStyle(Color.white)
                }
                .padding(.trailing, 6)
                RecordButton(look: .recording) { model.recordButtonTapped() }
            }
            .padding(.horizontal, 6)

        case .finishing:
            HStack(spacing: 4) {
                ModeChip(mode: model.mode)
                Spacer(minLength: 0)
                Text("Saving…")
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(Color.white.opacity(0.7))
                    .padding(.trailing, 6)
                RecordButton(look: .finishing) {}
            }
            .padding(.horizontal, 6)

        case .saved(let url):
            MessageRow(icon: .saved, text: "Saved to \(model.folder.lastPathComponent)", hint: "Show", chevron: true) {
                model.savedTapped(url)
            }

        case .permissionNeeded:
            MessageRow(icon: .warning, text: "Allow screen recording", hint: nil, chevron: true) {
                model.permissionTapped()
            }

        case .restartNeeded:
            MessageRow(icon: .restart, text: "Restart to finish", hint: nil, chevron: true) {
                model.relaunch()
            }
            .help("After turning on Rec Bar in System Settings, click to restart it so macOS applies the permission.")

        case .failed(let message):
            MessageRow(icon: .warning, text: "Recording failed", hint: "OK", chevron: false) {
                model.dismissFailure()
            }
            .help(message)
        }
    }
}

/// "2:47", or "1:02:47" past an hour.
func elapsedText(from start: Date, to now: Date) -> String {
    let total = max(0, Int(now.timeIntervalSince(start)))
    let h = total / 3600, m = (total % 3600) / 60, s = total % 60
    return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%02d:%02d", m, s)
}

// MARK: - Mode toggle

struct ModeToggle: View {
    @Binding var mode: RecorderModel.Mode
    @Namespace private var pill
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 2) {
            segment(.video, icon: "display", title: "Video")
            segment(.audio, icon: "waveform", title: "Audio")
        }
        .padding(2)
        .background(Capsule().fill(Color.white.opacity(0.08)))
    }

    private func segment(_ value: RecorderModel.Mode, icon: String, title: String) -> some View {
        let selected = mode == value
        return Button {
            guard mode != value else { return }
            // The highlight pill slides (and stretches to fit) between Video and Audio.
            withAnimation(reduceMotion ? nil : Animation.spring(response: 0.32, dampingFraction: 0.78)) {
                mode = value
            }
        } label: {
            SegmentLabel(icon: icon, title: title, selected: selected, drawsPill: false)
                .background {
                    if selected {
                        Capsule()
                            .fill(Color.white.opacity(0.18))
                            .matchedGeometryEffect(id: "pill", in: pill)
                    }
                }
        }
        .buttonStyle(.plain)
        .help(value == .video ? "Screen + desktop audio → .mp4" : "Desktop audio only → .mp3")
    }
}

/// While recording, only the locked mode shows (both buttons plus the timer don't fit in 220 pt).
struct ModeChip: View {
    let mode: RecorderModel.Mode

    var body: some View {
        SegmentLabel(
            icon: mode == .video ? "display" : "waveform",
            title: mode == .video ? "Video" : "Audio",
            selected: true
        )
        .padding(2)
        .background(Capsule().fill(Color.white.opacity(0.08)))
        .opacity(0.4)
    }
}

struct SegmentLabel: View {
    let icon: String
    let title: String
    let selected: Bool
    /// The mode toggle draws its own sliding pill instead.
    var drawsPill = true

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: icon).font(.system(size: 11, weight: .semibold))
            Text(title).font(.system(size: 12, weight: .semibold))
        }
        .padding(.horizontal, 8)
        .frame(height: 24)
        .foregroundStyle(selected ? Color.white : Color.white.opacity(0.5))
        .background(Capsule().fill(selected && drawsPill ? Color.white.opacity(0.18) : Color.clear))
        .contentShape(Capsule())
        .fixedSize()
    }
}

// MARK: - Record button

struct RecordButton: View {
    enum Look { case idle, starting, recording, finishing }

    let look: Look
    let action: () -> Void
    @State private var pulse = false

    private var live: Bool { look == .recording || look == .finishing }

    var body: some View {
        Button(action: action) {
            ZStack {
                // The red glow is a fill inside the button's own circle, never outside it.
                Circle().fill(live ? recRed.opacity(0.18) : Color.clear)
                Circle().strokeBorder(live ? recRed.opacity(0.6) : Color.white.opacity(0.28), lineWidth: 2)
                Circle()
                    .fill(live ? recRed : Color(white: 0.82))
                    .frame(width: 12, height: 12)
                    .opacity(look == .recording && pulse ? 0.45 : 1)
            }
            .frame(width: 28, height: 28)
            .contentShape(Circle())
            .opacity(look == .starting ? 0.5 : 1)
        }
        .buttonStyle(.plain)
        .disabled(look == .starting || look == .finishing)
        .help(look == .recording ? "Stop recording" : "Start recording")
        .onAppear {
            guard look == .recording else { return }
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

// MARK: - Settings menu (the sliders icon)

struct SettingsMenu: View {
    @ObservedObject var model: RecorderModel

    var body: some View {
        Menu {
            Picker("Video quality", selection: $model.preset) {
                ForEach(QualityPreset.allCases) { preset in
                    Text(preset.title).tag(preset)
                }
            }
            .pickerStyle(.inline)

            Divider()
            Section("Save recordings to") {
                Text(model.folderDisplayPath)  // shown as a greyed-out line
                Button("Choose Folder…") { model.chooseFolder() }
                Button("Show in Finder") { model.openFolder() }
            }

            Divider()
            Toggle("Open at Login", isOn: Binding(
                get: { model.opensAtLogin },
                set: { model.setOpensAtLogin($0) }
            ))
            Divider()
            Button("Quit Rec Bar") { NSApp.terminate(nil) }
        } label: {
            Image(systemName: "slider.horizontal.3")
                .font(.system(size: 13, weight: .medium))
        }
        .menuStyle(.borderlessButton)
        .menuIndicator(.hidden)
        .fixedSize()
        .frame(width: 24, height: 28)
        .opacity(0.6)
        .help("Settings")
    }
}

// MARK: - Saved / Permission / Failed

struct MessageRow: View {
    enum Icon { case saved, warning, restart }

    let icon: Icon
    let text: String
    let hint: String?
    let chevron: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                iconView.font(.system(size: 15))
                Text(text)
                    .font(.system(size: 12.5, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .lineLimit(1)
                Spacer(minLength: 4)
                HStack(spacing: 2) {
                    if let hint { Text(hint) }
                    if chevron { Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold)) }
                }
                .font(.system(size: 11.5, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.5))
            }
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var iconView: some View {
        switch icon {
        case .saved:
            Image(systemName: "checkmark.circle.fill")
                .symbolRenderingMode(.palette)
                .foregroundStyle(Color.white, savedGreen)
        case .warning:
            Image(systemName: "exclamationmark.triangle.fill")
                .symbolRenderingMode(.palette)
                .foregroundStyle(Color.black, warnAmber)
        case .restart:
            Image(systemName: "arrow.clockwise.circle.fill")
                .symbolRenderingMode(.palette)
                .foregroundStyle(Color.white, restartBlue)
        }
    }
}

// MARK: - Dragging the box

/// Sits behind the controls; dragging on any empty part of the box moves it.
struct WindowDragArea: NSViewRepresentable {
    func makeNSView(context: Context) -> NSView { DragView() }
    func updateNSView(_ nsView: NSView, context: Context) {}

    final class DragView: NSView {
        override var mouseDownCanMoveWindow: Bool { true }
        override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
        override func mouseDown(with event: NSEvent) { window?.performDrag(with: event) }
    }
}
