import AppKit
import SwiftUI

@main
enum RecBarMain {
    @MainActor
    static func main() {
        let app = NSApplication.shared
        let delegate = AppDelegate()
        app.delegate = delegate
        app.setActivationPolicy(.accessory)  // no Dock icon or menu bar; the box is the whole app
        withExtendedLifetime(delegate) { app.run() }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    private let model = RecorderModel()
    private let screenshots = ScreenshotController()
    private var panel: RecBarPanel?
    private var observers: [NSObjectProtocol] = []

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Only one Rec Bar at a time: quit any other copy (e.g. an older version)
        // that's still running. They save any recording in progress as they quit.
        if let id = Bundle.main.bundleIdentifier {
            let me = NSRunningApplication.current.processIdentifier
            for other in NSRunningApplication.runningApplications(withBundleIdentifier: id)
            where other.processIdentifier != me {
                other.terminate()
            }
        }

        BackgroundCursor.enable()        // lets the crosshair show while another app is in front
        screenshots.registerShortcuts()  // ⌃⇧4 area, ⌃⇧2 screen, ⌃⇧1 scrolling (changeable)
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 1_500_000_000)
            self?.screenshots.reportShortcutClashes()
        }
        let host = FirstMouseHostingView(rootView: BarView(model: model, shots: screenshots))
        host.frame = NSRect(x: 0, y: 0, width: RecBarPanel.size.width, height: RecBarPanel.size.height)

        let panel = RecBarPanel(contentView: host)
        panel.orderFrontRegardless()
        self.panel = panel
        // The window shadow follows the capsule's shape once it has drawn.
        DispatchQueue.main.async { panel.invalidateShadow() }

        // Finish the file cleanly before the Mac sleeps.
        observers.append(NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.willSleepNotification, object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in await self?.model.stopIfRecording() }
        })

        // Keep the box on screen if displays are plugged in or rearranged.
        observers.append(NotificationCenter.default.addObserver(
            forName: NSApplication.didChangeScreenParametersNotification, object: nil, queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.panel?.keepOnScreen() }
        })
    }

    /// Quitting mid-recording finishes and saves the file first.
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard model.isRecording else { return .terminateNow }
        Task { @MainActor in
            await model.stopIfRecording()
            NSApp.reply(toApplicationShouldTerminate: true)
        }
        return .terminateLater
    }
}

/// Lets the first click on the box work even when another app is in front.
final class FirstMouseHostingView<Content: View>: NSHostingView<Content> {
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }
}

/// The floating, always-on-top box. It never takes focus from the app you're
/// using, shows on every Space and over full-screen apps, and remembers where you put it.
final class RecBarPanel: NSPanel {
    static let size = NSSize(width: 220, height: 40)
    private static let autosaveName = "RecBarPanel"

    init(contentView: NSView) {
        super.init(
            contentRect: NSRect(origin: .zero, size: Self.size),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        isFloatingPanel = true
        level = .floating
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        hidesOnDeactivate = false
        isOpaque = false
        backgroundColor = .clear
        hasShadow = true
        sharingType = .none  // extra guard; recordings also exclude Rec Bar's windows directly
        self.contentView = contentView

        if !setFrameUsingName(Self.autosaveName) {
            moveToTopCenter()
        }
        setFrameAutosaveName(Self.autosaveName)
        keepOnScreen()
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }

    /// Centred at the top of the main display, just under the menu bar (PRD default).
    func moveToTopCenter() {
        guard let screen = NSScreen.main ?? NSScreen.screens.first else { return }
        let visible = screen.visibleFrame
        setFrameOrigin(NSPoint(
            x: (visible.midX - Self.size.width / 2).rounded(),
            y: visible.maxY - Self.size.height - 8
        ))
    }

    /// If the saved spot is no longer on any display, put the box back at the top centre.
    func keepOnScreen() {
        let onSomeScreen = NSScreen.screens.contains { $0.visibleFrame.intersects(frame) }
        if !onSomeScreen { moveToTopCenter() }
    }
}
