import AppKit
import Combine
import RecBarCore
import ServiceManagement

/// Everything the box shows and does: which mode is picked, whether it's
/// recording, and the short-lived Saved / Permission / Failed states.
@MainActor
final class RecorderModel: ObservableObject {
    enum Mode: String {
        case video, audio
    }

    enum Phase: Equatable {
        case idle
        case starting
        case recording(since: Date)
        case finishing
        case saved(URL)
        case permissionNeeded
        case restartNeeded      // permission turned on; macOS applies it after a restart
        case failed(String)
    }

    @Published var mode: Mode {
        didSet { UserDefaults.standard.set(mode.rawValue, forKey: Keys.mode) }
    }
    @Published var preset: QualityPreset {
        didSet { UserDefaults.standard.set(preset.rawValue, forKey: Keys.preset) }
    }
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var opensAtLogin = false

    /// Where recordings are saved. Starts as OBS's recording folder (or Movies),
    /// changed with Choose Folder… in the settings menu, remembered between launches.
    @Published private(set) var folder: URL

    /// e.g. "~/Movies" for the settings menu.
    var folderDisplayPath: String { (folder.path as NSString).abbreviatingWithTildeInPath }

    private var recorder: Recording?
    private var revertTask: Task<Void, Never>?
    private var permissionWatch: Task<Void, Never>?

    private enum Keys {
        static let mode = "mode"
        static let preset = "preset"
        static let folder = "saveFolderPath"
        static let didSetUpLogin = "didSetUpLoginItem"
        static let wantsLogin = "wantsOpenAtLogin"
    }

    init() {
        let defaults = UserDefaults.standard
        mode = Mode(rawValue: defaults.string(forKey: Keys.mode) ?? "") ?? .video
        preset = QualityPreset(rawValue: defaults.string(forKey: Keys.preset) ?? "") ?? .standard

        let startFolder: URL
        if let saved = defaults.string(forKey: Keys.folder),
           Recordings.isUsableFolder(URL(fileURLWithPath: saved, isDirectory: true)) {
            startFolder = URL(fileURLWithPath: saved, isDirectory: true)
        } else {
            // First launch (or the saved folder is gone): use OBS's folder, else Movies.
            startFolder = Recordings.defaultFolder
            defaults.set(startFolder.path, forKey: Keys.folder)
        }
        folder = startFolder

        setUpLoginItem()
        Task { await checkPermission() }
    }

    var isRecording: Bool {
        if case .recording = phase { return true }
        return false
    }

    // MARK: Record / stop

    func recordButtonTapped() {
        switch phase {
        case .recording:
            Task { await stop() }
        case .idle, .saved, .failed:
            Task { await start() }
        case .permissionNeeded:
            permissionTapped()
        case .restartNeeded:
            relaunch()
        case .starting, .finishing:
            break
        }
    }

    func start() async {
        revertTask?.cancel()
        // No up-front permission check: macOS's quick check can say "no" even when
        // recording is allowed. Starting a capture is the real test; a refusal
        // comes back as RecBarError.permissionDenied below.

        // The chosen folder may be on a drive that's been unplugged since.
        guard Recordings.isUsableFolder(folder) else {
            show(failure: RecBarError.file(
                "Can't save to \(folderDisplayPath). Choose another folder in the settings menu."))
            return
        }

        phase = .starting
        do {
            let newRecorder: Recording
            switch mode {
            case .video: newRecorder = try await VideoRecorder.make(preset: preset, folder: folder)
            case .audio: newRecorder = try await MP3Recorder.make(folder: folder)
            }
            newRecorder.onUnexpectedStop = { [weak self] error in
                Task { @MainActor in await self?.handleUnexpectedStop(error) }
            }
            try await newRecorder.start()
            recorder = newRecorder
            phase = .recording(since: Date())
        } catch RecBarError.permissionDenied {
            showPermissionNeeded()
        } catch {
            show(failure: error)
        }
    }

    func stop() async {
        guard isRecording, let current = recorder else { return }
        recorder = nil
        phase = .finishing
        do {
            showSaved(try await current.stop())
        } catch {
            show(failure: error)
        }
    }

    func stopIfRecording() async {
        if isRecording { await stop() }
    }

    /// Capture ended by itself (display unplugged, disk full…): save what was recorded.
    private func handleUnexpectedStop(_ error: Error) async {
        guard isRecording else { return }
        await stop()
    }

    // MARK: Message states

    func savedTapped(_ url: URL) {
        NSWorkspace.shared.activateFileViewerSelecting([url])
        revertTask?.cancel()
        phase = .idle
    }

    func permissionTapped() {
        ScreenRecordingPermission.request()
        ScreenRecordingPermission.openSystemSettings()
        // macOS only applies a newly allowed permission after the app restarts,
        // so the box now offers that restart.
        phase = .restartNeeded
    }

    /// Quits and reopens Rec Bar (used after allowing screen recording).
    func relaunch() {
        let reopen = Process()
        reopen.executableURL = URL(fileURLWithPath: "/bin/sh")
        reopen.arguments = ["-c", "sleep 1; /usr/bin/open \"$0\"", Bundle.main.bundlePath]
        try? reopen.run()
        NSApp.terminate(nil)
    }

    /// The reliable check: ask ScreenCaptureKit for the screen. The first time,
    /// this also shows macOS's "Rec Bar would like to record…" prompt.
    private func checkPermission() async {
        if await ScreenRecordingPermission.canCapture() {
            if phase == .permissionNeeded || phase == .restartNeeded { phase = .idle }
        } else if phase == .idle {
            showPermissionNeeded()
        }
    }

    func dismissFailure() {
        revertTask?.cancel()
        phase = .idle
    }

    func openFolder() {
        NSWorkspace.shared.open(folder)
    }

    /// Milestone 4: pick where recordings are saved.
    func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.directoryURL = folder
        panel.prompt = "Save Here"
        panel.message = "Choose where Rec Bar saves your recordings."

        // Rec Bar never takes focus on its own, so bring it forward for the dialog.
        NSApp.activate(ignoringOtherApps: true)
        guard panel.runModal() == .OK, let url = panel.url else { return }

        guard Recordings.isUsableFolder(url) else {
            show(failure: RecBarError.file("Rec Bar can't save to \(url.lastPathComponent). Pick a different folder."))
            return
        }
        folder = url
        UserDefaults.standard.set(url.path, forKey: Keys.folder)
    }

    private func showSaved(_ url: URL) {
        phase = .saved(url)
        revert(after: 2.5) { if case .saved = $0 { return true } else { return false } }
    }

    private func show(failure error: Error) {
        phase = .failed(error.localizedDescription)
        revert(after: 6) { if case .failed = $0 { return true } else { return false } }
    }

    /// Goes back to Idle after `seconds`, if still in the state `matches` accepts.
    private func revert(after seconds: Double, onlyIf matches: @escaping (Phase) -> Bool) {
        revertTask?.cancel()
        revertTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            guard !Task.isCancelled, let self, matches(self.phase) else { return }
            self.phase = .idle
        }
    }

    private func showPermissionNeeded() {
        phase = .permissionNeeded
        permissionWatch?.cancel()
        permissionWatch = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 2_000_000_000)
                guard let self else { return }
                if ScreenRecordingPermission.isGranted {
                    if self.phase == .permissionNeeded || self.phase == .restartNeeded { self.phase = .idle }
                    return
                }
            }
        }
    }

    // MARK: Open at login (PRD default: on)

    func setOpensAtLogin(_ on: Bool) {
        UserDefaults.standard.set(on, forKey: Keys.wantsLogin)
        do {
            if on {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
        } catch {
            NSLog("Rec Bar: couldn't change Open at Login: \(error.localizedDescription)")
        }
        opensAtLogin = SMAppService.mainApp.status == .enabled
    }

    /// On by default (PRD). Checked every launch so the login item always points
    /// at this copy of Rec Bar, not an older one that's been replaced.
    private func setUpLoginItem() {
        let defaults = UserDefaults.standard
        // Only from an installed copy, so a test build doesn't register itself.
        guard Bundle.main.bundlePath.hasSuffix(".app") else {
            opensAtLogin = SMAppService.mainApp.status == .enabled
            return
        }
        if defaults.object(forKey: Keys.wantsLogin) == nil {
            // First launch, or upgrading from a version that didn't store this.
            let upgrading = defaults.bool(forKey: Keys.didSetUpLogin)
            defaults.set(upgrading ? SMAppService.mainApp.status == .enabled : true, forKey: Keys.wantsLogin)
            defaults.set(true, forKey: Keys.didSetUpLogin)
        }
        if defaults.bool(forKey: Keys.wantsLogin), SMAppService.mainApp.status != .enabled {
            try? SMAppService.mainApp.register()
        }
        opensAtLogin = SMAppService.mainApp.status == .enabled
    }
}
