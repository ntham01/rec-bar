import AppKit
import RecBarCore
import SwiftUI

/// One screenshot's preview popup.
@MainActor
final class PreviewItem: ObservableObject, Identifiable {
    let id = UUID()
    @Published var shot: Screenshot {
        didSet { reader = nil }
    }
    @Published var toast: String?
    @Published var hovering = false
    /// Eyedropper on: hovering the picture shows a magnifier, a click copies the color.
    @Published var picking = false
    var editing = false
    private var toastTask: Task<Void, Never>?
    private var reader: PixelReader?

    /// "#RRGGBB" at a pixel of the screenshot (top-left origin).
    func hex(atPixel p: CGPoint) -> String? {
        if reader == nil { reader = PixelReader(shot.image) }
        return reader?.hex(x: Int(p.x), y: Int(p.y))
    }

    init(shot: Screenshot) {
        self.shot = shot
    }

    func show(toast text: String) {
        toast = text
        toastTask?.cancel()
        toastTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            guard !Task.isCancelled else { return }
            self?.toast = nil
        }
    }
}

/// Opens each preview right where the pointer is when the screenshot finishes,
/// and hides it after a while unless the pointer is over it (or it's being edited).
@MainActor
final class PreviewManager {
    static let width: CGFloat = 300
    static let imageWidth: CGFloat = 276
    private static let autoHideSeconds: UInt64 = 10

    private final class Entry {
        let item: PreviewItem
        let panel: NSPanel
        let screen: NSScreen
        var hideTask: Task<Void, Never>?
        init(item: PreviewItem, panel: NSPanel, screen: NSScreen) {
            self.item = item
            self.panel = panel
            self.screen = screen
        }
    }

    private var entries: [Entry] = []
    private lazy var loupe = ColorLoupePanel()
    weak var controller: ScreenshotController?

    /// `point` is where the pointer is (AppKit screen coordinates).
    func show(_ shot: Screenshot, at point: NSPoint) {
        let screen = NSScreen.screens.first { NSMouseInRect(point, $0.frame, false) } ?? NSScreen.screens[0]
        let item = PreviewItem(shot: shot)
        let panel = PreviewPanel()
        let view = PreviewView(item: item, actions: PreviewActions(
            close: { [weak self, weak item] in if let item { self?.close(item) } },
            edit: { [weak self, weak item] in if let item { self?.controller?.openEditor(for: item, tool: .none) } },
            copy: { [weak item] in
                guard let item else { return }
                ImageTools.copyToClipboard(item.shot)
                item.show(toast: "Copied")
            },
            save: { [weak self, weak item] in if let item { self?.controller?.save(item) } },
            pickColor: { [weak self, weak item] in
                guard let item else { return }
                item.picking.toggle()
                if item.picking {
                    item.show(toast: "Hover the picture · click to copy a color")
                } else {
                    self?.loupe.hide()
                }
            },
            colorHover: { [weak self, weak item] pixel in
                guard let self, let item else { return }
                if let pixel, item.picking {
                    self.loupe.show(image: item.shot.image, pixel: pixel, hex: item.hex(atPixel: pixel), at: NSEvent.mouseLocation)
                } else {
                    self.loupe.hide()
                }
            },
            colorPick: { [weak self, weak item] pixel in
                guard let item, let hex = item.hex(atPixel: pixel) else { return }
                ImageTools.copyToClipboard(text: hex)
                item.picking = false
                self?.loupe.hide()
                item.show(toast: "Copied \(hex)")
            },
            copyText: { [weak self, weak item] in if let item { self?.controller?.copyText(from: item) } },
            hoverChanged: { [weak self, weak item] inside in
                guard let item else { return }
                item.hovering = inside
                if !inside { self?.scheduleHide(item) }
            }
        ))
        let host = FirstMouseHostingView(rootView: view)
        panel.contentView = host
        let entry = Entry(item: item, panel: panel, screen: screen)
        entries.append(entry)

        // Keep at most four open; the oldest goes first.
        if entries.count > 4, let oldest = entries.first(where: { !$0.item.editing }) {
            close(oldest.item)
        }
        panel.setFrame(Self.frame(size: Self.panelSize(for: shot), near: point, on: screen), display: true)
        panel.orderFrontRegardless()
        scheduleHide(item)
    }

    /// Call after a screenshot changes (e.g. edited): the popup keeps its top-left
    /// corner (wherever it was dragged to) and takes the new shape.
    func refresh(_ item: PreviewItem) {
        guard let entry = entries.first(where: { $0.item === item }) else { return }
        let size = Self.panelSize(for: item.shot)
        let old = entry.panel.frame
        var frame = NSRect(x: old.minX, y: old.maxY - size.height, width: size.width, height: size.height)
        frame = Self.clamp(frame, to: entry.panel.screen?.visibleFrame ?? entry.screen.visibleFrame)
        entry.panel.setFrame(frame, display: true, animate: true)
        scheduleHide(item)
    }

    func close(_ item: PreviewItem) {
        guard let index = entries.firstIndex(where: { $0.item === item }) else { return }
        let entry = entries.remove(at: index)
        entry.hideTask?.cancel()
        entry.panel.orderOut(nil)
        if entry.item.picking { loupe.hide() }
    }

    func scheduleHide(_ item: PreviewItem) {
        guard let entry = entries.first(where: { $0.item === item }) else { return }
        entry.hideTask?.cancel()
        entry.hideTask = Task { [weak self, weak item] in
            try? await Task.sleep(nanoseconds: Self.autoHideSeconds * 1_000_000_000)
            guard !Task.isCancelled, let self, let item else { return }
            if item.editing { return }
            if item.hovering || item.picking {
                self.scheduleHide(item)
                return
            }
            self.close(item)
        }
    }

    static func panelSize(for shot: Screenshot) -> NSSize {
        NSSize(width: width, height: 26 + imageBoxHeight(for: shot) + 46)
    }

    static func imageBoxHeight(for shot: Screenshot) -> CGFloat {
        let size = shot.pixelSize
        guard size.width > 0 else { return 120 }
        return min(200, max(90, imageWidth * size.height / size.width))
    }

    /// Just below and to the right of the pointer, so it doesn't sit under it;
    /// flipped left / above when there's no room, and kept on screen.
    private static func frame(size: NSSize, near point: NSPoint, on screen: NSScreen) -> NSRect {
        let visible = screen.visibleFrame
        let gap: CGFloat = 14
        var x = point.x + gap
        var y = point.y - gap - size.height
        if x + size.width > visible.maxX - 8 { x = point.x - gap - size.width }
        if y < visible.minY + 8 { y = point.y + gap }
        return clamp(NSRect(x: x, y: y, width: size.width, height: size.height), to: visible)
    }

    private static func clamp(_ frame: NSRect, to visible: NSRect) -> NSRect {
        var f = frame
        f.origin.x = min(max(f.minX, visible.minX + 8), visible.maxX - f.width - 8)
        f.origin.y = min(max(f.minY, visible.minY + 8), visible.maxY - f.height - 8)
        return f
    }
}

final class PreviewPanel: NSPanel {
    init() {
        super.init(contentRect: NSRect(x: 0, y: 0, width: PreviewManager.width, height: 240),
                   styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        level = .floating
        isOpaque = false
        backgroundColor = .clear
        hasShadow = true
        isReleasedWhenClosed = false
        hidesOnDeactivate = false
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        animationBehavior = .none  // appears instantly, no pop-in
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

struct PreviewActions {
    let close: () -> Void
    let edit: () -> Void
    let copy: () -> Void
    let save: () -> Void
    let pickColor: () -> Void
    /// Pixel under the pointer while picking (nil when it leaves the picture).
    let colorHover: (CGPoint?) -> Void
    let colorPick: (CGPoint) -> Void
    let copyText: () -> Void
    let hoverChanged: (Bool) -> Void
}

/// The popup: close button and drag handle on top, the screenshot, then the tools.
struct PreviewView: View {
    @ObservedObject var item: PreviewItem
    let actions: PreviewActions

    private let panelFill = Color(red: 0.165, green: 0.165, blue: 0.18)
    private let imageFill = Color(red: 0.09, green: 0.07, blue: 0.1)

    var body: some View {
        VStack(spacing: 0) {
            topBar
            imageBox
            toolRow
        }
        .frame(width: PreviewManager.width)
        .background {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(panelFill)
                WindowDragArea()  // drag the popup by its background
            }
        }
        .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(Color.white.opacity(0.1), lineWidth: 0.5))
        .clipShape(RoundedRectangle(cornerRadius: 14))
        .onHover { actions.hoverChanged($0) }
        .environment(\.colorScheme, .dark)
    }

    private var topBar: some View {
        ZStack {
            HStack(spacing: 5) {
                ForEach(0..<4, id: \.self) { _ in
                    Circle().fill(Color.white.opacity(0.35)).frame(width: 3, height: 3)
                }
            }
            HStack {
                Button(action: actions.close) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(Color.white.opacity(0.8))
                        .frame(width: 22, height: 22)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .help("Close")
                Spacer()
            }
            .padding(.horizontal, 8)
        }
        .frame(height: 26)
    }

    private var imageBox: some View {
        ZStack(alignment: .bottom) {
            RoundedRectangle(cornerRadius: 8).fill(imageFill)
            Image(nsImage: item.shot.nsImage)
                .resizable()
                .interpolation(.high)
                .aspectRatio(contentMode: .fit)
                .overlay {
                    if item.picking {
                        GeometryReader { geo in
                            Color.clear
                                .contentShape(Rectangle())
                                .onContinuousHover(coordinateSpace: .local) { phase in
                                    switch phase {
                                    case .active(let location): actions.colorHover(pixel(location, in: geo.size))
                                    case .ended: actions.colorHover(nil)
                                    }
                                }
                                .onTapGesture(coordinateSpace: .local) { location in
                                    actions.colorPick(pixel(location, in: geo.size))
                                }
                        }
                    }
                }
                .padding(4)
                .onDrag {
                    // Drag the screenshot straight into another app.
                    guard let url = ImageTools.temporaryFile(item.shot),
                          let provider = NSItemProvider(contentsOf: url) else { return NSItemProvider() }
                    return provider
                }
                .help("Drag into another app")
            if let toast = item.toast {
                Text(toast)
                    .font(.system(size: 11.5, weight: .semibold))
                    .foregroundStyle(Color.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Capsule().fill(Color.black.opacity(0.75)))
                    .padding(.bottom, 8)
                    .transition(.opacity)
            }
        }
        .frame(width: PreviewManager.imageWidth, height: PreviewManager.imageBoxHeight(for: item.shot))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .animation(.easeOut(duration: 0.15), value: item.toast)
    }

    /// A point on the fitted picture → that pixel of the full-size screenshot.
    private func pixel(_ location: CGPoint, in size: CGSize) -> CGPoint {
        let w = CGFloat(item.shot.image.width), h = CGFloat(item.shot.image.height)
        guard size.width > 0, size.height > 0 else { return .zero }
        return CGPoint(x: min(max(location.x / size.width * w, 0), w - 1),
                       y: min(max(location.y / size.height * h, 0), h - 1))
    }

    private var toolRow: some View {
        HStack(spacing: 0) {
            tool("pencil", "Edit — crop and rotate", actions.edit)
            tool("doc.on.doc", "Copy", actions.copy)
            tool("square.and.arrow.down", "Save to your screenshots folder", actions.save)
            tool("eyedropper", item.picking ? "Stop picking" : "Pick a color", actions.pickColor, on: item.picking)
            tool("text.viewfinder", "Copy the text in it", actions.copyText)
        }
        .padding(.horizontal, 6)
        .frame(height: 46)
    }

    private func tool(_ symbol: String, _ help: String, _ action: @escaping () -> Void, on: Bool = false) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .regular))
                .foregroundStyle(Color.white.opacity(on ? 1 : 0.85))
                .frame(width: 34, height: 30)
                .background(RoundedRectangle(cornerRadius: 7).fill(on ? Color.white.opacity(0.18) : Color.clear))
                .frame(maxWidth: .infinity, minHeight: 32)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .help(help)
    }
}

/// The magnifier that follows the pointer while picking a color in a preview:
/// 11 × 11 real pixels, the centre one outlined, and its hex code underneath.
@MainActor
final class ColorLoupePanel {
    private let panel: NSPanel
    private let view = ColorLoupeView(frame: NSRect(x: 0, y: 0, width: 140, height: 160))

    init() {
        panel = NSPanel(contentRect: NSRect(x: 0, y: 0, width: 140, height: 160),
                        styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.level = .popUpMenu
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.ignoresMouseEvents = true
        panel.isReleasedWhenClosed = false
        panel.animationBehavior = .none
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .ignoresCycle]
        panel.contentView = view
    }

    func show(image: CGImage, pixel: CGPoint, hex: String?, at mouse: NSPoint) {
        view.image = image
        view.pixel = pixel
        view.hex = hex
        view.needsDisplay = true

        let size = view.frame.size
        var origin = NSPoint(x: mouse.x + 18, y: mouse.y - 18 - size.height)
        if let visible = (NSScreen.screens.first { NSMouseInRect(mouse, $0.frame, false) })?.visibleFrame {
            if origin.x + size.width > visible.maxX { origin.x = mouse.x - 18 - size.width }
            if origin.y < visible.minY { origin.y = mouse.y + 18 }
        }
        panel.setFrameOrigin(origin)
        panel.orderFrontRegardless()
    }

    func hide() {
        panel.orderOut(nil)
    }
}

final class ColorLoupeView: NSView {
    var image: CGImage?
    var pixel: CGPoint = .zero
    var hex: String?

    override var isFlipped: Bool { true }

    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current?.cgContext, let image else { return }
        let circle = CGRect(x: 10, y: 4, width: 120, height: 120)
        Loupe.draw(image: image, centerX: Int(pixel.x), centerY: Int(pixel.y), span: 11, in: circle, context: context)
        if let hex {
            let size = Pill.size(hex)
            Pill.draw(hex, at: CGPoint(x: (bounds.width - size.width) / 2, y: circle.maxY + 8))
        }
    }
}
