import AppKit
import ApplicationServices
import RecBarCore
import Security
import SwiftUI

/// Scrolling capture sends scroll events, which macOS only allows for apps
/// switched on in System Settings → Privacy & Security → Accessibility.
///
/// Why "switched on but not recognised" happens, and what's done about it:
/// • Behind that one list macOS keeps two separate permissions, Accessibility
///   and PostEvent, and its quick PostEvent check only updates when the app
///   restarts. Rec Bar now checks three ways, one of which (a test event tap)
///   notices the switch live, and watches it while the help window is open.
/// • A switch can belong to an older copy of Rec Bar (a different signature):
///   it shows as on but doesn't count. "Fix Old Entry" clears both permissions
///   and adds Rec Bar again, so the switch you turn on is the current copy's.
@MainActor
enum AutoScrollPermission {
    /// Whether Rec Bar may send scroll events right now.
    static var isGranted: Bool {
        AXIsProcessTrusted() || CGPreflightPostEventAccess() || eventTapAllowed()
    }

    /// macOS lets an app create an event tap that can change events only once
    /// it may control the computer. Unlike CGPreflightPostEventAccess this
    /// notices the switch without a restart. The tap is removed at once.
    static func eventTapAllowed() -> Bool {
        let mask = CGEventMask(1) << CGEventMask(CGEventType.scrollWheel.rawValue)
        guard let tap = CGEvent.tapCreate(
            tap: .cgSessionEventTap,
            place: .tailAppendEventTap,
            options: .defaultTap,
            eventsOfInterest: mask,
            callback: { _, _, event, _ in Unmanaged.passUnretained(event) },
            userInfo: nil
        ) else { return false }
        CGEvent.tapEnable(tap: tap, enable: false)
        CFMachPortInvalidate(tap)
        return true
    }

    // MARK: Help window

    private static var helpWindow: AutoScrollHelpWindow?

    /// The help window with a live status dot and fix-it buttons.
    /// `shortcut` is e.g. "⌃⇧1"; `tryAnyway` starts a scrolling capture without the check.
    static func showHelp(shortcut: String, tryAnyway: @escaping () -> Void) {
        if let helpWindow {
            helpWindow.show()
            return
        }
        let window = AutoScrollHelpWindow(shortcut: shortcut, tryAnyway: tryAnyway)
        window.onClose = {
            Task { @MainActor in helpWindow = nil }
        }
        helpWindow = window
        window.show()
    }

    // MARK: Steps

    /// Puts Rec Bar in the Accessibility list (macOS shows its own prompt the first time).
    static func addToList() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
    }

    static func openSettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
    }

    /// Removes Rec Bar's entries (including stale ones from older copies) for
    /// both permissions. Returns false if macOS refused.
    @discardableResult
    static func clearEntries() -> Bool {
        guard let id = Bundle.main.bundleIdentifier else { return false }
        var accessibilityCleared = false
        for service in ["Accessibility", "PostEvent"] {
            let tccutil = Process()
            tccutil.executableURL = URL(fileURLWithPath: "/usr/bin/tccutil")
            tccutil.arguments = ["reset", service, id]
            tccutil.standardOutput = FileHandle.nullDevice
            tccutil.standardError = FileHandle.nullDevice
            do {
                try tccutil.run()
                tccutil.waitUntilExit()
                if service == "Accessibility" { accessibilityCleared = tccutil.terminationStatus == 0 }
            } catch {
                continue
            }
        }
        return accessibilityCleared
    }

    /// Everything needed to tell why the switch isn't recognised, as text to paste into a chat.
    static func diagnostics() -> String {
        let bundle = Bundle.main
        let version = bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "?"
        let signing = SigningInfo.current()
        let copies = NSWorkspace.shared
            .urlsForApplications(withBundleIdentifier: bundle.bundleIdentifier ?? "")
            .map(\.path)
        let record = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support/Rec Bar/installer-signer.txt")
        let recordedSigner = (try? String(contentsOf: record, encoding: .utf8))?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? "none"

        let signLog = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support/Rec Bar/signing-log.txt")
        let signingNotes = (try? String(contentsOf: signLog, encoding: .utf8))?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\n", with: "\n  ") ?? "none"

        func yesNo(_ value: Bool) -> String { value ? "yes" : "no" }
        return """
        Rec Bar \(version) diagnostics
        App: \(bundle.bundlePath)
        macOS: \(ProcessInfo.processInfo.operatingSystemVersionString)
        Signed with: \(signing.summary)
        Requirement: \(signing.requirement)
        Installer signer record: \(recordedSigner)
        Accessibility (AXIsProcessTrusted): \(yesNo(AXIsProcessTrusted()))
        Post events (preflight): \(yesNo(CGPreflightPostEventAccess()))
        Event tap test: \(yesNo(eventTapAllowed()))
        Screen recording: \(yesNo(CGPreflightScreenCaptureAccess()))
        Copies of Rec Bar macOS knows about: \(copies.isEmpty ? "none" : copies.joined(separator: ", "))
        Last scrolling capture:
          \(ScrollLog.text)
        Installer signing notes:
          \(signingNotes)
        """
    }
}

/// Quits Rec Bar and opens it again a second later (any recording is saved first).
@MainActor
enum AppRelaunch {
    static func now() {
        let reopen = Process()
        reopen.executableURL = URL(fileURLWithPath: "/bin/sh")
        reopen.arguments = ["-c", "sleep 1; /usr/bin/open \"$0\"", Bundle.main.bundlePath]
        try? reopen.run()
        NSApp.terminate(nil)
    }
}

// MARK: - Signature

/// What Rec Bar is signed with. macOS ties permission switches to this, so
/// a signature that changes with every build (ad-hoc) loses them on updates.
struct SigningInfo {
    let summary: String
    let isStable: Bool
    let requirement: String

    static func current() -> SigningInfo {
        var code: SecCode?
        var staticCode: SecStaticCode?
        guard SecCodeCopySelf([], &code) == errSecSuccess, let code,
              SecCodeCopyStaticCode(code, [], &staticCode) == errSecSuccess, let staticCode
        else { return SigningInfo(summary: "unknown", isStable: false, requirement: "?") }

        var requirementText = "?"
        var requirement: SecRequirement?
        if SecCodeCopyDesignatedRequirement(staticCode, [], &requirement) == errSecSuccess, let requirement {
            var text: CFString?
            if SecRequirementCopyString(requirement, [], &text) == errSecSuccess, let text {
                requirementText = text as String
            }
        }

        var info: CFDictionary?
        guard SecCodeCopySigningInformation(staticCode, SecCSFlags(rawValue: UInt32(kSecCSSigningInformation)), &info)
                == errSecSuccess,
              let dictionary = info as? [String: Any]
        else { return SigningInfo(summary: "unknown", isStable: false, requirement: requirementText) }

        if let certificates = dictionary[kSecCodeInfoCertificates as String] as? [SecCertificate],
           let leaf = certificates.first {
            var name: CFString?
            SecCertificateCopyCommonName(leaf, &name)
            return SigningInfo(summary: (name as String?) ?? "a certificate", isStable: true, requirement: requirementText)
        }
        let flags = (dictionary[kSecCodeInfoFlags as String] as? NSNumber)?.uint32Value ?? 0
        let adHoc = flags & SecCodeSignatureFlags.adhoc.rawValue != 0
        return SigningInfo(summary: adHoc ? "ad-hoc" : "nothing", isStable: false, requirement: requirementText)
    }
}

// MARK: - Help window

@MainActor
final class AutoScrollHelpModel: ObservableObject {
    @Published private(set) var granted: Bool
    @Published var note: String?
    let shortcut: String
    let signing = SigningInfo.current()
    var onGranted: (() -> Void)?
    private var watch: Task<Void, Never>?

    init(shortcut: String) {
        self.shortcut = shortcut
        granted = AutoScrollPermission.isGranted
    }

    /// Checks once a second, so the dot turns green as soon as the switch counts.
    func startWatching() {
        watch?.cancel()
        watch = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                guard let self else { return }
                let now = AutoScrollPermission.isGranted
                if now != self.granted {
                    self.granted = now
                    if now { self.onGranted?() }
                }
            }
        }
    }

    func stopWatching() {
        watch?.cancel()
        watch = nil
    }

    func openSettings() {
        AutoScrollPermission.addToList()
        AutoScrollPermission.openSettings()
        note = nil
    }

    func fixOldEntry() {
        let cleared = AutoScrollPermission.clearEntries()
        AutoScrollPermission.addToList()
        AutoScrollPermission.openSettings()
        note = cleared
            ? "Old entry cleared. Close and reopen System Settings if Rec Bar still shows as on, then switch it on."
            : "macOS wouldn't clear it from here. In the list, select Rec Bar, click − below the list, then click Fix Old Entry again."
    }

    func copyDetails() {
        ImageTools.copyToClipboard(text: AutoScrollPermission.diagnostics())
        note = "Details copied. Paste them into the chat with Claude."
    }
}

@MainActor
final class AutoScrollHelpWindow: NSObject, NSWindowDelegate {
    private let window: NSWindow
    private let model: AutoScrollHelpModel
    var onClose: (() -> Void)?

    init(shortcut: String, tryAnyway: @escaping () -> Void) {
        model = AutoScrollHelpModel(shortcut: shortcut)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 460, height: 420),
                          styleMask: [.titled, .closable], backing: .buffered, defer: false)
        super.init()
        window.title = "Auto-Scroll"
        window.isReleasedWhenClosed = false
        window.level = .floating   // stays visible next to System Settings
        window.delegate = self

        let host = NSHostingView(rootView: AutoScrollHelpView(
            model: model,
            close: { [weak self] in self?.window.close() },
            tryAnyway: { [weak self] in
                self?.window.close()
                tryAnyway()
            }
        ))
        window.contentView = host
        window.setContentSize(host.fittingSize)

        // Top right, so it doesn't sit on top of System Settings' list.
        if let visible = (NSScreen.main ?? NSScreen.screens.first)?.visibleFrame {
            window.setFrameTopLeftPoint(NSPoint(x: visible.maxX - window.frame.width - 24, y: visible.maxY - 24))
        } else {
            window.center()
        }

        model.onGranted = { [weak self] in
            Notice.show("Auto-scroll is on. Press \(shortcut) to take a scrolling capture.", seconds: 6)
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                self?.window.close()
            }
        }
    }

    func show() {
        NSApp.activate(ignoringOtherApps: true)
        window.makeKeyAndOrderFront(nil)
        model.startWatching()
    }

    func windowWillClose(_ notification: Notification) {
        model.stopWatching()
        onClose?()
    }
}

private struct AutoScrollHelpView: View {
    @ObservedObject var model: AutoScrollHelpModel
    let close: () -> Void
    let tryAnyway: () -> Void

    private var statusColor: Color { model.granted ? .green : .orange }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                Image(nsImage: NSApp.applicationIconImage)
                    .resizable()
                    .frame(width: 44, height: 44)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Let Rec Bar scroll for you")
                        .font(.system(size: 15, weight: .semibold))
                    Text("Scrolling capture scrolls the page by itself, like Shottr. macOS only allows that for apps switched on in Privacy & Security → Accessibility.")
                        .font(.system(size: 12))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            HStack(spacing: 8) {
                Circle().fill(statusColor).frame(width: 9, height: 9)
                Text(model.granted
                     ? "Allowed. Press \(model.shortcut) to take a scrolling capture."
                     : "Waiting for the Accessibility switch…")
                    .font(.system(size: 12.5, weight: .medium))
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(RoundedRectangle(cornerRadius: 8).fill(statusColor.opacity(0.13)))

            VStack(alignment: .leading, spacing: 12) {
                step(1, "Open Accessibility in System Settings.", button: "Open Settings") { model.openSettings() }
                step(2, "Switch on Rec Bar. The dot above turns green by itself.")
                step(3, "Switched on but still orange? That switch belongs to an older copy. Clear it, then switch Rec Bar on again.",
                     button: "Fix Old Entry") { model.fixOldEntry() }
                step(4, "Still orange after that? Restart Rec Bar.", button: "Restart") { AppRelaunch.now() }
            }

            if let note = model.note {
                Text(note)
                    .font(.system(size: 11.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Image(systemName: model.signing.isStable ? "checkmark.seal" : "exclamationmark.triangle.fill")
                    .foregroundStyle(model.signing.isStable ? Color.secondary : Color.orange)
                Text(model.signing.isStable
                     ? "Signed with \(model.signing.summary), so the switch carries over to updates."
                     : "Signed with \(model.signing.summary): macOS forgets the switch after every update. Click Copy Details and paste them to Claude.")
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Divider()

            HStack {
                Button("Copy Details") { model.copyDetails() }
                Spacer()
                Button("Try Anyway", action: tryAnyway)
                Button(model.granted ? "Done" : "Close", action: close)
                    .keyboardShortcut(.defaultAction)
            }
        }
        .padding(20)
        .frame(width: 460)
    }

    private func step(_ number: Int, _ text: String, button: String? = nil,
                      action: @escaping () -> Void = {}) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text("\(number)")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: 18, height: 18)
                .background(Circle().fill(Color.secondary.opacity(0.55)))
            Text(text)
                .font(.system(size: 12.5))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 8)
            if let button {
                Button(button, action: action)
                    .controlSize(.small)
            }
        }
    }
}
