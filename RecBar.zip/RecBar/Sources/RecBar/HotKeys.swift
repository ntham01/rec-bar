import Carbon.HIToolbox
import Foundation

/// System-wide keyboard shortcuts (Carbon hot keys). These work whichever app
/// is in front and need no extra permission.
final class HotKeys {
    static let shared = HotKeys()

    struct Shortcut: Hashable {
        let keyCode: UInt32
        let modifiers: UInt32

        static let controlShift = UInt32(controlKey | shiftKey)
        static let area = Shortcut(keyCode: UInt32(kVK_ANSI_4), modifiers: controlShift)
        static let screen = Shortcut(keyCode: UInt32(kVK_ANSI_2), modifiers: controlShift)
        static let scrolling = Shortcut(keyCode: UInt32(kVK_ANSI_1), modifiers: controlShift)
        static let escape = Shortcut(keyCode: UInt32(kVK_Escape), modifiers: 0)
        static let returnKey = Shortcut(keyCode: UInt32(kVK_Return), modifiers: 0)
    }

    private var actions: [UInt32: () -> Void] = [:]
    private var refs: [UInt32: EventHotKeyRef] = [:]
    private var nextID: UInt32 = 1
    private var handlerInstalled = false

    private init() {}

    /// Registers a shortcut. Returns an id for `unregister`, or nil if it
    /// couldn't be registered. `exclusive` makes it fail when another app (say,
    /// Shottr) already owns the same keys, instead of the key press silently
    /// going to that app.
    @discardableResult
    func register(_ shortcut: Shortcut, exclusive: Bool = true, action: @escaping () -> Void) -> UInt32? {
        installHandlerIfNeeded()
        let id = nextID
        nextID += 1
        var ref: EventHotKeyRef?
        let hotKeyID = EventHotKeyID(signature: OSType(0x5242_4152), id: id)  // 'RBAR'
        let options = exclusive ? OptionBits(kEventHotKeyExclusive) : OptionBits(kEventHotKeyNoOptions)
        let status = RegisterEventHotKey(
            shortcut.keyCode, shortcut.modifiers, hotKeyID, GetApplicationEventTarget(), options, &ref
        )
        guard status == noErr, let ref else { return nil }
        refs[id] = ref
        actions[id] = action
        return id
    }

    func unregister(_ id: UInt32?) {
        guard let id, let ref = refs.removeValue(forKey: id) else { return }
        UnregisterEventHotKey(ref)
        actions[id] = nil
    }

    fileprivate func fire(_ id: UInt32) {
        actions[id]?()
    }

    private func installHandlerIfNeeded() {
        guard !handlerInstalled else { return }
        handlerInstalled = true
        var spec = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(GetApplicationEventTarget(), { (_, event, _) -> OSStatus in
            var hotKeyID = EventHotKeyID()
            let status = GetEventParameter(
                event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID),
                nil, MemoryLayout<EventHotKeyID>.size, nil, &hotKeyID
            )
            guard status == noErr else { return status }
            let id = hotKeyID.id
            DispatchQueue.main.async { HotKeys.shared.fire(id) }
            return noErr
        }, 1, &spec, nil, nil)
    }
}
