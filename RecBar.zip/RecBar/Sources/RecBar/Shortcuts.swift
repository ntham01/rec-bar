import AppKit
import Carbon.HIToolbox
import SwiftUI

/// The screenshot actions that have a keyboard shortcut.
enum ShotAction: String, CaseIterable, Identifiable {
    case area, screen, scrolling

    var id: String { rawValue }

    var title: String {
        switch self {
        case .area: return "Capture Area"
        case .screen: return "Capture Screen"
        case .scrolling: return "Scrolling Capture"
        }
    }

    var defaultCombo: KeyCombo {
        let controlShift = UInt32(controlKey | shiftKey)
        switch self {
        case .area: return KeyCombo(keyCode: UInt32(kVK_ANSI_4), modifiers: controlShift, keyName: "4")
        case .screen: return KeyCombo(keyCode: UInt32(kVK_ANSI_2), modifiers: controlShift, keyName: "2")
        case .scrolling: return KeyCombo(keyCode: UInt32(kVK_ANSI_1), modifiers: controlShift, keyName: "1")
        }
    }
}

/// A key plus modifiers, stored as Carbon codes so it can be registered as a
/// system-wide hot key. `keyName` is what's shown, e.g. "4" or "F5".
struct KeyCombo: Codable, Equatable {
    var keyCode: UInt32
    var modifiers: UInt32
    var keyName: String

    var shortcut: HotKeys.Shortcut { HotKeys.Shortcut(keyCode: keyCode, modifiers: modifiers) }

    /// e.g. "⌃⇧4", in Apple's modifier order.
    var display: String {
        var s = ""
        if modifiers & UInt32(controlKey) != 0 { s += "⌃" }
        if modifiers & UInt32(optionKey) != 0 { s += "⌥" }
        if modifiers & UInt32(shiftKey) != 0 { s += "⇧" }
        if modifiers & UInt32(cmdKey) != 0 { s += "⌘" }
        return s + keyName
    }

    private static let functionKeys: [Int: String] = [
        kVK_F1: "F1", kVK_F2: "F2", kVK_F3: "F3", kVK_F4: "F4", kVK_F5: "F5", kVK_F6: "F6",
        kVK_F7: "F7", kVK_F8: "F8", kVK_F9: "F9", kVK_F10: "F10", kVK_F11: "F11", kVK_F12: "F12",
        kVK_F13: "F13", kVK_F14: "F14", kVK_F15: "F15", kVK_F16: "F16", kVK_F17: "F17",
        kVK_F18: "F18", kVK_F19: "F19", kVK_F20: "F20",
    ]

    private static let specialKeys: [Int: String] = [
        kVK_Space: "Space", kVK_Return: "↩", kVK_Tab: "⇥", kVK_Delete: "⌫", kVK_ForwardDelete: "⌦",
        kVK_LeftArrow: "←", kVK_RightArrow: "→", kVK_UpArrow: "↑", kVK_DownArrow: "↓",
        kVK_Home: "↖", kVK_End: "↘", kVK_PageUp: "⇞", kVK_PageDown: "⇟",
    ]

    enum RecordResult {
        case combo(KeyCombo)
        case needsModifier
        case ignored
    }

    /// Turns a key press into a combo. Plain keys need ⌘, ⌃ or ⌥ (Shift alone
    /// isn't enough), so typing normally never triggers a screenshot; F-keys can stand alone.
    static func from(_ event: NSEvent) -> RecordResult {
        let code = Int(event.keyCode)
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        var modifiers: UInt32 = 0
        if flags.contains(.command) { modifiers |= UInt32(cmdKey) }
        if flags.contains(.option) { modifiers |= UInt32(optionKey) }
        if flags.contains(.control) { modifiers |= UInt32(controlKey) }
        if flags.contains(.shift) { modifiers |= UInt32(shiftKey) }

        let name: String
        if let f = functionKeys[code] {
            name = f
        } else if let special = specialKeys[code] {
            name = special
        } else if let chars = event.characters(byApplyingModifiers: []), !chars.isEmpty,
                  chars.unicodeScalars.allSatisfy({ !CharacterSet.controlCharacters.contains($0) }) {
            name = chars.uppercased()
        } else {
            return .ignored
        }

        let strong = UInt32(cmdKey | optionKey | controlKey)
        if functionKeys[code] == nil && modifiers & strong == 0 { return .needsModifier }
        return .combo(KeyCombo(keyCode: UInt32(code), modifiers: modifiers, keyName: name))
    }
}

// MARK: - The shortcuts window

/// "Keyboard Shortcuts…" from the sliders menu: click a shortcut, press new keys.
@MainActor
final class ShortcutsWindowController: NSObject, NSWindowDelegate {
    private let window: NSWindow
    private let recorder: ShortcutRecorder

    init(controller: ScreenshotController) {
        recorder = ShortcutRecorder(controller: controller)
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 420, height: 250),
                          styleMask: [.titled, .closable], backing: .buffered, defer: false)
        super.init()
        window.title = "Screenshot Shortcuts"
        window.isReleasedWhenClosed = false
        window.delegate = self
        window.contentView = NSHostingView(rootView: ShortcutsView(recorder: recorder, controller: controller,
                                                                    close: { [weak self] in self?.window.close() }))
        window.center()
    }

    func show() {
        NSApp.activate(ignoringOtherApps: true)
        window.makeKeyAndOrderFront(nil)
    }

    func windowWillClose(_ notification: Notification) {
        recorder.stop()
    }
}

/// Which row is listening for keys. While listening, the screenshot shortcuts
/// are switched off so pressing the current one doesn't take a screenshot.
@MainActor
final class ShortcutRecorder: ObservableObject {
    @Published private(set) var listening: ShotAction?
    @Published var message: String?

    private let controller: ScreenshotController
    private var monitor: Any?

    init(controller: ScreenshotController) {
        self.controller = controller
    }

    func toggle(_ action: ShotAction) {
        if listening == action {
            stop()
        } else {
            start(action)
        }
    }

    private func start(_ action: ShotAction) {
        stop()
        listening = action
        message = "Press the new shortcut · Esc to cancel · ⌫ to turn it off"
        controller.suspendShortcuts()
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, let action = self.listening else { return event }
            self.handle(event, for: action)
            return nil  // don't let the key do anything else
        }
    }

    func stop() {
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
        if listening != nil {
            listening = nil
            controller.resumeShortcuts()
        }
    }

    private func handle(_ event: NSEvent, for action: ShotAction) {
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        let bare = flags.intersection([.command, .option, .control, .shift]).isEmpty
        if bare && Int(event.keyCode) == kVK_Escape {
            message = nil
            stop()
            return
        }
        if bare && (Int(event.keyCode) == kVK_Delete || Int(event.keyCode) == kVK_ForwardDelete) {
            stop()
            controller.setShortcut(nil, for: action)
            message = "\(action.title) has no shortcut now."
            return
        }
        switch KeyCombo.from(event) {
        case .combo(let combo):
            stop()
            let moved = controller.setShortcut(combo, for: action)
            if controller.unavailable.contains(action) {
                message = "\(combo.display) is already used by another app. Try a different one."
            } else if let moved {
                message = "Set to \(combo.display). \(moved.title) had it, so it's off now."
            } else {
                message = "Set to \(combo.display)."
            }
        case .needsModifier:
            message = "Add ⌘, ⌃ or ⌥ (F-keys work on their own)."
        case .ignored:
            break
        }
    }
}

private struct ShortcutsView: View {
    @ObservedObject var recorder: ShortcutRecorder
    @ObservedObject var controller: ScreenshotController
    let close: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            ForEach(ShotAction.allCases) { action in
                HStack {
                    Text(action.title)
                        .frame(width: 140, alignment: .leading)
                    Button {
                        recorder.toggle(action)
                    } label: {
                        Text(label(for: action))
                            .font(.system(size: 13, weight: .medium).monospacedDigit())
                            .frame(width: 150)
                            .padding(.vertical, 3)
                    }
                    .buttonStyle(.bordered)
                    .tint(recorder.listening == action ? .accentColor : nil)
                    if controller.unavailable.contains(action) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundStyle(.orange)
                            .help("Another app already uses this shortcut")
                    }
                    Spacer()
                }
            }

            Text(recorder.message ?? "Click a shortcut to change it.")
                .font(.system(size: 11.5))
                .foregroundStyle(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)

            Spacer(minLength: 0)
            HStack {
                Button("Reset to Defaults") {
                    recorder.stop()
                    controller.resetShortcuts()
                    recorder.message = "Back to ⌃⇧4, ⌃⇧2 and ⌃⇧1."
                }
                Spacer()
                Button("Done", action: close)
                    .keyboardShortcut(.defaultAction)
            }
        }
        .padding(20)
        .frame(width: 420, height: 250)
    }

    private func label(for action: ShotAction) -> String {
        if recorder.listening == action { return "Type shortcut…" }
        return controller.shortcuts[action]?.display ?? "Off"
    }
}
