import AppKit
import RecBarCore

extension NSScreen {
    var displayID: CGDirectDisplayID? {
        (deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber)?.uint32Value
    }

    /// The screen under the mouse pointer.
    static var underMouse: NSScreen? {
        let mouse = NSEvent.mouseLocation
        return screens.first { NSMouseInRect(mouse, $0.frame, false) } ?? main
    }
}

/// What the person dragged out on the frozen screen.
struct AreaSelection {
    let screen: NSScreen
    let capture: DisplayCapture
    /// In the display's own points, top-left origin (what ScreenCaptureKit wants).
    let rectInDisplay: CGRect
    /// In AppKit screen coordinates (bottom-left origin), for placing windows around it.
    let rectOnScreen: CGRect

    var pixelRect: CGRect {
        let s = capture.scale
        return CGRect(x: rectInDisplay.minX * s, y: rectInDisplay.minY * s,
                      width: rectInDisplay.width * s, height: rectInDisplay.height * s)
    }
}

/// Freezes the screen (shows the screenshot just taken over every display, so it
/// looks unchanged) and lets the person drag out an area. Kept minimal: a
/// crosshair pointer, the outline of the area and its size. Esc or right-click cancels.
@MainActor
final class AreaSelector {
    private var windows: [NSPanel] = []
    private var continuation: CheckedContinuation<AreaSelection?, Never>?
    private var escapeHotKey: UInt32?
    private var previousApp: NSRunningApplication?
    private var cursorTask: Task<Void, Never>?

    func run(captures: [DisplayCapture], hint: String?) async -> AreaSelection? {
        await withCheckedContinuation { continuation in
            self.continuation = continuation
            for screen in NSScreen.screens {
                guard let id = screen.displayID, let capture = captures.first(where: { $0.displayID == id }) else { continue }
                let panel = OverlayPanel(screen: screen)
                let root = FrozenScreenView(frame: NSRect(origin: .zero, size: screen.frame.size), image: capture.image)
                let selection = SelectionView(frame: root.bounds, capture: capture, hint: hint)
                selection.autoresizingMask = [.width, .height]
                selection.onFinish = { [weak self] rect in
                    self?.finish(AreaSelection(
                        screen: screen, capture: capture, rectInDisplay: rect,
                        rectOnScreen: CGRect(x: screen.frame.minX + rect.minX, y: screen.frame.maxY - rect.maxY,
                                             width: rect.width, height: rect.height)
                    ))
                }
                selection.onCancel = { [weak self] in self?.finish(nil) }
                root.addSubview(selection)
                panel.contentView = root
                panel.setFrame(screen.frame, display: true)
                panel.orderFrontRegardless()
                windows.append(panel)
            }
            guard !windows.isEmpty else {
                finish(nil)
                return
            }
            // macOS only lets the app in front change the pointer, so Rec Bar steps
            // in front while you select (the frozen picture hides the switch) and
            // hands focus back to your app afterwards.
            let front = NSWorkspace.shared.frontmostApplication
            previousApp = front?.processIdentifier == NSRunningApplication.current.processIdentifier ? nil : front
            NSApp.activate(ignoringOtherApps: true)
            let target = windows.first { NSMouseInRect(NSEvent.mouseLocation, $0.frame, false) } ?? windows[0]
            target.makeKeyAndOrderFront(nil)
            for window in windows {
                if let view = window.contentView?.subviews.first { window.invalidateCursorRects(for: view) }
            }
            NSCursor.crosshair.set()
            // Activation finishes a moment later; keep the crosshair on until then.
            cursorTask = Task { @MainActor [weak self] in
                for _ in 0..<10 {
                    try? await Task.sleep(nanoseconds: 50_000_000)
                    guard let self, self.continuation != nil else { return }
                    NSCursor.crosshair.set()
                }
            }
            escapeHotKey = HotKeys.shared.register(.escape, exclusive: false) { [weak self] in
                Task { @MainActor in self?.finish(nil) }
            }
        }
    }

    /// Stops selecting without taking a screenshot.
    func cancel() { finish(nil) }

    private func finish(_ selection: AreaSelection?) {
        guard let continuation else { return }
        self.continuation = nil
        HotKeys.shared.unregister(escapeHotKey)
        escapeHotKey = nil
        cursorTask?.cancel()
        cursorTask = nil
        for window in windows { window.orderOut(nil) }
        windows.removeAll()
        NSCursor.arrow.set()
        if let previousApp {
            NSApp.yieldActivation(to: previousApp)
            previousApp.activate(from: NSRunningApplication.current, options: [])
        }
        previousApp = nil
        continuation.resume(returning: selection)
    }
}

/// A borderless panel above everything (menu bar and Dock included). It appears
/// instantly: no pop-in animation, so the screen doesn't seem to jump.
final class OverlayPanel: NSPanel {
    init(screen: NSScreen) {
        super.init(contentRect: screen.frame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        animationBehavior = .none
        level = .screenSaver
        isOpaque = true
        backgroundColor = .black
        hasShadow = false
        isReleasedWhenClosed = false
        hidesOnDeactivate = false
        acceptsMouseMovedEvents = true
        collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

/// Shows the frozen screenshot (as a layer, so redrawing the selection is cheap).
final class FrozenScreenView: NSView {
    init(frame: NSRect, image: CGImage) {
        super.init(frame: frame)
        wantsLayer = true
        layer?.contents = image
        layer?.contentsGravity = .resize
        layer?.magnificationFilter = .nearest
    }

    required init?(coder: NSCoder) { fatalError("not used") }
}

/// The dragged rectangle and its size (plus an optional hint before dragging).
final class SelectionView: NSView {
    var onFinish: ((CGRect) -> Void)?
    var onCancel: (() -> Void)?

    private let capture: DisplayCapture
    private let hint: String?
    private var start: CGPoint?
    private var current: CGPoint?
    private var mouse: CGPoint?

    init(frame: NSRect, capture: DisplayCapture, hint: String?) {
        self.capture = capture
        self.hint = hint
        super.init(frame: frame)
        wantsLayer = true
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(
            rect: bounds,
            options: [.mouseMoved, .mouseEnteredAndExited, .cursorUpdate, .activeAlways, .inVisibleRect],
            owner: self
        ))
    }

    override func cursorUpdate(with event: NSEvent) { NSCursor.crosshair.set() }

    override func resetCursorRects() {
        addCursorRect(bounds, cursor: .crosshair)
    }

    override func mouseEntered(with event: NSEvent) {
        NSCursor.crosshair.set()
        mouse = convert(event.locationInWindow, from: nil)
        needsDisplay = true
    }

    override func mouseExited(with event: NSEvent) {
        mouse = nil
        needsDisplay = true
    }

    override func mouseMoved(with event: NSEvent) {
        NSCursor.crosshair.set()
        mouse = convert(event.locationInWindow, from: nil)
        needsDisplay = true
    }

    override func mouseDown(with event: NSEvent) {
        let p = convert(event.locationInWindow, from: nil)
        start = p
        current = p
        mouse = p
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        let p = convert(event.locationInWindow, from: nil)
        current = CGPoint(x: min(max(p.x, 0), bounds.width), y: min(max(p.y, 0), bounds.height))
        mouse = current
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        guard let rect = selectionRect, rect.width >= 4, rect.height >= 4 else {
            onCancel?()  // a click without a drag
            return
        }
        onFinish?(rect)
    }

    override func rightMouseDown(with event: NSEvent) { onCancel?() }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 { onCancel?() } else { super.keyDown(with: event) }
    }

    private var selectionRect: CGRect? {
        guard let start, let current else { return nil }
        // Snap to whole pixels.
        let s = capture.scale
        func snap(_ v: CGFloat) -> CGFloat { (v * s).rounded() / s }
        return CGRect(x: snap(min(start.x, current.x)), y: snap(min(start.y, current.y)),
                      width: snap(abs(current.x - start.x)), height: snap(abs(current.y - start.y)))
    }

    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current?.cgContext else { return }
        if let rect = selectionRect {
            // White line with a faint dark edge, so it shows on light and dark content.
            context.setStrokeColor(NSColor.black.withAlphaComponent(0.35).cgColor)
            context.setLineWidth(1)
            context.stroke(rect.insetBy(dx: -1.5, dy: -1.5))
            context.setStrokeColor(NSColor.white.cgColor)
            context.stroke(rect.insetBy(dx: -0.5, dy: -0.5))
            drawSizeLabel(for: rect)
        } else if hint != nil {
            drawHint()
        }
    }

    private func drawSizeLabel(for rect: CGRect) {
        let w = Int((rect.width * capture.scale).rounded())
        let h = Int((rect.height * capture.scale).rounded())
        let text = "\(w) × \(h)"
        var origin = CGPoint(x: rect.maxX - 4, y: rect.maxY + 8)
        let size = Pill.size(text)
        origin.x = min(max(origin.x - size.width, 8), bounds.width - size.width - 8)
        if origin.y + size.height > bounds.height - 8 { origin.y = rect.maxY - size.height - 8 }
        Pill.draw(text, at: origin)
    }

    private func drawHint() {
        guard let hint else { return }
        let size = Pill.size(hint)
        Pill.draw(hint, at: CGPoint(x: (bounds.width - size.width) / 2, y: 48))
    }
}

/// A dark rounded label with white text.
enum Pill {
    static let font = NSFont.monospacedDigitSystemFont(ofSize: 12, weight: .semibold)

    static func size(_ text: String) -> CGSize {
        let t = (text as NSString).size(withAttributes: [.font: font])
        return CGSize(width: ceil(t.width) + 16, height: 22)
    }

    static func draw(_ text: String, at origin: CGPoint) {
        let size = size(text)
        let rect = CGRect(origin: origin, size: size)
        NSColor(white: 0.1, alpha: 0.85).setFill()
        NSBezierPath(roundedRect: rect, xRadius: 11, yRadius: 11).fill()
        (text as NSString).draw(
            at: CGPoint(x: rect.minX + 8, y: rect.minY + (rect.height - font.ascender + font.descender) / 2),
            withAttributes: [.font: font, .foregroundColor: NSColor.white]
        )
    }
}

/// Zoomed pixels in a circle (selection magnifier and color picker).
/// Draws into a flipped (top-left origin) view.
enum Loupe {
    static func draw(image: CGImage, centerX: Int, centerY: Int, span: Int, in frame: CGRect, context: CGContext) {
        let half = span / 2
        let source = CGRect(x: centerX - half, y: centerY - half, width: span, height: span)
        context.saveGState()
        let circle = CGPath(ellipseIn: frame, transform: nil)

        context.addPath(circle)
        context.setFillColor(NSColor(white: 0.15, alpha: 1).cgColor)
        context.fillPath()

        context.addPath(circle)
        context.clip()
        if let pixels = image.cropping(to: source.intersection(CGRect(x: 0, y: 0, width: image.width, height: image.height))) {
            // Where the (possibly edge-clipped) crop sits inside the span.
            let clipped = source.intersection(CGRect(x: 0, y: 0, width: image.width, height: image.height))
            let zoom = frame.width / CGFloat(span)
            let dest = CGRect(x: frame.minX + (clipped.minX - source.minX) * zoom,
                              y: frame.minY + (clipped.minY - source.minY) * zoom,
                              width: clipped.width * zoom, height: clipped.height * zoom)
            context.interpolationQuality = .none
            // The view is flipped; flip the image back so it isn't drawn upside down.
            context.saveGState()
            context.translateBy(x: 0, y: dest.minY + dest.maxY)
            context.scaleBy(x: 1, y: -1)
            context.draw(pixels, in: dest)
            context.restoreGState()
        }
        // The centre pixel.
        let zoom = frame.width / CGFloat(span)
        let center = CGRect(x: frame.minX + CGFloat(half) * zoom, y: frame.minY + CGFloat(half) * zoom, width: zoom, height: zoom)
        context.setStrokeColor(NSColor.white.cgColor)
        context.setLineWidth(1.5)
        context.stroke(center)
        context.setStrokeColor(NSColor.black.withAlphaComponent(0.6).cgColor)
        context.setLineWidth(0.75)
        context.stroke(center.insetBy(dx: -1.1, dy: -1.1))
        context.restoreGState()

        context.saveGState()
        context.addPath(circle)
        context.setStrokeColor(NSColor.white.withAlphaComponent(0.9).cgColor)
        context.setLineWidth(2)
        context.strokePath()
        context.restoreGState()
    }
}
