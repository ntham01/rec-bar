import AppKit
import Combine
import RecBarCore

/// Screenshots, Shottr-style (default shortcuts; change them in Keyboard Shortcuts…):
///   ⌃⇧4  an area you drag out on the frozen screen
///   ⌃⇧2  the whole screen under the pointer
///   ⌃⇧1  a scrolling (long) capture of an area
/// Every capture is copied to the clipboard and shown in a small preview.
@MainActor
final class ScreenshotController: ObservableObject {
    /// Where Save puts screenshots. Starts as the Pictures folder.
    @Published private(set) var folder: URL
    /// The shortcut for each action (missing = turned off).
    @Published private(set) var shortcuts: [ShotAction: KeyCombo] = [:]
    /// Actions whose shortcut another app already uses.
    @Published private(set) var unavailable: Set<ShotAction> = []

    var folderDisplayPath: String { (folder.path as NSString).abbreviatingWithTildeInPath }

    private let previews = PreviewManager()
    private var busy = false
    private var scrolling: ScrollingCapture?
    private var editors: [EditorWindowController] = []
    private var registered: [ShotAction: UInt32] = [:]
    private var selector: AreaSelector?
    private var suspended = false
    private var shortcutsWindow: ShortcutsWindowController?

    private enum Keys {
        static let folder = "screenshotFolderPath"
        static func shortcut(_ action: ShotAction) -> String { "shortcut.\(action.rawValue)" }
    }

    init() {
        let pictures = FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask)[0]
        if let saved = UserDefaults.standard.string(forKey: Keys.folder),
           Recordings.isUsableFolder(URL(fileURLWithPath: saved, isDirectory: true)) {
            folder = URL(fileURLWithPath: saved, isDirectory: true)
        } else {
            folder = pictures
        }
        shortcuts = Self.loadShortcuts()
        previews.controller = self
    }

    // MARK: Shortcuts

    /// Registers the current shortcuts system-wide (replacing any registered before).
    func registerShortcuts() {
        for id in registered.values { HotKeys.shared.unregister(id) }
        registered.removeAll()
        guard !suspended else { return }
        var failed = Set<ShotAction>()
        for action in ShotAction.allCases {
            guard let combo = shortcuts[action] else { continue }
            let id = HotKeys.shared.register(combo.shortcut) { [weak self] in
                Task { @MainActor in await self?.perform(action) }
            }
            if let id { registered[action] = id } else { failed.insert(action) }
        }
        unavailable = failed
    }

    /// At launch: say so if another app (e.g. Shottr) already owns a shortcut,
    /// since its key presses then go to that app instead.
    func reportShortcutClashes() {
        let clashes = ShotAction.allCases.filter { unavailable.contains($0) }
        guard !clashes.isEmpty else { return }
        let keys = clashes.compactMap { shortcuts[$0]?.display }.joined(separator: ", ")
        Notice.show("Rec Bar can't use \(keys): another app (Shottr?) already has it. Quit that app, or pick new keys in Rec Bar's sliders menu → Screenshots → Keyboard Shortcuts…", seconds: 9)
    }

    func perform(_ action: ShotAction) async {
        // A shortcut pressed while an area is being selected replaces that selection.
        if let selector {
            selector.cancel()
            for _ in 0..<40 where busy { try? await Task.sleep(nanoseconds: 25_000_000) }
        }
        switch action {
        case .area: await captureArea()
        case .screen: await captureScreen()
        case .scrolling: await captureScrolling()
        }
    }

    /// Off while a new shortcut is being typed in, so the old one doesn't fire.
    func suspendShortcuts() {
        suspended = true
        registerShortcuts()
    }

    func resumeShortcuts() {
        suspended = false
        registerShortcuts()
    }

    /// Sets (or, with nil, turns off) an action's shortcut. If another action
    /// had the same keys, that one is turned off and returned.
    @discardableResult
    func setShortcut(_ combo: KeyCombo?, for action: ShotAction) -> ShotAction? {
        var moved: ShotAction?
        if let combo, let other = ShotAction.allCases.first(where: { $0 != action && shortcuts[$0] == combo }) {
            shortcuts[other] = nil
            save(nil, for: other)
            moved = other
        }
        shortcuts[action] = combo
        save(combo, for: action)
        registerShortcuts()
        return moved
    }

    func resetShortcuts() {
        for action in ShotAction.allCases {
            UserDefaults.standard.removeObject(forKey: Keys.shortcut(action))
        }
        shortcuts = Self.loadShortcuts()
        registerShortcuts()
    }

    func openShortcutsWindow() {
        let window = shortcutsWindow ?? ShortcutsWindowController(controller: self)
        shortcutsWindow = window
        window.show()
    }

    /// e.g. "Capture Area   ⌃⇧4" for the settings menu.
    func menuTitle(_ action: ShotAction) -> String {
        guard let combo = shortcuts[action] else { return action.title }
        return "\(action.title)   \(combo.display)"
    }

    private func save(_ combo: KeyCombo?, for action: ShotAction) {
        let key = Keys.shortcut(action)
        if let combo, let data = try? JSONEncoder().encode(combo) {
            UserDefaults.standard.set(data, forKey: key)
        } else {
            UserDefaults.standard.set("off", forKey: key)
        }
    }

    private static func loadShortcuts() -> [ShotAction: KeyCombo] {
        var result: [ShotAction: KeyCombo] = [:]
        for action in ShotAction.allCases {
            let stored = UserDefaults.standard.object(forKey: Keys.shortcut(action))
            if let data = stored as? Data, let combo = try? JSONDecoder().decode(KeyCombo.self, from: data) {
                result[action] = combo
            } else if stored as? String == "off" {
                continue
            } else {
                result[action] = action.defaultCombo
            }
        }
        return result
    }

    // MARK: Captures

    /// When started from the settings menu, wait for the menu to disappear first.
    func fromMenu(_ capture: @escaping @MainActor () async -> Void) {
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 250_000_000)
            await capture()
        }
    }

    func captureArea() async {
        guard begin() else { return }
        defer { busy = false }
        do {
            let captures = try await ScreenGrabber.captureAllDisplays()
            let selector = AreaSelector()
            self.selector = selector
            defer { self.selector = nil }
            guard let selection = await selector.run(captures: captures, hint: nil),
                  let image = ImageTools.crop(selection.capture.image, toPixels: selection.pixelRect) else { return }
            deliver(Screenshot(image: image, scale: selection.capture.scale))
        } catch {
            handle(error)
        }
    }

    func captureScreen() async {
        guard begin() else {
            Notice.show("Another screenshot is still in progress (Esc ends it).")
            return
        }
        defer { busy = false }
        do {
            let screen = NSScreen.underMouse ?? NSScreen.screens[0]
            let captures = try await ScreenGrabber.captureAllDisplays()
            guard let capture = captures.first(where: { $0.displayID == screen.displayID }) ?? captures.first else { return }
            deliver(Screenshot(image: capture.image, scale: capture.scale))
        } catch {
            handle(error)
        }
    }

    /// `checked: false` skips the Accessibility check (the help window's Try Anyway).
    func captureScrolling(checked: Bool = true) async {
        // Pressing the scrolling shortcut again during a scrolling capture finishes it.
        if let scrolling {
            scrolling.finish()
            return
        }
        // Like Shottr, Rec Bar scrolls the page itself, which needs Accessibility permission.
        guard !checked || ScrollingCapture.canAutoScroll else {
            requestAutoScroll()
            return
        }
        guard begin() else { return }
        defer { busy = false }
        do {
            let captures = try await ScreenGrabber.captureAllDisplays()
            let selector = AreaSelector()
            self.selector = selector
            let picked = await selector.run(captures: captures, hint: nil)
            self.selector = nil
            guard let selection = picked else { return }
            let session = ScrollingCapture(selection: selection)
            scrolling = session
            let shot = await session.run()
            scrolling = nil
            if let shot { deliver(shot) }
            if session.couldNotScroll {
                Notice.show("Rec Bar couldn't scroll the page: macOS isn't letting it yet. You got what was on screen.", seconds: 7)
                requestAutoScroll()
            }
        } catch {
            scrolling = nil
            handle(error)
        }
    }

    private func begin() -> Bool {
        guard !busy else { return false }
        busy = true
        return true
    }

    /// Copies the screenshot and opens its preview where the pointer is now
    /// (for an area capture, where you let go).
    private func deliver(_ shot: Screenshot) {
        ImageTools.copyToClipboard(shot)
        previews.show(shot, at: NSEvent.mouseLocation)
    }

    private func handle(_ error: Error) {
        if let recBarError = error as? RecBarError, case .permissionDenied = recBarError {
            ScreenRecordingPermission.request()
            ScreenRecordingPermission.openSystemSettings()
            Notice.show("Screenshots need Screen & System Audio Recording: turn on Rec Bar in System Settings.")
        } else {
            NSLog("Rec Bar screenshot failed: \(error.localizedDescription)")
            Notice.show("Screenshot didn't work: \(error.localizedDescription)")
        }
    }

    // MARK: Preview actions

    func save(_ item: PreviewItem) {
        do {
            let url = try ImageTools.save(item.shot, in: folder)
            item.show(toast: "Saved to \(folder.lastPathComponent)")
            NSLog("Rec Bar saved \(url.path)")
        } catch {
            item.show(toast: "Couldn't save: \(error.localizedDescription)")
        }
    }

    func copyText(from item: PreviewItem) {
        item.show(toast: "Reading text…")
        let image = item.shot.image
        Task { @MainActor in
            let text = await ImageTools.recognizeText(image)
            if text.isEmpty {
                item.show(toast: "No text found")
            } else {
                ImageTools.copyToClipboard(text: text)
                let lines = text.split(separator: "\n").count
                item.show(toast: "Copied text (\(lines) line\(lines == 1 ? "" : "s"))")
            }
        }
    }

    func openEditor(for item: PreviewItem, tool: EditorModel.Tool) {
        if let open = editors.first(where: { $0.item === item }) {
            open.model.tool = tool
            open.showWindow()
            return
        }
        item.editing = true
        let editor = EditorWindowController(item: item, tool: tool, folder: folder) { [weak self] controller, edited in
            guard let self else { return }
            item.editing = false
            if let edited {
                item.shot = edited
                ImageTools.copyToClipboard(edited)
                item.show(toast: "Copied edited screenshot")
                self.previews.refresh(item)
            } else {
                self.previews.scheduleHide(item)
            }
            self.editors.removeAll { $0 === controller }
        }
        editors.append(editor)
        editor.showWindow()
    }

    // MARK: Settings

    func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.directoryURL = folder
        panel.prompt = "Save Here"
        panel.message = "Choose where Rec Bar saves screenshots."
        NSApp.activate(ignoringOtherApps: true)
        guard panel.runModal() == .OK, let url = panel.url, Recordings.isUsableFolder(url) else { return }
        folder = url
        UserDefaults.standard.set(url.path, forKey: Keys.folder)
    }

    func openFolder() {
        NSWorkspace.shared.open(folder)
    }

    /// Scrolling capture can scroll for you once Rec Bar may send scroll events
    /// (System Settings → Privacy & Security → Accessibility).
    func requestAutoScroll() {
        AutoScrollPermission.showHelp(shortcut: shortcuts[.scrolling]?.display ?? "the scrolling shortcut") { [weak self] in
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 300_000_000)   // let the window go first
                await self?.captureScrolling(checked: false)
            }
        }
    }
}
