import AppKit
import ApplicationServices
import CoreGraphics
import RecBarCore
import SwiftUI

/// Scrolling capture, the way Shottr does it: you drag over an area, then Rec
/// Bar scrolls it by itself, a third of the area at a time, joining the frames
/// as it goes, and stops at the bottom of the page.
///
/// Sending scroll events needs Accessibility permission (ScreenshotController
/// asks for it before starting). Esc, Return, the scrolling shortcut again or
/// Done finish early and keep what's there; Cancel throws it away.
@MainActor
final class ScrollingCapture: ObservableObject {
    private enum Stop { case done, cancel }

    @Published private(set) var heightInPixels = 0
    @Published private(set) var status = "Scrolling… Esc to stop"
    @Published private(set) var finishing = false
    /// The page never moved and macOS hasn't allowed scrolling: the events went nowhere.
    private(set) var couldNotScroll = false

    private let selection: AreaSelection
    private var stopReason: Stop?
    private var hud: NSPanel?
    private var border: NSPanel?
    private var hotKeys: [UInt32?] = []

    /// Longest a capture runs before stopping by itself.
    private static let timeLimit: TimeInterval = 180

    init(selection: AreaSelection) {
        self.selection = selection
    }

    /// Whether Rec Bar may send scroll events (System Settings → Privacy & Security → Accessibility).
    /// (AXIsProcessTrusted updates as soon as it's switched on; the other check
    /// can lag until Rec Bar restarts.)
    static var canAutoScroll: Bool { AutoScrollPermission.isGranted }

    // MARK: Controls

    func finish() { if stopReason == nil { stopReason = .done } }
    func cancel() { stopReason = .cancel }

    // MARK: Running

    func run() async -> Screenshot? {
        showWindows()
        hotKeys = [
            HotKeys.shared.register(.escape, exclusive: false) { [weak self] in Task { @MainActor in self?.finish() } },
            HotKeys.shared.register(.returnKey, exclusive: false) { [weak self] in Task { @MainActor in self?.finish() } },
        ]
        defer {
            hotKeys.forEach { HotKeys.shared.unregister($0) }
            hud?.orderOut(nil)
            border?.orderOut(nil)
        }

        let originalMouse = CGEvent(source: nil)?.location
        let result = await captureLoop()
        if let originalMouse { CGWarpMouseCursorPosition(originalMouse) }
        return result
    }

    private func captureLoop() async -> Screenshot? {
        let capturer: RegionCapturer
        do {
            capturer = try await ScreenGrabber.regionCapturer(
                displayID: selection.capture.displayID, rectInPoints: selection.rectInDisplay)
        } catch {
            return nil
        }
        let worker = StitchWorker()
        guard let firstImage = try? await capturer.capture(), await worker.start(firstImage) else { return nil }
        heightInPixels = await worker.height

        // Scroll events go to whatever is under the pointer, so point it at the area.
        let point = scrollPoint
        CGWarpMouseCursorPosition(point)
        try? await Task.sleep(nanoseconds: 120_000_000)

        // Apps don't all move the page by the amount asked for, so start with a
        // small step, measure how far the page really moved, and size the next
        // steps to move about 40% of the area each time.
        let areaHeight = selection.rectInDisplay.height
        let target = areaHeight * 0.4
        var request = max(30, min(120, areaHeight * 0.15))   // points asked for per step
        var direction: CGFloat = -1   // negative = scroll down
        var flipped = false
        var moved = false
        var stillSteps = 0
        var lostCount = 0
        var recovering = 0            // steps left in which going back up is expected
        var knownRatio: CGFloat?      // how far the page moves per point asked for
        var nearEnd = false           // the last step moved less than expected: probably the bottom
        let started = Date()
        ScrollLog.begin("area \(Int(selection.rectInDisplay.width))×\(Int(areaHeight)) pt, scale \(capturer.scale)")

        while stopReason == nil {
            if Date().timeIntervalSince(started) > Self.timeLimit {
                finish()
                break
            }
            let asked = request
            await scroll(by: asked * direction, at: point)
            guard let result = await settleAndAdd(capturer, worker) else {
                try? await Task.sleep(nanoseconds: 100_000_000)
                continue
            }
            if stopReason != nil { break }
            let detail = await worker.detail
            ScrollLog.add("asked \(Int(asked * direction)) → \(result) [\(detail)]")

            switch result {
            case .appended(let rows):
                moved = true
                stillSteps = 0
                lostCount = 0
                recovering = 0
                heightInPixels = await worker.height
                let movedPoints = CGFloat(rows) / capturer.scale
                if let known = knownRatio, movedPoints < asked * known * 0.85 {
                    // Fell short of what was asked: the page has probably hit the
                    // bottom. Check with one gentle nudge instead of a big push
                    // (big pushes at the bottom make the page bounce back).
                    nearEnd = true
                    request = min(asked, 24)
                } else {
                    nearEnd = false
                    let ratio = min(8, max(0.25, movedPoints / asked))
                    knownRatio = ratio
                    request = min(max(target / ratio, 10), min(asked * 2, areaHeight * 0.6))
                }

            case .noMovement:
                if recovering > 0 {
                    recovering -= 1
                    break
                }
                stillSteps += 1
                if !moved && !flipped && stillSteps >= 2 {
                    direction = -direction      // some setups scroll the other way round
                    flipped = true
                    stillSteps = 0
                } else if moved && (nearEnd || stillSteps >= 2) {
                    finish()                    // reached the bottom
                } else if moved {
                    request = min(request, 24)  // confirm with a gentle nudge
                } else if stillSteps >= 3 {
                    finish()                    // nothing here scrolls
                }

            case .movedUp:
                if recovering > 0 {
                    recovering -= 1
                } else if !moved && !flipped {
                    direction = -direction
                    flipped = true
                    stillSteps = 0
                } else {
                    finish()
                }

            case .lost:
                // Moved further than the overlap. Go back once, then carry on in
                // much smaller steps (no back-and-forth: a few tries, then stop).
                lostCount += 1
                if lostCount > 4 {
                    status = "Lost track (moving content?) — keeping what's captured"
                    finish()
                    break
                }
                await scroll(by: -asked * direction, at: point)
                request = max(10, asked / 3)
                recovering = 6
                stillSteps = 0
                try? await Task.sleep(nanoseconds: 300_000_000)

            case .full:
                status = "Reached the maximum height"
                finish()
            }
        }
        ScrollLog.add("ended: \(stopReason == .cancel ? "cancelled" : "done"), moved \(moved), height \(heightInPixels) px")

        if !moved && !AutoScrollPermission.isGranted { couldNotScroll = true }
        guard stopReason == .done else { return nil }
        finishing = true
        guard let image = await worker.makeImage() else { return nil }
        return Screenshot(image: image, scale: capturer.scale)
    }

    /// Waits until the page has stopped moving (two captures in a row look the
    /// same, or about half a second has passed), then joins the frame on.
    private func settleAndAdd(_ capturer: RegionCapturer, _ worker: StitchWorker) async -> StitchResult? {
        try? await Task.sleep(nanoseconds: 70_000_000)
        guard let firstImage = try? await capturer.capture() else { return nil }
        _ = await worker.stage(firstImage)
        for _ in 0..<7 {
            if stopReason != nil { break }
            try? await Task.sleep(nanoseconds: 50_000_000)
            guard let image = try? await capturer.capture() else { break }
            if await worker.stage(image) { break }
        }
        return await worker.addStaged()
    }

    // MARK: Scrolling

    /// Centre of the area in global display coordinates (top-left origin).
    private var scrollPoint: CGPoint {
        let primaryHeight = NSScreen.screens.first?.frame.height ?? selection.screen.frame.height
        let r = selection.rectOnScreen
        return CGPoint(x: r.midX, y: primaryHeight - r.midY)
    }

    /// Sends the scroll as a few small trackpad-style events (some apps cap how
    /// far a single event can scroll).
    private func scroll(by points: CGFloat, at location: CGPoint) async {
        let parts = 4
        let each = Int32((points / CGFloat(parts)).rounded())
        guard each != 0 else { return }
        for _ in 0..<parts {
            guard let event = CGEvent(
                scrollWheelEvent2Source: nil, units: .pixel, wheelCount: 1,
                wheel1: each, wheel2: 0, wheel3: 0
            ) else { return }
            event.setIntegerValueField(.scrollWheelEventIsContinuous, value: 1)
            event.location = location
            event.post(tap: .cghidEventTap)
            try? await Task.sleep(nanoseconds: 12_000_000)
        }
    }

    // MARK: Windows

    private func showWindows() {
        let rect = selection.rectOnScreen

        // A dashed frame just outside the area (Rec Bar's windows aren't captured anyway).
        let frame = NSPanel(contentRect: rect.insetBy(dx: -4, dy: -4), styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        frame.animationBehavior = .none
        frame.level = .statusBar
        frame.isOpaque = false
        frame.backgroundColor = .clear
        frame.hasShadow = false
        frame.ignoresMouseEvents = true
        frame.isReleasedWhenClosed = false
        frame.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        frame.contentView = DashedFrameView(frame: NSRect(origin: .zero, size: frame.frame.size))
        frame.orderFrontRegardless()
        border = frame

        // The status bar under the area (or above it if there's no room).
        let size = NSSize(width: ScrollingHUD.width, height: 40)
        let visible = selection.screen.visibleFrame
        var origin = NSPoint(x: rect.midX - size.width / 2, y: rect.minY - size.height - 12)
        if origin.y < visible.minY + 8 { origin.y = rect.maxY + 12 }
        if origin.y + size.height > visible.maxY - 8 { origin.y = rect.minY + 12 }
        origin.x = min(max(origin.x, visible.minX + 8), visible.maxX - size.width - 8)

        let panel = NSPanel(contentRect: NSRect(origin: origin, size: size), styleMask: [.borderless, .nonactivatingPanel],
                            backing: .buffered, defer: false)
        panel.animationBehavior = .none
        panel.level = .statusBar
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.isReleasedWhenClosed = false
        panel.hidesOnDeactivate = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        let host = FirstMouseHostingView(rootView: ScrollingHUD(session: self))
        host.frame = NSRect(origin: .zero, size: size)
        panel.contentView = host
        panel.orderFrontRegardless()
        hud = panel
    }
}

private final class DashedFrameView: NSView {
    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current?.cgContext else { return }
        let rect = bounds.insetBy(dx: 2, dy: 2)
        context.setLineWidth(2)
        context.setStrokeColor(NSColor.white.cgColor)
        context.stroke(rect)
        context.setStrokeColor(NSColor(red: 1, green: 69 / 255, blue: 58 / 255, alpha: 1).cgColor)
        context.setLineDash(phase: 0, lengths: [6, 6])
        context.stroke(rect)
    }
}

/// The dark status bar shown during a scrolling capture.
private struct ScrollingHUD: View {
    static let width: CGFloat = 420
    @ObservedObject var session: ScrollingCapture

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(Color(red: 1, green: 69 / 255, blue: 58 / 255))
                .frame(width: 8, height: 8)
            Text("\(session.heightInPixels.formatted()) px")
                .font(.system(size: 12, weight: .semibold).monospacedDigit())
                .foregroundStyle(Color.white)
                .fixedSize()
            Text(session.finishing ? "Joining…" : session.status)
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.7))
                .lineLimit(1)
            Spacer(minLength: 4)
            hudButton("Cancel", prominent: false) { session.cancel() }
            hudButton("Done", prominent: true) { session.finish() }
        }
        .padding(.horizontal, 14)
        .frame(width: Self.width, height: 40)
        .background(Capsule().fill(Color(red: 24 / 255, green: 24 / 255, blue: 27 / 255).opacity(0.92)))
        .overlay(Capsule().strokeBorder(Color.white.opacity(0.12), lineWidth: 0.5))
        .environment(\.colorScheme, .dark)
    }

    private func hudButton(_ title: String, prominent: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(Color.white)
                .padding(.horizontal, 10)
                .frame(height: 24)
                .background(Capsule().fill(prominent ? Color(red: 10 / 255, green: 132 / 255, blue: 1) : Color.white.opacity(0.14)))
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .disabled(session.finishing)
    }
}

/// What the last scrolling capture did, step by step (included in Copy Details).
@MainActor
enum ScrollLog {
    private(set) static var lines: [String] = []

    static func begin(_ line: String) { lines = [line] }

    static func add(_ line: String) {
        if lines.count < 80 { lines.append(line) }
    }

    static var text: String { lines.isEmpty ? "none yet" : lines.joined(separator: "\n  ") }
}
