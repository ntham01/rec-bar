import AppKit
import RecBarCore
import SwiftUI

/// The screenshot being edited, its tools and its undo history.
@MainActor
final class EditorModel: ObservableObject {
    enum Tool { case none, crop, color }

    @Published private(set) var shot: Screenshot
    @Published var tool: Tool {
        didSet { if tool != .crop { cropRect = nil } }
    }
    /// The crop being drawn, in image pixels (top-left origin).
    @Published var cropRect: CGRect?
    /// Color under the pointer in color mode, and the last one copied.
    @Published var hoverHex: String?
    @Published private(set) var copiedHex: String?
    @Published private(set) var canUndo = false

    private var history: [Screenshot] = []
    private var reader: PixelReader?
    private let original: Screenshot

    var changed: Bool { shot.image !== original.image }

    init(shot: Screenshot, tool: Tool) {
        self.shot = shot
        original = shot
        self.tool = tool
    }

    var sizeText: String { "\(shot.image.width) × \(shot.image.height)" }

    func rotate(clockwise: Bool) {
        guard let rotated = ImageTools.rotate(shot.image, clockwise: clockwise) else { return }
        replace(with: Screenshot(image: rotated, scale: shot.scale))
    }

    func applyCrop() {
        guard let rect = cropRect, rect.width >= 2, rect.height >= 2,
              let cropped = ImageTools.crop(shot.image, toPixels: rect) else { return }
        replace(with: Screenshot(image: cropped, scale: shot.scale))
        tool = .none
    }

    func undo() {
        guard let previous = history.popLast() else { return }
        shot = previous
        reader = nil
        cropRect = nil
        canUndo = !history.isEmpty
    }

    func hex(atPixelX x: Int, y: Int) -> String? {
        if reader == nil { reader = PixelReader(shot.image) }
        return reader?.hex(x: x, y: y)
    }

    /// Copies the color at a pixel as "#RRGGBB".
    func pick(atPixelX x: Int, y: Int) {
        guard let hex = hex(atPixelX: x, y: y) else { return }
        ImageTools.copyToClipboard(text: hex)
        copiedHex = hex
    }

    private func replace(with new: Screenshot) {
        history.append(shot)
        shot = new
        reader = nil
        cropRect = nil
        canUndo = true
    }
}

/// The editor window. Closing it (or Done) keeps the edits.
@MainActor
final class EditorWindowController: NSObject, NSWindowDelegate {
    let item: PreviewItem
    let model: EditorModel
    private let window: NSWindow
    private let folder: URL
    private let onClose: (EditorWindowController, Screenshot?) -> Void
    private var closed = false

    init(item: PreviewItem, tool: EditorModel.Tool, folder: URL,
         onClose: @escaping (EditorWindowController, Screenshot?) -> Void) {
        self.item = item
        self.folder = folder
        self.onClose = onClose
        model = EditorModel(shot: item.shot, tool: tool)

        let visible = (NSScreen.underMouse ?? NSScreen.screens[0]).visibleFrame
        let point = item.shot.pointSize
        let width = min(max(point.width + 48, 640), visible.width * 0.85)
        let height = min(max(point.height + 48 + 52, 420), visible.height * 0.85)
        window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: width, height: height),
            styleMask: [.titled, .closable, .resizable, .miniaturizable, .fullSizeContentView],
            backing: .buffered, defer: false
        )
        super.init()

        window.title = "Screenshot"
        window.titlebarAppearsTransparent = true
        window.isReleasedWhenClosed = false
        window.appearance = NSAppearance(named: .darkAqua)
        window.backgroundColor = NSColor(red: 0.12, green: 0.12, blue: 0.13, alpha: 1)
        window.minSize = NSSize(width: 560, height: 360)
        window.delegate = self
        window.contentView = NSHostingView(rootView: EditorView(
            model: model,
            copy: { [weak self] in self?.copy() },
            save: { [weak self] in self?.save() },
            done: { [weak self] in self?.window.close() }
        ))
        window.center()
    }

    func showWindow() {
        NSApp.activate(ignoringOtherApps: true)
        window.makeKeyAndOrderFront(nil)
    }

    private func copy() {
        ImageTools.copyToClipboard(model.shot)
        item.show(toast: "Copied")
    }

    private func save() {
        do {
            _ = try ImageTools.save(model.shot, in: folder)
            item.shot = model.shot
            item.show(toast: "Saved to \(folder.lastPathComponent)")
            window.close()
        } catch {
            NSSound.beep()
        }
    }

    func windowWillClose(_ notification: Notification) {
        guard !closed else { return }
        closed = true
        onClose(self, model.changed ? model.shot : nil)
    }
}

// MARK: - The editor's layout

private struct EditorView: View {
    @ObservedObject var model: EditorModel
    let copy: () -> Void
    let save: () -> Void
    let done: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            toolRow
                .padding(.top, 28)  // under the transparent title bar
            EditorCanvas(model: model)
        }
        .background(Color(red: 0.12, green: 0.12, blue: 0.13))
        .environment(\.colorScheme, .dark)
    }

    private var toolRow: some View {
        HStack(spacing: 6) {
            toolButton("crop", "Crop", selected: model.tool == .crop) {
                model.tool = model.tool == .crop ? .none : .crop
            }
            iconButton("rotate.left", "Rotate left") { model.rotate(clockwise: false) }
            iconButton("rotate.right", "Rotate right") { model.rotate(clockwise: true) }
            toolButton("eyedropper", "Color", selected: model.tool == .color) {
                model.tool = model.tool == .color ? .none : .color
            }
            iconButton("arrow.uturn.backward", "Undo") { model.undo() }
                .disabled(!model.canUndo)
                .opacity(model.canUndo ? 1 : 0.35)

            Divider().frame(height: 20).padding(.horizontal, 4)
            status
            Spacer(minLength: 8)

            Text(model.sizeText)
                .font(.system(size: 11.5).monospacedDigit())
                .foregroundStyle(Color.white.opacity(0.5))
            textButton("Copy", prominent: false, action: copy)
            textButton("Save", prominent: false, action: save)
            textButton("Done", prominent: true, action: done)
        }
        .padding(.horizontal, 14)
        .frame(height: 44)
    }

    /// What the current tool needs: crop buttons, or the color under the pointer.
    @ViewBuilder
    private var status: some View {
        switch model.tool {
        case .crop:
            if model.cropRect != nil {
                textButton("Apply Crop", prominent: true) { model.applyCrop() }
                textButton("Clear", prominent: false) { model.cropRect = nil }
            } else {
                hint("Drag over the part to keep · Return to apply")
            }
        case .color:
            if let hex = model.hoverHex ?? model.copiedHex {
                HStack(spacing: 6) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color(hexString: hex))
                        .frame(width: 16, height: 16)
                        .overlay(RoundedRectangle(cornerRadius: 3).strokeBorder(Color.white.opacity(0.3), lineWidth: 0.5))
                    Text(hex).font(.system(size: 12, weight: .semibold).monospaced())
                    if let copied = model.copiedHex {
                        Text("· copied \(copied)").font(.system(size: 11.5)).foregroundStyle(Color.white.opacity(0.5))
                    }
                }
            } else {
                hint("Click (or press Tab) to copy a color")
            }
        case .none:
            EmptyView()
        }
    }

    private func hint(_ text: String) -> some View {
        Text(text).font(.system(size: 11.5)).foregroundStyle(Color.white.opacity(0.5)).lineLimit(1)
    }

    private func iconButton(_ symbol: String, _ help: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 14))
                .frame(width: 30, height: 28)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(Color.white.opacity(0.85))
        .help(help)
    }

    private func toolButton(_ symbol: String, _ help: String, selected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 14))
                .frame(width: 30, height: 28)
                .background(RoundedRectangle(cornerRadius: 6).fill(selected ? Color.white.opacity(0.18) : Color.clear))
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(Color.white.opacity(selected ? 1 : 0.85))
        .help(help)
    }

    private func textButton(_ title: String, prominent: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .padding(.horizontal, 10)
                .frame(height: 26)
                .background(RoundedRectangle(cornerRadius: 6)
                    .fill(prominent ? Color(red: 10 / 255, green: 132 / 255, blue: 1) : Color.white.opacity(0.12)))
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(Color.white)
    }
}

extension Color {
    /// "#RRGGBB" → Color.
    init(hexString: String) {
        let digits = hexString.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        let value = UInt32(digits, radix: 16) ?? 0
        self.init(red: Double((value >> 16) & 0xFF) / 255, green: Double((value >> 8) & 0xFF) / 255,
                  blue: Double(value & 0xFF) / 255)
    }
}

// MARK: - The canvas

private struct EditorCanvas: NSViewRepresentable {
    @ObservedObject var model: EditorModel

    func makeNSView(context: Context) -> EditorCanvasView { EditorCanvasView(model: model) }

    func updateNSView(_ view: EditorCanvasView, context: Context) {
        view.needsDisplay = true
        view.window?.invalidateCursorRects(for: view)
    }
}

/// Draws the screenshot fitted to the window, plus the crop box or the color magnifier.
final class EditorCanvasView: NSView {
    private let model: EditorModel
    private var mouse: CGPoint?
    private var drag: Drag?

    private struct Edges: OptionSet {
        let rawValue: Int
        static let left = Edges(rawValue: 1)
        static let right = Edges(rawValue: 2)
        static let top = Edges(rawValue: 4)
        static let bottom = Edges(rawValue: 8)
    }

    private enum Drag {
        case new(start: CGPoint)
        case move(grab: CGPoint, original: CGRect)
        case resize(edges: Edges, original: CGRect)
    }

    init(model: EditorModel) {
        self.model = model
        super.init(frame: .zero)
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    override var isFlipped: Bool { true }
    override var acceptsFirstResponder: Bool { true }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        window?.makeFirstResponder(self)
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: bounds, options: [.mouseMoved, .mouseEnteredAndExited, .activeInKeyWindow, .inVisibleRect],
                                       owner: self))
    }

    // MARK: Geometry

    private var image: CGImage { model.shot.image }

    /// Where the image is drawn: fitted inside the view, never bigger than its real size.
    private var imageRect: CGRect {
        let point = model.shot.pointSize
        let area = bounds.insetBy(dx: 24, dy: 20)
        guard point.width > 0, point.height > 0, area.width > 0, area.height > 0 else { return .zero }
        let fit = min(1, area.width / point.width, area.height / point.height)
        let size = CGSize(width: point.width * fit, height: point.height * fit)
        return CGRect(x: (bounds.width - size.width) / 2, y: (bounds.height - size.height) / 2,
                      width: size.width, height: size.height).integral
    }

    private var pixelsPerViewPoint: CGFloat {
        let r = imageRect
        return r.width > 0 ? CGFloat(image.width) / r.width : 1
    }

    private func toPixel(_ p: CGPoint) -> CGPoint {
        let r = imageRect, k = pixelsPerViewPoint
        return CGPoint(x: (p.x - r.minX) * k, y: (p.y - r.minY) * k)
    }

    private func toView(_ rect: CGRect) -> CGRect {
        let r = imageRect, k = pixelsPerViewPoint
        return CGRect(x: r.minX + rect.minX / k, y: r.minY + rect.minY / k, width: rect.width / k, height: rect.height / k)
    }

    private func clampToImage(_ p: CGPoint) -> CGPoint {
        CGPoint(x: min(max(p.x, 0), CGFloat(image.width)), y: min(max(p.y, 0), CGFloat(image.height)))
    }

    // MARK: Drawing

    override func draw(_ dirtyRect: NSRect) {
        guard let context = NSGraphicsContext.current?.cgContext else { return }
        let r = imageRect

        // The image (the view is flipped, so flip it back while drawing).
        context.saveGState()
        context.interpolationQuality = pixelsPerViewPoint < 1 ? .none : .high
        context.translateBy(x: 0, y: r.minY + r.maxY)
        context.scaleBy(x: 1, y: -1)
        context.draw(image, in: r)
        context.restoreGState()
        context.setStrokeColor(NSColor.white.withAlphaComponent(0.12).cgColor)
        context.stroke(r.insetBy(dx: -0.5, dy: -0.5))

        switch model.tool {
        case .crop: drawCrop(in: context)
        case .color: drawColorLoupe(in: context)
        case .none: break
        }
    }

    private func drawCrop(in context: CGContext) {
        guard let crop = model.cropRect else { return }
        let r = imageRect
        let box = toView(crop)
        let path = CGMutablePath()
        path.addRect(r)
        path.addRect(box)
        context.addPath(path)
        context.setFillColor(NSColor.black.withAlphaComponent(0.55).cgColor)
        context.fillPath(using: .evenOdd)

        context.setStrokeColor(NSColor.white.cgColor)
        context.setLineWidth(1.5)
        context.stroke(box)
        // Rule-of-thirds lines.
        context.setStrokeColor(NSColor.white.withAlphaComponent(0.3).cgColor)
        context.setLineWidth(0.5)
        for i in 1...2 {
            let x = box.minX + box.width * CGFloat(i) / 3, y = box.minY + box.height * CGFloat(i) / 3
            context.move(to: CGPoint(x: x, y: box.minY)); context.addLine(to: CGPoint(x: x, y: box.maxY))
            context.move(to: CGPoint(x: box.minX, y: y)); context.addLine(to: CGPoint(x: box.maxX, y: y))
        }
        context.strokePath()
        // Handles.
        context.setFillColor(NSColor.white.cgColor)
        for p in handlePoints(of: box) {
            context.fill(CGRect(x: p.x - 4, y: p.y - 4, width: 8, height: 8))
        }
        Pill.draw("\(Int(crop.width.rounded())) × \(Int(crop.height.rounded()))",
                  at: CGPoint(x: box.minX, y: max(r.minY, box.minY - 28)))
    }

    private func drawColorLoupe(in context: CGContext) {
        guard let mouse, imageRect.contains(mouse) else { return }
        let p = toPixel(mouse)
        let px = Int(p.x.rounded(.down)), py = Int(p.y.rounded(.down))
        let side: CGFloat = 132
        var frame = CGRect(x: mouse.x + 20, y: mouse.y + 20, width: side, height: side)
        if frame.maxX > bounds.width - 8 { frame.origin.x = mouse.x - 20 - side }
        if frame.maxY > bounds.height - 8 { frame.origin.y = mouse.y - 20 - side }
        Loupe.draw(image: image, centerX: px, centerY: py, span: 11, in: frame, context: context)
        if let hex = model.hex(atPixelX: px, y: py) {
            let size = Pill.size(hex)
            Pill.draw(hex, at: CGPoint(x: frame.midX - size.width / 2, y: frame.maxY + 6))
        }
    }

    private func handlePoints(of box: CGRect) -> [CGPoint] {
        [CGPoint(x: box.minX, y: box.minY), CGPoint(x: box.midX, y: box.minY), CGPoint(x: box.maxX, y: box.minY),
         CGPoint(x: box.minX, y: box.midY), CGPoint(x: box.maxX, y: box.midY),
         CGPoint(x: box.minX, y: box.maxY), CGPoint(x: box.midX, y: box.maxY), CGPoint(x: box.maxX, y: box.maxY)]
    }

    /// Which edges a point near the crop box would move (empty = not on a handle or edge).
    private func edges(at p: CGPoint, of box: CGRect) -> Edges {
        let reach: CGFloat = 7
        guard box.insetBy(dx: -reach, dy: -reach).contains(p) else { return [] }
        var e: Edges = []
        if abs(p.x - box.minX) <= reach { e.insert(.left) }
        if abs(p.x - box.maxX) <= reach { e.insert(.right) }
        if abs(p.y - box.minY) <= reach { e.insert(.top) }
        if abs(p.y - box.maxY) <= reach { e.insert(.bottom) }
        return e
    }

    // MARK: Mouse and keys

    override func mouseMoved(with event: NSEvent) {
        mouse = convert(event.locationInWindow, from: nil)
        if model.tool == .color, let mouse, imageRect.contains(mouse) {
            let p = toPixel(mouse)
            model.hoverHex = model.hex(atPixelX: Int(p.x), y: Int(p.y))
        }
        needsDisplay = true
    }

    override func mouseExited(with event: NSEvent) {
        mouse = nil
        if model.tool == .color { model.hoverHex = nil }
        needsDisplay = true
    }

    override func mouseDown(with event: NSEvent) {
        window?.makeFirstResponder(self)
        let p = convert(event.locationInWindow, from: nil)
        mouse = p
        switch model.tool {
        case .color:
            if imageRect.contains(p) {
                let px = toPixel(p)
                model.pick(atPixelX: Int(px.x), y: Int(px.y))
            }
        case .crop:
            if let crop = model.cropRect {
                let box = toView(crop)
                let e = edges(at: p, of: box)
                if !e.isEmpty {
                    drag = .resize(edges: e, original: crop)
                    return
                }
                if box.contains(p) {
                    drag = .move(grab: toPixel(p), original: crop)
                    return
                }
            }
            drag = .new(start: clampToImage(toPixel(p)))
        case .none:
            // Dragging on the image starts a crop straight away.
            if imageRect.contains(p) {
                model.tool = .crop
                drag = .new(start: clampToImage(toPixel(p)))
            }
        }
        needsDisplay = true
    }

    override func mouseDragged(with event: NSEvent) {
        let p = convert(event.locationInWindow, from: nil)
        mouse = p
        let q = clampToImage(toPixel(p))
        let w = CGFloat(image.width), h = CGFloat(image.height)
        guard let drag else { return }
        switch drag {
        case .new(let start):
            model.cropRect = CGRect(x: min(start.x, q.x), y: min(start.y, q.y),
                                    width: abs(q.x - start.x), height: abs(q.y - start.y)).integral
        case .move(let grab, let original):
            let raw = toPixel(p)
            var r = original.offsetBy(dx: raw.x - grab.x, dy: raw.y - grab.y)
            r.origin.x = min(max(r.minX, 0), w - r.width)
            r.origin.y = min(max(r.minY, 0), h - r.height)
            model.cropRect = r.integral
        case .resize(let edges, let original):
            var minX = original.minX, maxX = original.maxX, minY = original.minY, maxY = original.maxY
            if edges.contains(.left) { minX = q.x }
            if edges.contains(.right) { maxX = q.x }
            if edges.contains(.top) { minY = q.y }
            if edges.contains(.bottom) { maxY = q.y }
            model.cropRect = CGRect(x: min(minX, maxX), y: min(minY, maxY),
                                    width: abs(maxX - minX), height: abs(maxY - minY)).integral
        }
        needsDisplay = true
    }

    override func mouseUp(with event: NSEvent) {
        if case .new? = drag, let crop = model.cropRect, crop.width < 3 || crop.height < 3 {
            model.cropRect = nil  // just a click
        }
        drag = nil
        needsDisplay = true
    }

    override func keyDown(with event: NSEvent) {
        let command = event.modifierFlags.contains(.command)
        switch event.keyCode {
        case 36, 76:  // Return, Enter
            if model.tool == .crop { model.applyCrop() } else { super.keyDown(with: event) }
        case 53:      // Esc
            if model.cropRect != nil { model.cropRect = nil } else { model.tool = .none }
        case 48:      // Tab: copy the color under the pointer (like Shottr)
            if model.tool == .color, let mouse, imageRect.contains(mouse) {
                let p = toPixel(mouse)
                model.pick(atPixelX: Int(p.x), y: Int(p.y))
            }
        default:
            if command, event.charactersIgnoringModifiers == "z" {
                model.undo()
            } else if command, event.charactersIgnoringModifiers == "c" {
                ImageTools.copyToClipboard(model.shot)
            } else if command, event.charactersIgnoringModifiers == "w" {
                window?.close()
            } else {
                super.keyDown(with: event)
            }
        }
        needsDisplay = true
    }

    override func resetCursorRects() {
        switch model.tool {
        case .color, .crop: addCursorRect(imageRect, cursor: .crosshair)
        case .none: break
        }
    }
}
