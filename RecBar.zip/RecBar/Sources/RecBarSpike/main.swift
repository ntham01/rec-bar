// RecBar — Milestone 1 capture spike (round 4: 10-minute recordings)
//
// Records the main display plus system audio (no microphone) to an MP4 in
// ~/Movies for up to 10 minutes, using ScreenCaptureKit for capture and
// AVAssetWriter for H.264 + AAC encoding.
//
// What's new in rounds 2–4:
//   • Default and maximum length is 600 s (10 min). Stop early with Return or Ctrl+C.
//   • Constant frame rate: ScreenCaptureKit only sends a frame when the screen
//     changes, so a 30 fps ticker on the host clock writes the latest frame
//     (repeating it when nothing changed). Editors see true CFR.
//   • Video and audio share the host clock, and the file ends exactly on the
//     last video frame, so long clips stay in sync.
//   • After saving, the file is read back and checked (length, fps, A/V offset).
//   • Before recording, it checks there's enough free disk space for the run.
//
// Run:  swift run -c release RecBarSpike [seconds]

import AVFoundation
import CoreGraphics
import CoreMedia
import Foundation
import ScreenCaptureKit

// MARK: - Settings ("Standard" preset from the PRD)

let maxSeconds = 600.0
let requestedSeconds = Double(CommandLine.arguments.dropFirst().first ?? "") ?? maxSeconds
let seconds = min(max(requestedSeconds, 1), maxSeconds)
let fps: Int32 = 30
let targetHeight = 1080
let videoBitrate = 12_000_000
let audioBitrate = 192_000

enum SpikeError: Error, CustomStringConvertible {
    case noDisplay
    case writerSetup(String)

    var description: String {
        switch self {
        case .noDisplay: return "Couldn't find the main display."
        case .writerSetup(let detail): return "Couldn't set up the file writer: \(detail)"
        }
    }
}

/// A thread-safe "please stop" flag shared by Return, Ctrl+C and the main loop.
final class StopFlag: @unchecked Sendable {
    private let lock = NSLock()
    private var value = false
    func set() { lock.lock(); value = true; lock.unlock() }
    var isSet: Bool { lock.lock(); defer { lock.unlock() }; return value }
}

// MARK: - Recorder

final class Recorder: NSObject, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    struct Stats {
        var freshFrames = 0       // frames that were new screen content
        var repeatedFrames = 0    // frames repeated to keep a constant frame rate
        var encoderWaits = 0      // ticks where the encoder wasn't ready (caught up next tick)
        var audioBuffers = 0
        var audioDropped = 0
        var framesWritten: Int { freshFrames + repeatedFrames }
    }

    let outputURL: URL
    let outputWidth: Int
    let outputHeight: Int

    private let writer: AVAssetWriter
    private let videoInput: AVAssetWriterInput
    private let adaptor: AVAssetWriterInputPixelBufferAdaptor
    private let audioInput: AVAssetWriterInput
    private let queue = DispatchQueue(label: "recbar.capture")
    private var stream: SCStream?
    private var ticker: DispatchSourceTimer?

    // Everything below is only touched on `queue`.
    private var startTime: CMTime?
    private var latestFrame: CVPixelBuffer?
    private var latestIsFresh = false
    private var nextIndex: Int64 = 0
    private var endTime: CMTime?   // set when stop begins: video is closed, audio drains up to here
    private var stopped = false
    private var stats = Stats()
    private var streamError: Error?

    /// Call from outside `queue` only.
    var currentStats: Stats { queue.sync { stats } }
    var failure: Error? {
        queue.sync { streamError ?? (writer.status == .failed ? writer.error : nil) }
    }

    init(display: SCDisplay, outputURL: URL) throws {
        self.outputURL = outputURL

        // Keep the display's aspect ratio at 1080p; H.264 needs even dimensions.
        let aspect = Double(display.width) / Double(display.height)
        outputHeight = targetHeight
        outputWidth = Int((Double(targetHeight) * aspect / 2).rounded()) * 2

        writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
        // Write a fragment every ~2 s so a crash still leaves a playable file.
        writer.movieFragmentInterval = CMTime(seconds: 2, preferredTimescale: 600)

        videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: outputWidth,
            AVVideoHeightKey: outputHeight,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: videoBitrate,
                AVVideoExpectedSourceFrameRateKey: Int(fps),
                AVVideoMaxKeyFrameIntervalKey: Int(fps) * 2,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
            ] as [String: Any],
        ])
        videoInput.expectsMediaDataInRealTime = true

        audioInput = AVAssetWriterInput(mediaType: .audio, outputSettings: [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 48_000,
            AVNumberOfChannelsKey: 2,
            AVEncoderBitRateKey: audioBitrate,
        ])
        audioInput.expectsMediaDataInRealTime = true

        guard writer.canAdd(videoInput), writer.canAdd(audioInput) else {
            throw SpikeError.writerSetup("the writer rejected the video or audio input")
        }
        writer.add(videoInput)
        writer.add(audioInput)
        adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: videoInput, sourcePixelBufferAttributes: nil)

        super.init()

        let config = SCStreamConfiguration()
        config.width = outputWidth
        config.height = outputHeight
        config.minimumFrameInterval = CMTime(value: 1, timescale: fps)
        config.queueDepth = 8
        config.showsCursor = true
        config.pixelFormat = kCVPixelFormatType_32BGRA
        // System audio only. ScreenCaptureKit never opens the microphone here.
        config.capturesAudio = true
        config.sampleRate = 48_000
        config.channelCount = 2
        config.excludesCurrentProcessAudio = true

        let filter = SCContentFilter(display: display, excludingWindows: [])
        let scStream = SCStream(filter: filter, configuration: config, delegate: self)
        try scStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        try scStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue)
        stream = scStream
    }

    func start() async throws {
        guard writer.startWriting() else {
            throw SpikeError.writerSetup(writer.error?.localizedDescription ?? "unknown error")
        }
        try await stream?.startCapture()

        // The constant-frame-rate ticker. It runs on the same serial queue as
        // the capture callbacks, so no locking is needed.
        let timer = DispatchSource.makeTimerSource(flags: .strict, queue: queue)
        timer.schedule(deadline: .now(), repeating: .nanoseconds(Int(1_000_000_000 / fps)), leeway: .milliseconds(1))
        timer.setEventHandler { [weak self] in self?.tick() }
        timer.resume()
        ticker = timer
    }

    /// Stops capture, writes any frames still due, and finishes the file
    /// exactly on the last video frame. Returns false if nothing was recorded.
    func stop() async -> Bool {
        // 1. Close the video side at the last due frame.
        let end: CMTime? = queue.sync {
            tick()  // catch up to "now" before stopping
            ticker?.cancel()
            guard let start = startTime else {
                stopped = true
                return nil
            }
            let end = CMTimeAdd(start, CMTime(value: nextIndex, timescale: fps))
            endTime = end
            return end
        }
        // 2. Audio arrives slightly behind video, so keep accepting it (up to
        //    `end`) until capture has fully stopped, then close everything.
        try? await stream?.stopCapture()
        queue.sync { stopped = true }

        guard let end, writer.status == .writing else {
            writer.cancelWriting()
            return false
        }
        videoInput.markAsFinished()
        audioInput.markAsFinished()
        writer.endSession(atSourceTime: end)  // trims any audio past the last frame
        await writer.finishWriting()
        if writer.status != .completed {
            print("Writer failed: \(writer.error?.localizedDescription ?? "unknown error")")
            return false
        }
        return true
    }

    // MARK: Constant frame rate (runs on `queue`)

    private func tick() {
        guard !stopped, endTime == nil, let start = startTime, let frame = latestFrame,
              writer.status == .writing else { return }
        let now = CMClockGetTime(CMClockGetHostTimeClock())
        let due = Int64(CMTimeGetSeconds(CMTimeSubtract(now, start)) * Double(fps))

        // Write every frame that is due, so a late tick catches up instead of
        // leaving a gap in the timeline.
        while nextIndex <= due {
            guard videoInput.isReadyForMoreMediaData else {
                stats.encoderWaits += 1
                return  // try again next tick
            }
            let pts = CMTimeAdd(start, CMTime(value: nextIndex, timescale: fps))
            guard adaptor.append(frame, withPresentationTime: pts) else { return }
            if latestIsFresh {
                stats.freshFrames += 1
                latestIsFresh = false
            } else {
                stats.repeatedFrames += 1
            }
            nextIndex += 1
        }
    }

    // MARK: SCStreamOutput

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard !stopped, sampleBuffer.isValid, writer.status == .writing else { return }

        switch type {
        case .screen:
            // ScreenCaptureKit also sends "idle" buffers with no image when the
            // screen hasn't changed; the ticker repeats the last real frame instead.
            guard endTime == nil, Recorder.isCompleteFrame(sampleBuffer),
                  let pixels = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
            latestFrame = pixels
            latestIsFresh = true
            if startTime == nil {
                // The file starts at the first real video frame; audio before it is dropped.
                let first = sampleBuffer.presentationTimeStamp
                startTime = first
                writer.startSession(atSourceTime: first)
                tick()
            }

        case .audio:
            let pts = sampleBuffer.presentationTimeStamp
            guard let start = startTime, pts >= start else { return }
            if let endTime, pts >= endTime { return }
            if audioInput.isReadyForMoreMediaData, audioInput.append(sampleBuffer) {
                stats.audioBuffers += 1
            } else {
                stats.audioDropped += 1
            }

        default:
            return
        }
    }

    // MARK: SCStreamDelegate

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        queue.async { self.streamError = error }
    }

    private static func isCompleteFrame(_ sampleBuffer: CMSampleBuffer) -> Bool {
        guard
            let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false)
                as? [[SCStreamFrameInfo: Any]],
            let rawStatus = attachments.first?[.status] as? Int,
            let status = SCFrameStatus(rawValue: rawStatus)
        else { return false }
        return status == .complete
    }
}

// MARK: - File check

/// Reads the finished file back and prints what an editor will see.
func checkFile(_ url: URL) async {
    let asset = AVURLAsset(url: url)
    do {
        var video: CMTimeRange?
        var audio: CMTimeRange?
        var frameRate: Float = 0
        for track in try await asset.load(.tracks) {
            let range = try await track.load(.timeRange)
            if track.mediaType == .video {
                video = range
                frameRate = try await track.load(.nominalFrameRate)
            } else if track.mediaType == .audio {
                audio = range
            }
        }
        let bytes = (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64) ?? 0

        print("File check")
        print("  Size:          \(String(format: "%.1f", Double(bytes) / 1_000_000)) MB")
        guard let video else {
            print("  ✗ No video track found.")
            return
        }
        print("  Video:         \(String(format: "%.2f", video.duration.seconds)) s at \(String(format: "%.2f", frameRate)) fps")
        guard let audio else {
            print("  ✗ No audio track. Was anything playing? (Silence still makes a track — so this is a bug.)")
            return
        }
        let startOffsetMs = (audio.start.seconds - video.start.seconds) * 1000
        let lengthDiffMs = (audio.duration.seconds - video.duration.seconds) * 1000
        print("  Audio:         \(String(format: "%.2f", audio.duration.seconds)) s")
        print("  A/V start gap: \(String(format: "%+.0f", startOffsetMs)) ms")
        print("  Length diff:   \(String(format: "%+.0f", lengthDiffMs)) ms")

        let fpsOK = abs(frameRate - Float(fps)) < 0.5
        let syncOK = abs(startOffsetMs) < 50 && abs(lengthDiffMs) < 100
        print(fpsOK && syncOK
              ? "  ✓ Looks good: constant \(fps) fps and audio lines up with video."
              : "  ✗ Something's off — paste this output into the chat.")
    } catch {
        print("Couldn't read the file back: \(error.localizedDescription)")
    }
}

// MARK: - Main

func timestamp() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd HH-mm-ss"
    return formatter.string(from: Date())
}

func clock(_ t: Double) -> String {
    let s = Int(t)
    return String(format: "%d:%02d", s / 60, s % 60)
}

// Return or Ctrl+C stops the recording early and still saves the file.
let stopFlag = StopFlag()
signal(SIGINT, SIG_IGN)
let interruptSource = DispatchSource.makeSignalSource(signal: SIGINT, queue: .global())
interruptSource.setEventHandler { stopFlag.set() }
interruptSource.resume()
Thread.detachNewThread {
    if readLine() != nil { stopFlag.set() }  // nil = no keyboard attached; ignore
}

do {
    let content: SCShareableContent
    do {
        content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
    } catch {
        print("""

        Screen recording isn't allowed for Terminal yet.
        1. Open System Settings → Privacy & Security → Screen & System Audio Recording
        2. Turn on Terminal (or whichever terminal app you're using)
        3. Quit and reopen Terminal, then run this command again.

        """)
        exit(1)
    }

    let mainID = CGMainDisplayID()
    guard let display = content.displays.first(where: { $0.displayID == mainID }) ?? content.displays.first else {
        throw SpikeError.noDisplay
    }

    let movies = FileManager.default.urls(for: .moviesDirectory, in: .userDomainMask)[0]
    let url = movies.appendingPathComponent("RecBar spike \(timestamp()).mp4")

    // Free-space check: estimated file size for this run, plus a 20% margin.
    let estimatedBytes = Int64(Double(videoBitrate + audioBitrate) / 8 * seconds * 1.2)
    let free = (try? movies.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey])
        .volumeAvailableCapacityForImportantUsage) ?? nil
    if let free, free < estimatedBytes {
        print("""

        Not enough free space for a \(clock(seconds)) recording.
        Needs about \(estimatedBytes / 1_000_000) MB; \(free / 1_000_000) MB is free on the disk with your Movies folder.
        Free up some space, or record for less time, e.g. `swift run -c release RecBarSpike 60`.

        """)
        exit(1)
    }

    let recorder = try Recorder(display: display, outputURL: url)
    try await recorder.start()
    print("Recording the main display + system audio at \(recorder.outputWidth)×\(recorder.outputHeight), \(fps) fps.")
    print("Play something with sound and move a window around. Press Return or Ctrl+C to stop early.\n")

    let began = Date()
    var failure: Error?
    while !stopFlag.isSet {
        let t = Date().timeIntervalSince(began)
        if t >= seconds { break }
        if let error = recorder.failure { failure = error; break }
        print("\r● REC  \(clock(t)) / \(clock(seconds))   ", terminator: "")
        fflush(stdout)
        try await Task.sleep(nanoseconds: 250_000_000)
    }
    let recorded = Date().timeIntervalSince(began)
    print("\r■ Stopped at \(clock(recorded)). Finishing the file…")
    if let failure {
        print("Capture stopped early: \(failure.localizedDescription)")
    }

    guard await recorder.stop() else {
        print("Nothing was recorded.")
        exit(1)
    }

    let stats = recorder.currentStats
    print("""

    Saved: \(url.path)

    Frames written:   \(stats.framesWritten)  (\(stats.freshFrames) new, \(stats.repeatedFrames) repeated to keep \(fps) fps)
    Encoder waits:    \(stats.encoderWaits)
    Audio buffers:    \(stats.audioBuffers)  (dropped: \(stats.audioDropped))

    """)
    await checkFile(url)
    print("")
} catch {
    print("Error: \(error)")
    exit(1)
}
