import AppKit
import CoreGraphics
import Foundation
import ScreenCaptureKit

// MARK: - Errors

public enum RecBarError: LocalizedError, Sendable {
    case permissionDenied
    case noDisplay
    case nothingCaptured
    case writer(String)
    case file(String)

    public var errorDescription: String? {
        switch self {
        case .permissionDenied: return "Screen recording isn't allowed for Rec Bar yet."
        case .noDisplay: return "Couldn't find the main display."
        case .nothingCaptured: return "Nothing was captured."
        case .writer(let detail): return detail
        case .file(let detail): return detail
        }
    }
}

// MARK: - Recorder interface

/// One recording session. Create it, `start()`, then `stop()` to get the finished file.
public protocol Recording: AnyObject, Sendable {
    var outputURL: URL { get }
    /// Called (on a background queue) if capture or writing stops by itself,
    /// e.g. the display was unplugged or the disk filled up. Call `stop()` to keep what was recorded.
    var onUnexpectedStop: (@Sendable (Error) -> Void)? { get set }
    /// Called (on a background queue) about 20 times a second while recording,
    /// with the loudest left and right samples since the last call (0…1, linear).
    var onAudioLevel: (@Sendable (StereoLevel) -> Void)? { get set }
    func start() async throws
    func stop() async throws -> URL
}

// MARK: - File formats

public enum VideoFormat: String, CaseIterable, Identifiable, Sendable {
    /// H.264 + AAC. Small files; plays anywhere.
    case mp4
    /// ProRes 422 LT + 24-bit PCM audio. Big files; smooth to edit in Premiere / Resolve.
    case mov

    public var id: String { rawValue }
    public var fileExtension: String { rawValue }
    public var shortName: String { rawValue.uppercased() }

    public var title: String {
        switch self {
        case .mp4: return "MP4 — H.264, small files"
        case .mov: return "MOV — ProRes 422 LT, for editing"
        }
    }
}

public enum AudioFormat: String, CaseIterable, Identifiable, Sendable {
    /// 320 kbps CBR via the bundled LAME encoder.
    case mp3
    /// Uncompressed 24-bit, 48 kHz stereo.
    case wav

    public var id: String { rawValue }
    public var fileExtension: String { rawValue }
    public var shortName: String { rawValue.uppercased() }

    public var title: String {
        switch self {
        case .mp3: return "MP3 — 320 kbps"
        case .wav: return "WAV — 24-bit, uncompressed"
        }
    }
}

// MARK: - Quality presets (PRD: Low / Standard / High)

public enum QualityPreset: String, CaseIterable, Identifiable, Sendable {
    case low, standard, high

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .low: return "Low — 720p, 30 fps"
        case .standard: return "Standard — 1080p, 30 fps"
        case .high: return "High — native, 60 fps"
        }
    }

    public var fps: Int32 { self == .high ? 60 : 30 }

    public var videoBitrate: Int {
        switch self {
        case .low: return 6_000_000
        case .standard: return 12_000_000
        case .high: return 30_000_000
        }
    }

    /// Output size in pixels for a display of `points` at `scale`, keeping the
    /// display's aspect ratio, never upscaling, and staying within H.264's 4096-pixel width.
    public func outputSize(points: CGSize, scale: CGFloat) -> (width: Int, height: Int) {
        let aspect = Double(points.width / points.height)
        let nativeHeight = Double(points.height * scale)
        var height: Double
        switch self {
        case .low: height = 720
        case .standard: height = 1080
        case .high: height = nativeHeight
        }
        height = min(height, nativeHeight)
        var width = height * aspect
        if width > 4096 {
            width = 4096
            height = width / aspect
        }
        return (even(width), even(height))
    }
}

private func even(_ value: Double) -> Int { max(2, Int((value / 2).rounded()) * 2) }

// MARK: - Permission

public enum ScreenRecordingPermission {
    public static var isGranted: Bool { CGPreflightScreenCaptureAccess() }

    /// Shows the system prompt the first time; afterwards it returns the current state.
    @discardableResult
    public static func request() -> Bool { CGRequestScreenCaptureAccess() }

    /// The reliable check: actually ask ScreenCaptureKit for the screen.
    /// (`isGranted` can say "no" until the app restarts after permission is turned on.)
    /// The first time, this also shows macOS's "would like to record" prompt.
    public static func canCapture() async -> Bool {
        do {
            _ = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            return true
        } catch {
            return false
        }
    }

    public static func openSystemSettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
            NSWorkspace.shared.open(url)
        }
    }
}

// MARK: - Where files go

public enum Recordings {
    /// The Movies folder, where OBS saves by default on macOS.
    public static var moviesFolder: URL {
        FileManager.default.urls(for: .moviesDirectory, in: .userDomainMask)[0]
    }

    /// Where Rec Bar saves until you pick a folder: the folder OBS records to
    /// (read from OBS's own settings), or Movies if OBS isn't set up.
    public static var defaultFolder: URL {
        OBSSettings.recordingFolder() ?? moviesFolder
    }

    public static func isUsableFolder(_ url: URL) -> Bool {
        var isDirectory: ObjCBool = false
        return FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
            && isDirectory.boolValue
            && FileManager.default.isWritableFile(atPath: url.path)
    }

    /// "Rec Bar 2026-11-09 21-14-03.mp4", with " (2)" etc. added if that name is taken.
    public static func newFileURL(extension ext: String, in folder: URL) -> URL {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd HH-mm-ss"
        let base = "Rec Bar \(formatter.string(from: Date()))"
        var url = folder.appendingPathComponent("\(base).\(ext)")
        var n = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent("\(base) (\(n)).\(ext)")
            n += 1
        }
        return url
    }
}

// MARK: - What to capture

/// The main display, with every window belonging to Rec Bar itself left out,
/// so the box never appears in its own recordings. With `hideNotifications`,
/// Notification Center's banners are left out too.
struct CaptureTarget {
    let display: SCDisplay
    let filter: SCContentFilter
    let scale: CGFloat

    /// The app that draws notification banners (and the Notification Center panel).
    static let notificationCenterID = "com.apple.notificationcenterui"

    static func mainDisplay(hideNotifications: Bool) async throws -> CaptureTarget {
        let content: SCShareableContent
        do {
            // All apps, not just ones with windows on screen right now: a banner
            // that appears mid-recording must already be in the filter.
            content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: false)
        } catch {
            if let scError = error as? SCStreamError, scError.code == .userDeclined {
                throw RecBarError.permissionDenied
            }
            if !ScreenRecordingPermission.isGranted { throw RecBarError.permissionDenied }
            throw error
        }

        let mainID = CGMainDisplayID()
        guard let display = content.displays.first(where: { $0.displayID == mainID }) ?? content.displays.first else {
            throw RecBarError.noDisplay
        }

        let me = ProcessInfo.processInfo.processIdentifier
        let leftOut = content.applications.filter { app in
            app.processID == me || (hideNotifications && app.bundleIdentifier == notificationCenterID)
        }
        let filter = SCContentFilter(display: display, excludingApplications: leftOut, exceptingWindows: [])

        // Retina scale from the display's current mode (pixels per point).
        var scale: CGFloat = 2
        if let mode = CGDisplayCopyDisplayMode(display.displayID), mode.width > 0 {
            scale = CGFloat(mode.pixelWidth) / CGFloat(mode.width)
        }
        return CaptureTarget(display: display, filter: filter, scale: scale)
    }
}
