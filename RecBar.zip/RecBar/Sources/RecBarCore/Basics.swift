import AppKit
import CoreGraphics
import Foundation
import ScreenCaptureKit

// MARK: - Errors

public enum RecBarError: LocalizedError, Sendable {
    case permissionDenied
    case noDisplay
    case nothingCaptured
    case writer(String)
    case file(String)

    public var errorDescription: String? {
        switch self {
        case .permissionDenied: return "Screen recording isn't allowed for Rec Bar yet."
        case .noDisplay: return "Couldn't find the main display."
        case .nothingCaptured: return "Nothing was captured."
        case .writer(let detail): return detail
        case .file(let detail): return detail
        }
    }
}

// MARK: - Recorder interface

/// One recording session. Create it, `start()`, then `stop()` to get the finished file.
public protocol Recording: AnyObject, Sendable {
    var outputURL: URL { get }
    /// Called (on a background queue) if capture or writing stops by itself,
    /// e.g. the display was unplugged or the disk filled up. Call `stop()` to keep what was recorded.
    var onUnexpectedStop: (@Sendable (Error) -> Void)? { get set }
    func start() async throws
    func stop() async throws -> URL
}

// MARK: - Quality presets (PRD: Low / Standard / High)

public enum QualityPreset: String, CaseIterable, Identifiable, Sendable {
    case low, standard, high

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .low: return "Low — 720p, 30 fps"
        case .standard: return "Standard — 1080p, 30 fps"
        case .high: return "High — native, 60 fps"
        }
    }

    public var fps: Int32 { self == .high ? 60 : 30 }

    public var videoBitrate: Int {
        switch self {
        case .low: return 6_000_000
        case .standard: return 12_000_000
        case .high: return 30_000_000
        }
    }

    /// Output size in pixels for a display of `points` at `scale`, keeping the
    /// display's aspect ratio, never upscaling, and staying within H.264's 4096-pixel width.
    public func outputSize(points: CGSize, scale: CGFloat) -> (width: Int, height: Int) {
        let aspect = Double(points.width / points.height)
        let nativeHeight = Double(points.height * scale)
        var height: Double
        switch self {
        case .low: height = 720
        case .standard: height = 1080
        case .high: height = nativeHeight
        }
        height = min(height, nativeHeight)
        var width = height * aspect
        if width > 4096 {
            width = 4096
            height = width / aspect
        }
        return (even(width), even(height))
    }
}

private func even(_ value: Double) -> Int { max(2, Int((value / 2).rounded()) * 2) }

// MARK: - Permission

public enum ScreenRecordingPermission {
    public static var isGranted: Bool { CGPreflightScreenCaptureAccess() }

    /// Shows the system prompt the first time; afterwards it returns the current state.
    @discardableResult
    public static func request() -> Bool { CGRequestScreenCaptureAccess() }

    /// The reliable check: actually ask ScreenCaptureKit for the screen.
    /// (`isGranted` can say "no" until the app restarts after permission is turned on.)
    /// The first time, this also shows macOS's "would like to record" prompt.
    public static func canCapture() async -> Bool {
        do {
            _ = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
            return true
        } catch {
            return false
        }
    }

    public static func openSystemSettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
            NSWorkspace.shared.open(url)
        }
    }
}

// MARK: - Where files go

public enum Recordings {
    /// The Movies folder, where OBS saves by default on macOS.
    public static var moviesFolder: URL {
        FileManager.default.urls(for: .moviesDirectory, in: .userDomainMask)[0]
    }

    /// Where Rec Bar saves until you pick a folder: the folder OBS records to
    /// (read from OBS's own settings), or Movies if OBS isn't set up.
    public static var defaultFolder: URL {
        OBSSettings.recordingFolder() ?? moviesFolder
    }

    public static func isUsableFolder(_ url: URL) -> Bool {
        var isDirectory: ObjCBool = false
        return FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
            && isDirectory.boolValue
            && FileManager.default.isWritableFile(atPath: url.path)
    }

    /// "Rec Bar 2026-11-09 21-14-03.mp4", with " (2)" etc. added if that name is taken.
    public static func newFileURL(extension ext: String, in folder: URL) -> URL {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd HH-mm-ss"
        let base = "Rec Bar \(formatter.string(from: Date()))"
        var url = folder.appendingPathComponent("\(base).\(ext)")
        var n = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent("\(base) (\(n)).\(ext)")
            n += 1
        }
        return url
    }
}

// MARK: - What to capture

/// The main display, with every window belonging to Rec Bar itself left out,
/// so the box never appears in its own recordings.
struct CaptureTarget {
    let display: SCDisplay
    let filter: SCContentFilter
    let scale: CGFloat

    static func mainDisplay() async throws -> CaptureTarget {
        let content: SCShareableContent
        do {
            content = try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        } catch {
            if let scError = error as? SCStreamError, scError.code == .userDeclined {
                throw RecBarError.permissionDenied
            }
            if !ScreenRecordingPermission.isGranted { throw RecBarError.permissionDenied }
            throw error
        }

        let mainID = CGMainDisplayID()
        guard let display = content.displays.first(where: { $0.displayID == mainID }) ?? content.displays.first else {
            throw RecBarError.noDisplay
        }

        let me = ProcessInfo.processInfo.processIdentifier
        let ownApps = content.applications.filter { $0.processID == me }
        let filter = SCContentFilter(display: display, excludingApplications: ownApps, exceptingWindows: [])

        // Retina scale from the display's current mode (pixels per point).
        var scale: CGFloat = 2
        if let mode = CGDisplayCopyDisplayMode(display.displayID), mode.width > 0 {
            scale = CGFloat(mode.pixelWidth) / CGFloat(mode.width)
        }
        return CaptureTarget(display: display, filter: filter, scale: scale)
    }
}
