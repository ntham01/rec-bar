import AVFoundation
import CoreMedia
import Foundation
import ScreenCaptureKit

/// Audio mode: system audio only (no microphone) → .mp3 (320 kbps) or .wav (24-bit).
///
/// Audio is encoded and written to disk as it arrives, so a crash still leaves
/// a playable file.
public final class AudioRecorder: NSObject, Recording, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    public let outputURL: URL
    public var onUnexpectedStop: (@Sendable (Error) -> Void)?
    public var onAudioLevel: (@Sendable (StereoLevel) -> Void)?

    private let encoder: AudioFileEncoder
    private let queue = DispatchQueue(label: "recbar.audio")
    private var stream: SCStream?

    // Only touched on `queue`.
    private var stopped = false
    private var failure: Error?
    private var levels = LevelReporter()

    public static func make(format: AudioFormat, folder: URL, hideNotifications: Bool) async throws -> AudioRecorder {
        let target = try await CaptureTarget.mainDisplay(hideNotifications: hideNotifications)
        let url = Recordings.newFileURL(extension: format.fileExtension, in: folder)
        return try AudioRecorder(target: target, format: format, outputURL: url)
    }

    init(target: CaptureTarget, format: AudioFormat, outputURL: URL) throws {
        self.outputURL = outputURL
        switch format {
        case .mp3: encoder = try MP3Encoder(url: outputURL)
        case .wav: encoder = try WAVEncoder(url: outputURL)
        }

        super.init()

        let config = SCStreamConfiguration()
        // ScreenCaptureKit always captures a display; keep that side tiny and slow
        // (64×36 at 1 fps) and throw the frames away.
        config.width = 64
        config.height = 36
        config.minimumFrameInterval = CMTime(value: 1, timescale: 1)
        config.showsCursor = false
        config.capturesAudio = true          // system audio only; the microphone is never opened
        config.sampleRate = 48_000
        config.channelCount = 2
        config.excludesCurrentProcessAudio = true

        let scStream = SCStream(filter: target.filter, configuration: config, delegate: self)
        try scStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        try scStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue)
        stream = scStream
    }

    public func start() async throws {
        do {
            try await stream?.startCapture()
        } catch {
            queue.sync { encoder.abandon() }
            throw error
        }
    }

    public func stop() async throws -> URL {
        try? await stream?.stopCapture()
        return try queue.sync {
            stopped = true
            if let failure {
                // Everything written before the failure is already on disk and playable.
                encoder.closeQuietly()
                throw failure
            }
            try encoder.finish()
            return outputURL
        }
    }

    // MARK: SCStreamOutput (on `queue`)

    public func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, !stopped, failure == nil, sampleBuffer.isValid else { return }
        guard sampleBuffer.isFloat32PCM else {
            fail(RecBarError.writer("Unexpected audio format from macOS."))
            return
        }
        do {
            let peaks: StereoLevel = try sampleBuffer.withAudioBufferList { (buffers, _) -> StereoLevel in
                guard let pcm = PCMBuffers(buffers) else { return .silent }
                try encoder.write(pcm)
                return pcm.peaks
            }
            levels.add(peaks) { onAudioLevel?($0) }
        } catch {
            fail(error)
        }
    }

    private func fail(_ error: Error) {
        guard failure == nil else { return }
        failure = error
        onUnexpectedStop?(error)
    }

    // MARK: SCStreamDelegate

    public func stream(_ stream: SCStream, didStopWithError error: Error) {
        queue.async { self.fail(error) }
    }
}

// MARK: - Encoders

/// Writes float PCM (48 kHz stereo) to a file as it arrives.
protocol AudioFileEncoder: AnyObject {
    func write(_ pcm: PCMBuffers) throws
    /// Flush, finalise the file's header or tag, and close.
    func finish() throws
    /// Close without finalising (after a failure); what's on disk stays.
    func closeQuietly()
    /// Close and delete (capture never started).
    func abandon()
}
