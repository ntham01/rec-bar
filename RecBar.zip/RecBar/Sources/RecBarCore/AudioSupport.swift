import Accelerate
import AVFoundation
import CoreMedia
import Foundation

/// System audio from ScreenCaptureKit, as plain float samples.
/// It's normally two separate (planar) channels; the other shapes are handled just in case.
enum PCMBuffers {
    case planar(left: UnsafeMutablePointer<Float>, right: UnsafeMutablePointer<Float>, frames: Int)
    case interleaved(UnsafeMutablePointer<Float>, frames: Int)  // stereo, L R L R …
    case mono(UnsafeMutablePointer<Float>, frames: Int)

    init?(_ buffers: UnsafeMutableAudioBufferListPointer) {
        guard let first = buffers.first,
              let firstData = first.mData?.assumingMemoryBound(to: Float.self) else { return nil }
        if buffers.count >= 2, let second = buffers[1].mData?.assumingMemoryBound(to: Float.self) {
            self = .planar(left: firstData, right: second,
                           frames: Int(first.mDataByteSize) / MemoryLayout<Float>.size)
        } else if first.mNumberChannels >= 2 {
            self = .interleaved(firstData,
                                frames: Int(first.mDataByteSize) / (MemoryLayout<Float>.size * Int(first.mNumberChannels)))
        } else {
            self = .mono(firstData, frames: Int(first.mDataByteSize) / MemoryLayout<Float>.size)
        }
    }

    var frames: Int {
        switch self {
        case .planar(_, _, let frames), .interleaved(_, let frames), .mono(_, let frames): return frames
        }
    }

    /// Loudest sample on each side (absolute value, 0…1).
    var peaks: StereoLevel {
        func maxMagnitude(_ pointer: UnsafeMutablePointer<Float>, stride: Int, _ count: Int) -> Float {
            guard count > 0 else { return 0 }
            var result: Float = 0
            vDSP_maxmgv(pointer, vDSP_Stride(stride), &result, vDSP_Length(count))
            return result
        }
        switch self {
        case .planar(let left, let right, let frames):
            return StereoLevel(left: maxMagnitude(left, stride: 1, frames), right: maxMagnitude(right, stride: 1, frames))
        case .interleaved(let samples, let frames):
            return StereoLevel(left: maxMagnitude(samples, stride: 2, frames),
                               right: maxMagnitude(samples + 1, stride: 2, frames))
        case .mono(let samples, let frames):
            let peak = maxMagnitude(samples, stride: 1, frames)
            return StereoLevel(left: peak, right: peak)
        }
    }

    /// Left / right sample `i` (mono plays on both sides).
    @inline(__always)
    func sample(_ i: Int) -> (Float, Float) {
        switch self {
        case .planar(let left, let right, _): return (left[i], right[i])
        case .interleaved(let samples, _): return (samples[2 * i], samples[2 * i + 1])
        case .mono(let samples, _): return (samples[i], samples[i])
        }
    }
}

extension CMSampleBuffer {
    /// True for 32-bit float PCM, the format ScreenCaptureKit sends.
    var isFloat32PCM: Bool {
        guard let format = formatDescription?.audioStreamBasicDescription else { return false }
        return format.mFormatID == kAudioFormatLinearPCM
            && format.mFormatFlags & kAudioFormatFlagIsFloat != 0
            && format.mBitsPerChannel == 32
    }
}

/// Left and right levels, 0…1.
public struct StereoLevel: Equatable, Sendable {
    public var left: Float
    public var right: Float

    public init(left: Float, right: Float) {
        self.left = left
        self.right = right
    }

    public static let silent = StereoLevel(left: 0, right: 0)
}

/// Collects peaks and passes on the loudest per side about 20 times a second,
/// so the meter in the box moves smoothly without redrawing for every buffer.
struct LevelReporter {
    private var pending = StereoLevel.silent
    private var lastReport: UInt64 = 0

    mutating func add(_ peaks: StereoLevel, report: (StereoLevel) -> Void) {
        pending.left = max(pending.left, peaks.left)
        pending.right = max(pending.right, peaks.right)
        let now = DispatchTime.now().uptimeNanoseconds
        if now - lastReport >= 50_000_000 {
            report(pending)
            pending = .silent
            lastReport = now
        }
    }
}
