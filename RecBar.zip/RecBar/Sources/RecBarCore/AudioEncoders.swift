import CLame
import Foundation

// MARK: - MP3 (LAME 3.100, 320 kbps CBR, 48 kHz stereo)

/// macOS has no built-in MP3 encoder, so this uses the bundled LAME.
/// On finish, LAME's info tag goes at the start of the file so players trim
/// the encoder padding and show the exact length.
final class MP3Encoder: AudioFileEncoder {
    private let url: URL
    private let lame: OpaquePointer
    private let file: FileHandle
    private var buffer = [UInt8](repeating: 0, count: 16_384)
    private var closed = false

    init(url: URL) throws {
        self.url = url
        guard let encoder = lame_init() else {
            throw RecBarError.writer("Couldn't start the MP3 encoder.")
        }
        lame_set_in_samplerate(encoder, 48_000)
        lame_set_out_samplerate(encoder, 48_000)
        lame_set_num_channels(encoder, 2)
        lame_set_VBR(encoder, vbr_off)
        lame_set_brate(encoder, 320)
        lame_set_quality(encoder, 2)        // 2 = near-best quality, still fast on Apple Silicon
        lame_set_bWriteVbrTag(encoder, 1)   // reserve the first frame for the info tag
        guard lame_init_params(encoder) >= 0 else {
            lame_close(encoder)
            throw RecBarError.writer("Couldn't configure the MP3 encoder.")
        }
        guard FileManager.default.createFile(atPath: url.path, contents: nil),
              let handle = try? FileHandle(forWritingTo: url) else {
            lame_close(encoder)
            throw RecBarError.file("Couldn't create \(url.lastPathComponent).")
        }
        lame = encoder
        file = handle
    }

    deinit {
        if !closed { lame_close(lame) }
    }

    func write(_ pcm: PCMBuffers) throws {
        let frames = pcm.frames
        guard frames > 0 else { return }
        // LAME's worst case for one call: 1.25 × samples + 7200 bytes.
        let needed = frames + frames / 4 + 7_200
        if buffer.count < needed { buffer = [UInt8](repeating: 0, count: needed) }

        let encoded: Int32 = buffer.withUnsafeMutableBufferPointer { (out) -> Int32 in
            switch pcm {
            case .planar(let left, let right, _):
                return lame_encode_buffer_ieee_float(lame, left, right, Int32(frames), out.baseAddress, Int32(out.count))
            case .interleaved(let samples, _):
                return lame_encode_buffer_interleaved_ieee_float(lame, samples, Int32(frames), out.baseAddress, Int32(out.count))
            case .mono(let samples, _):
                return lame_encode_buffer_ieee_float(lame, samples, samples, Int32(frames), out.baseAddress, Int32(out.count))
            }
        }
        guard encoded >= 0 else { throw RecBarError.writer("MP3 encoder error \(encoded).") }
        if encoded > 0 {
            try file.write(contentsOf: Data(buffer[0..<Int(encoded)]))
        }
    }

    func finish() throws {
        defer { close() }
        let flushed = buffer.withUnsafeMutableBufferPointer { out in
            lame_encode_flush(lame, out.baseAddress, Int32(out.count))
        }
        if flushed > 0 {
            try file.write(contentsOf: Data(buffer[0..<Int(flushed)]))
        }
        var tag = [UInt8](repeating: 0, count: 2_880)
        let tagSize = tag.withUnsafeMutableBufferPointer { out in
            lame_get_lametag_frame(lame, out.baseAddress, out.count)
        }
        if tagSize > 0 && tagSize <= tag.count {
            try file.seek(toOffset: 0)
            try file.write(contentsOf: Data(tag[0..<tagSize]))
        }
    }

    func closeQuietly() { close() }

    func abandon() {
        close()
        try? FileManager.default.removeItem(at: url)
    }

    private func close() {
        guard !closed else { return }
        closed = true
        lame_close(lame)
        try? file.close()
    }
}

// MARK: - WAV (24-bit PCM, 48 kHz stereo)

/// Uncompressed WAV. The header's length fields are refreshed every ~2 s, so a
/// crash still leaves a file that opens with (nearly) everything in it.
final class WAVEncoder: AudioFileEncoder {
    static let sampleRate = 48_000
    static let channels = 2
    static let bytesPerSample = 3
    static let bytesPerFrame = channels * bytesPerSample          // 6
    private static let headerRefreshBytes = sampleRate * bytesPerFrame * 2  // every ~2 s

    private let url: URL
    private let file: FileHandle
    private var scratch: [UInt8] = []
    private var dataBytes: UInt64 = 0
    private var bytesSinceHeader = 0
    private var closed = false

    init(url: URL) throws {
        self.url = url
        guard FileManager.default.createFile(atPath: url.path, contents: Self.header(dataBytes: 0)),
              let handle = try? FileHandle(forWritingTo: url) else {
            throw RecBarError.file("Couldn't create \(url.lastPathComponent).")
        }
        file = handle
        try file.seekToEnd()
    }

    func write(_ pcm: PCMBuffers) throws {
        let frames = pcm.frames
        guard frames > 0 else { return }
        let byteCount = frames * Self.bytesPerFrame
        if scratch.count < byteCount { scratch = [UInt8](repeating: 0, count: byteCount) }

        scratch.withUnsafeMutableBufferPointer { out in
            var o = 0
            for i in 0..<frames {
                let (l, r) = pcm.sample(i)
                Self.put24(l, into: out, at: o)
                Self.put24(r, into: out, at: o + 3)
                o += Self.bytesPerFrame
            }
        }
        try file.write(contentsOf: Data(scratch[0..<byteCount]))
        dataBytes += UInt64(byteCount)
        bytesSinceHeader += byteCount
        if bytesSinceHeader >= Self.headerRefreshBytes {
            try refreshHeader()
            bytesSinceHeader = 0
        }
    }

    func finish() throws {
        defer { close() }
        try refreshHeader()
    }

    func closeQuietly() {
        try? refreshHeader()
        close()
    }

    func abandon() {
        close()
        try? FileManager.default.removeItem(at: url)
    }

    private func close() {
        guard !closed else { return }
        closed = true
        try? file.close()
    }

    private func refreshHeader() throws {
        try file.seek(toOffset: 0)
        try file.write(contentsOf: Self.header(dataBytes: dataBytes))
        try file.seekToEnd()
    }

    /// Float −1…1 → signed 24-bit little-endian.
    @inline(__always)
    private static func put24(_ sample: Float, into out: UnsafeMutableBufferPointer<UInt8>, at index: Int) {
        let clamped = max(-1, min(1, sample))
        let value = Int32((clamped * 8_388_607).rounded())
        out[index] = UInt8(truncatingIfNeeded: value)
        out[index + 1] = UInt8(truncatingIfNeeded: value >> 8)
        out[index + 2] = UInt8(truncatingIfNeeded: value >> 16)
    }

    /// The standard 44-byte RIFF/WAVE header for 24-bit PCM, 48 kHz stereo.
    static func header(dataBytes: UInt64) -> Data {
        let data = UInt32(clamping: dataBytes)
        let riff = UInt32(clamping: UInt64(data) + 36)
        var h = Data()
        func text(_ s: String) { h.append(contentsOf: Array(s.utf8)) }
        func u32(_ v: UInt32) { withUnsafeBytes(of: v.littleEndian) { h.append(contentsOf: $0) } }
        func u16(_ v: UInt16) { withUnsafeBytes(of: v.littleEndian) { h.append(contentsOf: $0) } }
        text("RIFF"); u32(riff); text("WAVE")
        text("fmt "); u32(16)
        u16(1)                                            // PCM
        u16(UInt16(channels))
        u32(UInt32(sampleRate))
        u32(UInt32(sampleRate * bytesPerFrame))           // bytes per second
        u16(UInt16(bytesPerFrame))                        // block align
        u16(UInt16(bytesPerSample * 8))                   // bits per sample
        text("data"); u32(data)
        return h
    }
}
