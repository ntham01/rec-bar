import CoreGraphics
import Foundation

/// One frame as RGBA bytes, rows top to bottom.
public struct RGBAFrame: Sendable {
    public let width: Int
    public let height: Int
    public var bytes: [UInt8]   // width × height × 4

    public init?(_ image: CGImage, colorSpace: CGColorSpace) {
        let w = image.width, h = image.height
        guard w > 0, h > 0 else { return nil }
        var buffer = [UInt8](repeating: 0, count: w * h * 4)
        let drawn = buffer.withUnsafeMutableBytes { raw -> Bool in
            guard let context = CGContext(
                data: raw.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w * 4,
                space: colorSpace, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
            ) else { return false }
            context.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard drawn else { return nil }
        width = w
        height = h
        bytes = buffer
    }
}

public enum StitchResult: Equatable, Sendable {
    case appended(rows: Int)
    case noMovement
    case movedUp
    case lost        // no overlap found: scrolled too far between two frames
    case full        // reached the maximum height
}

/// Joins frames of a scrolling area into one tall image.
///
/// How a new frame is matched to the previous one:
/// 1. Exact: every row gets a hash (the right edge is left out, since scrollbars
///    move while scrolling). Runs of 8 rows that appear once in both frames vote
///    for how far the content moved; the winning shift is then checked against
///    the whole overlap.
/// 2. Fuzzy, if that fails (content that doesn't move by whole pixels): each row
///    becomes 32 brightness averages, and the shift with the smallest difference wins.
///
/// Rows that stay put while the content moves (sticky headers and footers) are
/// detected and kept only once. Tested against real Retina browser frames.
final class ScrollStitcher {
    static let window = 8
    static let fuzzySame: Float = 2.0

    let width: Int
    let height: Int
    let maxHeight: Int
    let colorSpace: CGColorSpace
    let hashedBytes: Int
    private let hashedPixels: Int
    private let minOverlap: Int

    private let first: RGBAFrame
    private var previous: RGBAFrame
    private var previousStrips: [[UInt64]]
    /// What the last `add` saw, for troubleshooting.
    private(set) var lastDetail = ""
    private var previousSignatures: [Float]?
    private var bottomBand: Int?
    private var content: [UInt8] = []
    private(set) var totalHeight: Int

    init(first: RGBAFrame, colorSpace: CGColorSpace, maxHeight: Int = 30_000) {
        width = first.width
        height = first.height
        self.maxHeight = maxHeight
        self.colorSpace = colorSpace
        let edge = min(48, first.width / 8)
        hashedPixels = max(1, first.width - edge)
        hashedBytes = hashedPixels * 4
        minOverlap = max(16, first.height / 10)
        self.first = first
        previous = first
        totalHeight = first.height
        previousStrips = []
        previousStrips = stripHashes(first)
    }

    // MARK: Adding frames

    func add(_ frame: RGBAFrame) -> StitchResult {
        guard frame.width == width, frame.height == height else { return .lost }
        if totalHeight >= maxHeight { return .full }

        // The width is cut into vertical strips that are matched separately, so
        // parts that stay put while the page scrolls (a sidebar, a fixed panel)
        // don't stop the moving part from being lined up.
        let stripsA = previousStrips
        let stripsB = stripHashes(frame)
        if stripsA == stripsB {
            lastDetail = "identical"
            return .noMovement
        }

        // Exact match first; if it finds nothing, or its answer doesn't hold up
        // against the whole overlap, fall back to the fuzzy match.
        let cap = Int(Double(height) * 0.3)
        var matched: (shift: Int, top: Int, bottom: Int)?
        var votes: [Int: Int] = [:]
        var shiftOf = [Int?](repeating: nil, count: stripsA.count)
        var changed = 0
        for k in 0..<stripsA.count where stripsA[k] != stripsB[k] {
            changed += 1
            if let s = exactShift(stripsA[k], stripsB[k]) {
                shiftOf[k] = s
                votes[s, default: 0] += 1
            }
        }
        lastDetail = "strips changed \(changed)/\(stripsA.count), shifts \(votes)"
        if let winner = votes.max(by: { $0.value < $1.value }) {
            let s = winner.key
            if s < 0 { return .movedUp }
            if s > 0 {
                // Strips that agree (give or take a pixel: some apps draw layers
                // a fraction of a pixel apart).
                let active = (0..<stripsA.count).filter { shiftOf[$0] == s }
                let agreeing = (0..<stripsA.count).filter { k in
                    guard let other = shiftOf[k] else { return false }
                    return abs(other - s) <= 1
                }.count
                let voting = votes.values.reduce(0, +)
                let hashesA = combined(stripsA, active)
                let hashesB = combined(stripsB, active)
                let bands = staticBands(hashesA, hashesB, shift: s)
                let band = bottomBand ?? min(bands.bottom, cap)
                if overlapIsGood(hashesA, hashesB, shift: s, top: bands.top, bottom: band) {
                    matched = (s, bands.top, band)
                } else if agreeing >= 2, agreeing * 5 >= voting * 3, height - band - s - bands.top >= minOverlap {
                    // Several strips found the same shift independently. That's
                    // solid even when most rows aren't pixel-identical (text that
                    // is redrawn slightly differently, animations, hover effects).
                    matched = (s, bands.top, band)
                    lastDetail += ", accepted on votes"
                } else {
                    lastDetail += ", overlap check failed"
                }
            }
        }
        if matched == nil {
            let sigA = previousSignatures ?? signatures(previous)
            previousSignatures = sigA
            let sigB = signatures(frame)
            // Only the columns that changed take part (the rest is static or blank).
            let moving = movingBins(sigA, sigB)
            lastDetail += ", fuzzy on \(moving.count)/\(Self.bins) columns"
            if moving.isEmpty || meanDifference(sigA, sigB, moving) < Self.fuzzySame { return .noMovement }
            guard let match = fuzzyShift(sigA, sigB, moving) else {
                // No match downwards: scrolled up, or too far in one go.
                return fuzzyShift(sigB, sigA, moving) != nil ? .movedUp : .lost
            }
            matched = (match.shift, match.top, bottomBand ?? min(match.bottom, cap))
        }
        guard let found = matched else { return .lost }
        let shift = found.shift
        let top = found.top
        if bottomBand == nil { bottomBand = found.bottom }
        let b = bottomBand ?? 0
        if height - b - shift < top { return .lost }

        // New content: the `shift` rows just above the bottom band.
        var rows = shift
        if totalHeight + rows > maxHeight { rows = max(0, maxHeight - totalHeight) }
        let rowBytes = width * 4
        let startRow = height - b - shift
        content.append(contentsOf: frame.bytes[(startRow * rowBytes)..<((startRow + rows) * rowBytes)])
        totalHeight += rows

        previous = frame
        previousStrips = stripsB
        previousSignatures = nil
        return rows > 0 ? .appended(rows: rows) : .full
    }

    /// The stitched image: the first frame (minus its bottom band), everything
    /// added since, then the last frame's bottom band (e.g. a sticky footer) once.
    func makeImage() -> CGImage? {
        let b = bottomBand ?? 0
        let rowBytes = width * 4
        var bytes = [UInt8]()
        bytes.reserveCapacity(totalHeight * rowBytes)
        bytes.append(contentsOf: first.bytes[0..<((height - b) * rowBytes)])
        bytes.append(contentsOf: content)
        bytes.append(contentsOf: previous.bytes[((height - b) * rowBytes)..<(height * rowBytes)])
        let rows = bytes.count / rowBytes

        guard let provider = CGDataProvider(data: Data(bytes) as CFData) else { return nil }
        return CGImage(
            width: width, height: rows, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: rowBytes,
            space: colorSpace, bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
            provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent
        )
    }

    // MARK: Exact matching

    static let stripCount = 8

    /// Row hashes for each vertical strip of the (non-scrollbar) width.
    private func stripHashes(_ frame: RGBAFrame) -> [[UInt64]] {
        let stripPixels = hashedPixels / Self.stripCount
        guard stripPixels >= 16 else { return [Self.rowHashes(frame, hashedBytes: hashedBytes)] }
        return (0..<Self.stripCount).map { k in
            Self.rowHashes(frame, fromByte: k * stripPixels * 4, hashedBytes: stripPixels * 4)
        }
    }

    /// One hash per row from the chosen strips together.
    private func combined(_ strips: [[UInt64]], _ chosen: [Int]) -> [UInt64] {
        var result = [UInt64](repeating: 0xcbf2_9ce4_8422_2325, count: height)
        for k in chosen {
            let strip = strips[k]
            for y in 0..<height {
                var h = (result[y] ^ strip[y]) &* 0x9E37_79B9_7F4A_7C15
                h ^= h >> 31
                result[y] = h
            }
        }
        return result
    }

    static func rowHashes(_ frame: RGBAFrame, fromByte: Int = 0, hashedBytes: Int) -> [UInt64] {
        var hashes = [UInt64](repeating: 0, count: frame.height)
        let rowBytes = frame.width * 4
        let count = max(0, min(hashedBytes, rowBytes - fromByte))
        frame.bytes.withUnsafeBytes { raw in
            for y in 0..<frame.height {
                let start = y * rowBytes + fromByte
                var h: UInt64 = 0xcbf2_9ce4_8422_2325
                var offset = 0
                while offset + 8 <= count {
                    let word = raw.loadUnaligned(fromByteOffset: start + offset, as: UInt64.self)
                    h = (h ^ word) &* 0x9E37_79B9_7F4A_7C15
                    h ^= h >> 32
                    offset += 8
                }
                while offset < count {
                    h = (h ^ UInt64(raw[start + offset])) &* 0x0000_0100_0000_01B3
                    offset += 1
                }
                hashes[y] = h
            }
        }
        return hashes
    }

    /// One key per run of `window` consecutive rows.
    private func windowKeys(_ hashes: [UInt64]) -> [UInt64] {
        let n = hashes.count - Self.window + 1
        guard n > 0 else { return [] }
        var keys = [UInt64](repeating: 0, count: n)
        for i in 0..<n {
            var k: UInt64 = 0x84222325_cbf29ce4
            for j in 0..<Self.window {
                k = (k ^ hashes[i + j]) &* 0x0000_0100_0000_01B3
                k ^= k >> 29
            }
            keys[i] = k
        }
        return keys
    }

    private func exactShift(_ hashesA: [UInt64], _ hashesB: [UInt64]) -> Int? {
        let keysA = windowKeys(hashesA)
        let keysB = windowKeys(hashesB)
        guard !keysA.isEmpty else { return nil }

        var countA: [UInt64: Int] = [:]
        var positionA: [UInt64: Int] = [:]
        countA.reserveCapacity(keysA.count)
        positionA.reserveCapacity(keysA.count)
        for (i, key) in keysA.enumerated() {
            countA[key, default: 0] += 1
            positionA[key] = i
        }
        var countB: [UInt64: Int] = [:]
        countB.reserveCapacity(keysB.count)
        for key in keysB { countB[key, default: 0] += 1 }

        var votes: [Int: Int] = [:]
        var voters = 0
        for (i, key) in keysB.enumerated() {
            if keysA[i] == key { continue }                       // same at the same place
            guard countB[key] == 1, countA[key] == 1, let j = positionA[key] else { continue }
            voters += 1
            votes[j - i, default: 0] += 1
        }
        guard let winner = votes.max(by: { $0.value < $1.value }) else { return nil }
        guard winner.value >= 3, Double(winner.value) >= Double(voters) * 0.3 else { return nil }
        return winner.key
    }

    /// Leading / trailing rows that are the same at the same place and don't
    /// match the scrolled content: sticky headers and footers.
    private func staticBands(_ hashesA: [UInt64], _ hashesB: [UInt64], shift s: Int) -> (top: Int, bottom: Int) {
        func isStatic(_ i: Int) -> Bool {
            let moved = i + s >= 0 && i + s < height && hashesB[i] == hashesA[i + s]
            return hashesA[i] == hashesB[i] && !moved
        }
        var top = 0
        while top < height && isStatic(top) { top += 1 }
        var bottom = 0
        while bottom < height - top && isStatic(height - 1 - bottom) { bottom += 1 }
        return (top, bottom)
    }

    private func overlapIsGood(_ hashesA: [UInt64], _ hashesB: [UInt64], shift s: Int, top: Int, bottom: Int) -> Bool {
        let end = height - bottom - s
        guard end - top >= minOverlap else { return false }
        var same = 0
        for i in top..<end where hashesB[i] == hashesA[i + s] { same += 1 }
        return Double(same) >= 0.5 * Double(end - top)
    }

    // MARK: Fuzzy matching

    private static let bins = 32

    /// Per row: 32 brightness averages across the (non-scrollbar) width.
    private func signatures(_ frame: RGBAFrame) -> [Float] {
        let bins = Self.bins
        var sums = [Float](repeating: 0, count: height * bins)
        var counts = [Float](repeating: 0, count: bins)
        var binOf = [Int](repeating: 0, count: hashedPixels)
        for x in 0..<hashedPixels {
            let bin = min(bins - 1, x * bins / hashedPixels)
            binOf[x] = bin
            counts[bin] += 1
        }
        let rowBytes = width * 4
        frame.bytes.withUnsafeBufferPointer { px in
            for y in 0..<height {
                let row = y * rowBytes
                let out = y * bins
                for x in 0..<hashedPixels {
                    let p = row + x * 4
                    let lum = 0.299 * Float(px[p]) + 0.587 * Float(px[p + 1]) + 0.114 * Float(px[p + 2])
                    sums[out + binOf[x]] += lum
                }
            }
        }
        for y in 0..<height {
            for b in 0..<bins where counts[b] > 0 { sums[y * bins + b] /= counts[b] }
        }
        return sums
    }

    /// Mean absolute difference between row `i` of `a` and row `j` of `b`.
    @inline(__always)
    private func rowDifference(_ a: [Float], _ i: Int, _ b: [Float], _ j: Int, _ columns: [Int]) -> Float {
        var d: Float = 0
        let ai = i * Self.bins, bj = j * Self.bins
        for k in columns { d += abs(a[ai + k] - b[bj + k]) }
        return d / Float(columns.count)
    }

    private func meanDifference(_ a: [Float], _ b: [Float], _ columns: [Int]) -> Float {
        var total: Float = 0
        for y in 0..<height { total += rowDifference(a, y, b, y, columns) }
        return total / Float(height)
    }

    /// The brightness columns that differ between two frames. Columns that
    /// look the same in both (a sidebar, blank margins) are left out of matching.
    private func movingBins(_ a: [Float], _ b: [Float]) -> [Int] {
        var result: [Int] = []
        for k in 0..<Self.bins {
            var total: Float = 0
            for y in 0..<height { total += abs(a[y * Self.bins + k] - b[y * Self.bins + k]) }
            if total / Float(height) >= 0.5 { result.append(k) }
        }
        return result
    }

    /// Shift that makes `b` (the new frame) line up with `a` (the previous one).
    private func fuzzyShift(_ a: [Float], _ b: [Float], _ columns: [Int]) -> (shift: Int, top: Int, bottom: Int)? {
        // Sticky bars look the same at the same place; leave them out of the score.
        var top = 0
        while top < height && rowDifference(a, top, b, top, columns) < Self.fuzzySame { top += 1 }
        var bottom = 0
        while bottom < height - top && rowDifference(a, height - 1 - bottom, b, height - 1 - bottom, columns) < Self.fuzzySame {
            bottom += 1
        }
        let cap = Int(Double(height) * 0.3)
        top = min(top, cap)
        bottom = min(bottom, cap)

        let maxShift = height - top - bottom - minOverlap
        guard maxShift >= 1 else { return nil }
        var best = Float.greatestFiniteMagnitude
        var bestShift = 0
        for s in 1...maxShift {
            var total: Float = 0
            let end = height - bottom - s
            for i in top..<end { total += rowDifference(b, i, a, i + s, columns) }
            let d = total / Float(end - top)
            if d < best {
                best = d
                bestShift = s
            }
        }
        var same: Float = 0
        for i in top..<(height - bottom) { same += rowDifference(b, i, a, i, columns) }
        let d0 = same / Float(max(1, height - bottom - top))
        guard best < 3.0, best < d0 * 0.5 else { return nil }
        return (bestShift, top, bottom)
    }
}

/// Runs the stitcher off the main thread during a scrolling capture.
public actor StitchWorker {
    private var stitcher: ScrollStitcher?
    private var colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!

    public init() {}

    /// The first frame. Returns false if it couldn't be read.
    public func start(_ image: CGImage, maxHeight: Int = 30_000) -> Bool {
        colorSpace = image.colorSpace ?? colorSpace
        guard let frame = RGBAFrame(image, colorSpace: colorSpace) ?? fallbackFrame(image) else { return false }
        stitcher = ScrollStitcher(first: frame, colorSpace: colorSpace, maxHeight: maxHeight)
        return true
    }

    public func add(_ image: CGImage) -> StitchResult {
        guard let stitcher, let frame = RGBAFrame(image, colorSpace: colorSpace) else { return .lost }
        return stitcher.add(frame)
    }

    // Staging: lets the capture loop wait until the page has stopped moving
    // (two captures in a row look the same) before a frame is joined on.
    private var staged: RGBAFrame?
    private var stagedHashes: [UInt64]?

    /// Holds a frame for `addStaged`. Returns true if it looks the same as the frame staged before it.
    public func stage(_ image: CGImage) -> Bool {
        guard let stitcher, let frame = RGBAFrame(image, colorSpace: colorSpace) else { return false }
        let hashes = ScrollStitcher.rowHashes(frame, hashedBytes: stitcher.hashedBytes)
        let same = stagedHashes == hashes
        staged = frame
        stagedHashes = hashes
        return same
    }

    /// Joins the staged frame on.
    public func addStaged() -> StitchResult {
        guard let stitcher, let frame = staged else { return .lost }
        staged = nil
        stagedHashes = nil
        return stitcher.add(frame)
    }

    public var height: Int { stitcher?.totalHeight ?? 0 }

    /// What the last joined frame looked like to the matcher (for troubleshooting).
    public var detail: String { stitcher?.lastDetail ?? "" }

    public func makeImage() -> CGImage? { stitcher?.makeImage() }

    /// If the display's color space can't back a bitmap, fall back to sRGB.
    private func fallbackFrame(_ image: CGImage) -> RGBAFrame? {
        colorSpace = CGColorSpace(name: CGColorSpace.sRGB)!
        return RGBAFrame(image, colorSpace: colorSpace)
    }
}
