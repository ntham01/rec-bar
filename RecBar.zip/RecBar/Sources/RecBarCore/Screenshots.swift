import AppKit
import Foundation
import ScreenCaptureKit
import Vision

/// A captured image plus its Retina scale (pixels per point), so pasted and
/// saved screenshots show at their real on-screen size.
public struct Screenshot: @unchecked Sendable {
    public var image: CGImage
    public var scale: CGFloat

    public init(image: CGImage, scale: CGFloat) {
        self.image = image
        self.scale = scale
    }

    public var pixelSize: CGSize { CGSize(width: image.width, height: image.height) }
    public var pointSize: CGSize { CGSize(width: CGFloat(image.width) / scale, height: CGFloat(image.height) / scale) }
    public var nsImage: NSImage { NSImage(cgImage: image, size: pointSize) }
}

/// One whole display, captured.
public struct DisplayCapture: @unchecked Sendable {
    public let displayID: CGDirectDisplayID
    public let image: CGImage
    public let scale: CGFloat
}

/// Taking screenshots with ScreenCaptureKit. Rec Bar's own windows (the box,
/// previews, the selection overlay) are always left out.
public enum ScreenGrabber {
    /// Every display, as it is right now. Used to freeze the screen for selection.
    public static func captureAllDisplays() async throws -> [DisplayCapture] {
        let content = try await shareableContent()
        let excluded = ownApplications(in: content)
        var shots: [DisplayCapture] = []
        for display in content.displays {
            let filter = SCContentFilter(display: display, excludingApplications: excluded, exceptingWindows: [])
            let scale = CGFloat(filter.pointPixelScale)
            let config = SCStreamConfiguration()
            config.width = Int((CGFloat(display.width) * scale).rounded())
            config.height = Int((CGFloat(display.height) * scale).rounded())
            config.showsCursor = false
            config.captureResolution = .best
            let image = try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
            shots.append(DisplayCapture(displayID: display.displayID, image: image, scale: scale))
        }
        return shots
    }

    /// A reusable capturer for one area of one display (used by scrolling capture).
    public static func regionCapturer(displayID: CGDirectDisplayID, rectInPoints: CGRect) async throws -> RegionCapturer {
        let content = try await shareableContent()
        guard let display = content.displays.first(where: { $0.displayID == displayID }) else {
            throw RecBarError.noDisplay
        }
        let filter = SCContentFilter(display: display, excludingApplications: ownApplications(in: content), exceptingWindows: [])
        let scale = CGFloat(filter.pointPixelScale)
        let config = SCStreamConfiguration()
        config.sourceRect = rectInPoints
        config.width = Int((rectInPoints.width * scale).rounded())
        config.height = Int((rectInPoints.height * scale).rounded())
        config.showsCursor = false
        config.captureResolution = .best
        return RegionCapturer(filter: filter, config: config, scale: scale)
    }

    private static func shareableContent() async throws -> SCShareableContent {
        do {
            return try await SCShareableContent.excludingDesktopWindows(false, onScreenWindowsOnly: true)
        } catch {
            if !(await ScreenRecordingPermission.canCapture()) { throw RecBarError.permissionDenied }
            throw error
        }
    }

    private static func ownApplications(in content: SCShareableContent) -> [SCRunningApplication] {
        let me = ProcessInfo.processInfo.processIdentifier
        return content.applications.filter { $0.processID == me }
    }
}

public final class RegionCapturer: @unchecked Sendable {
    let filter: SCContentFilter
    let config: SCStreamConfiguration
    public let scale: CGFloat

    init(filter: SCContentFilter, config: SCStreamConfiguration, scale: CGFloat) {
        self.filter = filter
        self.config = config
        self.scale = scale
    }

    public func capture() async throws -> CGImage {
        try await SCScreenshotManager.captureImage(contentFilter: filter, configuration: config)
    }
}

// MARK: - Image helpers

public enum ImageTools {
    /// PNG data, tagged with the right DPI (144 for Retina) so apps show it at point size.
    public static func pngData(_ shot: Screenshot) -> Data? {
        let rep = NSBitmapImageRep(cgImage: shot.image)
        rep.size = shot.pointSize
        return rep.representation(using: .png, properties: [:])
    }

    /// Puts the screenshot on the clipboard as PNG (and TIFF, for older apps).
    @MainActor
    public static func copyToClipboard(_ shot: Screenshot) {
        let rep = NSBitmapImageRep(cgImage: shot.image)
        rep.size = shot.pointSize
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        let item = NSPasteboardItem()
        if let png = rep.representation(using: .png, properties: [:]) { item.setData(png, forType: .png) }
        if let tiff = rep.tiffRepresentation { item.setData(tiff, forType: .tiff) }
        pasteboard.writeObjects([item])
    }

    @MainActor
    public static func copyToClipboard(text: String) {
        let pasteboard = NSPasteboard.general
        pasteboard.clearContents()
        pasteboard.setString(text, forType: .string)
    }

    /// Saves as "Screenshot 2026-11-10 at 19.21.04.png" in `folder`.
    public static func save(_ shot: Screenshot, in folder: URL) throws -> URL {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        let base = "Screenshot \(formatter.string(from: Date()))"
        var url = folder.appendingPathComponent("\(base).png")
        var n = 2
        while FileManager.default.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent("\(base) (\(n)).png")
            n += 1
        }
        guard let data = pngData(shot) else { throw RecBarError.file("Couldn't encode the screenshot.") }
        try data.write(to: url, options: .atomic)
        return url
    }

    /// A temporary PNG for dragging the screenshot into other apps.
    public static func temporaryFile(_ shot: Screenshot) -> URL? {
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("Rec Bar Screenshots", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd 'at' HH.mm.ss"
        let url = dir.appendingPathComponent("Screenshot \(formatter.string(from: Date())).png")
        guard let data = pngData(shot), (try? data.write(to: url, options: .atomic)) != nil else { return nil }
        return url
    }

    public static func crop(_ image: CGImage, toPixels rect: CGRect) -> CGImage? {
        let bounds = CGRect(x: 0, y: 0, width: image.width, height: image.height)
        let r = rect.integral.intersection(bounds)
        guard r.width >= 1, r.height >= 1 else { return nil }
        return image.cropping(to: r)
    }

    /// Rotates by 90°, clockwise or counter-clockwise.
    public static func rotate(_ image: CGImage, clockwise: Bool) -> CGImage? {
        let w = image.width, h = image.height
        let space = image.colorSpace ?? CGColorSpace(name: CGColorSpace.sRGB)!
        guard let context = CGContext(
            data: nil, width: h, height: w, bitsPerComponent: 8, bytesPerRow: 0,
            space: space, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) ?? CGContext(
            data: nil, width: h, height: w, bitsPerComponent: 8, bytesPerRow: 0,
            space: CGColorSpace(name: CGColorSpace.sRGB)!, bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else { return nil }
        if clockwise {
            context.translateBy(x: 0, y: CGFloat(w))
            context.rotate(by: -.pi / 2)
        } else {
            context.translateBy(x: CGFloat(h), y: 0)
            context.rotate(by: .pi / 2)
        }
        context.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
        return context.makeImage()
    }

    /// Reads the text in the image (Apple's Vision OCR).
    public static func recognizeText(_ image: CGImage) async -> String {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                let request = VNRecognizeTextRequest()
                request.recognitionLevel = .accurate
                request.usesLanguageCorrection = true
                request.automaticallyDetectsLanguage = true
                let handler = VNImageRequestHandler(cgImage: image, options: [:])
                try? handler.perform([request])
                let lines = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }
                continuation.resume(returning: lines.joined(separator: "\n"))
            }
        }
    }
}

/// Reads single pixels of an image (for the color picker).
public struct PixelReader {
    public let width: Int
    public let height: Int
    private let bytes: [UInt8]

    public init?(_ image: CGImage) {
        let space = CGColorSpace(name: CGColorSpace.sRGB)!
        guard let frame = RGBAFrame(image, colorSpace: space) else { return nil }
        width = frame.width
        height = frame.height
        bytes = frame.bytes
    }

    /// sRGB color at pixel (x, y), top-left origin.
    public func color(x: Int, y: Int) -> (r: UInt8, g: UInt8, b: UInt8)? {
        guard x >= 0, y >= 0, x < width, y < height else { return nil }
        let i = (y * width + x) * 4
        return (bytes[i], bytes[i + 1], bytes[i + 2])
    }

    public func hex(x: Int, y: Int) -> String? {
        guard let c = color(x: x, y: y) else { return nil }
        return String(format: "#%02X%02X%02X", c.r, c.g, c.b)
    }
}
