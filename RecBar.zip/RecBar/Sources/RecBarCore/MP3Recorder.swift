import AVFoundation
import CLame
import CoreMedia
import Foundation
import ScreenCaptureKit

/// Audio mode: system audio only (no microphone) → .mp3, 320 kbps CBR, 48 kHz stereo.
///
/// macOS has no built-in MP3 encoder, so this uses the bundled LAME 3.100.
/// Audio is encoded and written to disk as it arrives, so a crash still leaves
/// a playable file. On stop, LAME's info tag is written at the start of the
/// file so players trim the encoder padding and show the exact length.
public final class MP3Recorder: NSObject, Recording, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    public let outputURL: URL
    public var onUnexpectedStop: (@Sendable (Error) -> Void)?

    private let lame: OpaquePointer
    private let file: FileHandle
    private let queue = DispatchQueue(label: "recbar.mp3")
    private var stream: SCStream?

    // Everything below is only touched on `queue`.
    private var mp3Buffer = [UInt8](repeating: 0, count: 16_384)
    private var stopped = false
    private var encoderClosed = false
    private var failure: Error?

    public static func make(folder: URL) async throws -> MP3Recorder {
        let target = try await CaptureTarget.mainDisplay()
        let url = Recordings.newFileURL(extension: "mp3", in: folder)
        return try MP3Recorder(target: target, outputURL: url)
    }

    init(target: CaptureTarget, outputURL: URL) throws {
        self.outputURL = outputURL

        guard let encoder = lame_init() else {
            throw RecBarError.writer("Couldn't start the MP3 encoder.")
        }
        lame_set_in_samplerate(encoder, 48_000)
        lame_set_out_samplerate(encoder, 48_000)
        lame_set_num_channels(encoder, 2)
        lame_set_VBR(encoder, vbr_off)
        lame_set_brate(encoder, 320)
        lame_set_quality(encoder, 2)        // 2 = near-best quality, still fast on Apple Silicon
        lame_set_bWriteVbrTag(encoder, 1)   // reserve the first frame for the info tag
        guard lame_init_params(encoder) >= 0 else {
            lame_close(encoder)
            throw RecBarError.writer("Couldn't configure the MP3 encoder.")
        }

        guard FileManager.default.createFile(atPath: outputURL.path, contents: nil),
              let handle = try? FileHandle(forWritingTo: outputURL) else {
            lame_close(encoder)
            throw RecBarError.file("Couldn't create \(outputURL.lastPathComponent).")
        }
        lame = encoder
        file = handle

        super.init()

        let config = SCStreamConfiguration()
        // ScreenCaptureKit always captures a display; keep that side tiny and slow
        // (64×36 at 1 fps) and throw the frames away.
        config.width = 64
        config.height = 36
        config.minimumFrameInterval = CMTime(value: 1, timescale: 1)
        config.showsCursor = false
        config.capturesAudio = true          // system audio only; the microphone is never opened
        config.sampleRate = 48_000
        config.channelCount = 2
        config.excludesCurrentProcessAudio = true

        let scStream = SCStream(filter: target.filter, configuration: config, delegate: self)
        try scStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        try scStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue)
        stream = scStream
    }

    deinit {
        if !encoderClosed { lame_close(lame) }
    }

    public func start() async throws {
        do {
            try await stream?.startCapture()
        } catch {
            try? file.close()
            try? FileManager.default.removeItem(at: outputURL)
            throw error
        }
    }

    public func stop() async throws -> URL {
        try? await stream?.stopCapture()

        return try queue.sync {
            stopped = true
            defer {
                lame_close(lame)
                encoderClosed = true
                try? file.close()
            }
            if let failure {
                // Everything encoded before the failure is already on disk and playable.
                throw failure
            }

            // Flush the encoder's last frames.
            let flushed = mp3Buffer.withUnsafeMutableBufferPointer { out in
                lame_encode_flush(lame, out.baseAddress, Int32(out.count))
            }
            if flushed > 0 {
                try file.write(contentsOf: Data(mp3Buffer[0..<Int(flushed)]))
            }

            // Overwrite the reserved first frame with LAME's info tag (exact length, gapless).
            var tag = [UInt8](repeating: 0, count: 2_880)
            let tagSize = tag.withUnsafeMutableBufferPointer { buffer in
                lame_get_lametag_frame(lame, buffer.baseAddress, buffer.count)
            }
            if tagSize > 0 && tagSize <= tag.count {
                try file.seek(toOffset: 0)
                try file.write(contentsOf: Data(tag[0..<tagSize]))
            }
            return outputURL
        }
    }

    // MARK: SCStreamOutput (on `queue`)

    public func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, !stopped, failure == nil, sampleBuffer.isValid else { return }
        do {
            try encode(sampleBuffer)
        } catch {
            fail(error)
        }
    }

    private func encode(_ sampleBuffer: CMSampleBuffer) throws {
        guard let format = sampleBuffer.formatDescription?.audioStreamBasicDescription,
              format.mFormatID == kAudioFormatLinearPCM,
              format.mFormatFlags & kAudioFormatFlagIsFloat != 0,
              format.mBitsPerChannel == 32 else {
            throw RecBarError.writer("Unexpected audio format from macOS.")
        }

        let encoded: Int32 = try sampleBuffer.withAudioBufferList { (buffers, _) -> Int32 in
            guard let first = buffers.first, let left = first.mData?.assumingMemoryBound(to: Float.self) else {
                return 0
            }

            if buffers.count >= 2, let right = buffers[1].mData?.assumingMemoryBound(to: Float.self) {
                // Non-interleaved stereo (what ScreenCaptureKit normally sends).
                let frames = Int(first.mDataByteSize) / MemoryLayout<Float>.size
                ensureCapacity(for: frames)
                return mp3Buffer.withUnsafeMutableBufferPointer { out in
                    lame_encode_buffer_ieee_float(lame, left, right, Int32(frames), out.baseAddress, Int32(out.count))
                }
            } else if first.mNumberChannels >= 2 {
                // Interleaved stereo.
                let frames = Int(first.mDataByteSize) / (MemoryLayout<Float>.size * Int(first.mNumberChannels))
                ensureCapacity(for: frames)
                return mp3Buffer.withUnsafeMutableBufferPointer { out in
                    lame_encode_buffer_interleaved_ieee_float(lame, left, Int32(frames), out.baseAddress, Int32(out.count))
                }
            } else {
                // Mono: same signal on both channels.
                let frames = Int(first.mDataByteSize) / MemoryLayout<Float>.size
                ensureCapacity(for: frames)
                return mp3Buffer.withUnsafeMutableBufferPointer { out in
                    lame_encode_buffer_ieee_float(lame, left, left, Int32(frames), out.baseAddress, Int32(out.count))
                }
            }
        }

        guard encoded >= 0 else { throw RecBarError.writer("MP3 encoder error \(encoded).") }
        if encoded > 0 {
            try file.write(contentsOf: Data(mp3Buffer[0..<Int(encoded)]))
        }
    }

    /// LAME's worst case for one call: 1.25 × samples + 7200 bytes.
    private func ensureCapacity(for frames: Int) {
        let needed = frames + frames / 4 + 7_200
        if mp3Buffer.count < needed {
            mp3Buffer = [UInt8](repeating: 0, count: needed)
        }
    }

    private func fail(_ error: Error) {
        guard failure == nil else { return }
        failure = error
        onUnexpectedStop?(error)
    }

    // MARK: SCStreamDelegate

    public func stream(_ stream: SCStream, didStopWithError error: Error) {
        queue.async { self.fail(error) }
    }
}
