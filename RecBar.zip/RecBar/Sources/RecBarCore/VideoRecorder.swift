import AVFoundation
import CoreMedia
import Foundation
import ScreenCaptureKit

/// Video mode: main display + system audio (no microphone) →
/// .mp4 (H.264 + AAC) or .mov (ProRes 422 LT + 24-bit PCM, for editing).
///
/// Same approach as the milestone 1 spike:
/// • Constant frame rate: ScreenCaptureKit only sends a frame when the screen
///   changes, so a ticker on the host clock writes the latest frame every 1/fps s,
///   repeating it when nothing changed.
/// • Video and audio share the host clock; the file ends exactly on the last frame.
/// • Fragmented file (a fragment every ~2 s), so a crash still leaves a playable file.
public final class VideoRecorder: NSObject, Recording, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    public let outputURL: URL
    public var onUnexpectedStop: (@Sendable (Error) -> Void)?
    public var onAudioLevel: (@Sendable (StereoLevel) -> Void)?

    private let fps: Int32
    private let writer: AVAssetWriter
    private let videoInput: AVAssetWriterInput
    private let adaptor: AVAssetWriterInputPixelBufferAdaptor
    private let audioInput: AVAssetWriterInput
    private let queue = DispatchQueue(label: "recbar.video")
    private var stream: SCStream?
    private var ticker: DispatchSourceTimer?

    // Everything below is only touched on `queue`.
    private var startTime: CMTime?
    private var latestFrame: CVPixelBuffer?
    private var nextIndex: Int64 = 0
    private var endTime: CMTime?   // set when stop begins: video closed, audio drains up to here
    private var stopped = false
    private var reportedFailure = false
    private var levels = LevelReporter()

    public static func make(preset: QualityPreset, format: VideoFormat, folder: URL,
                            hideNotifications: Bool) async throws -> VideoRecorder {
        let target = try await CaptureTarget.mainDisplay(hideNotifications: hideNotifications)
        let url = Recordings.newFileURL(extension: format.fileExtension, in: folder)
        return try VideoRecorder(target: target, preset: preset, format: format, outputURL: url)
    }

    init(target: CaptureTarget, preset: QualityPreset, format: VideoFormat, outputURL: URL) throws {
        self.outputURL = outputURL
        fps = preset.fps

        let points = CGSize(width: target.display.width, height: target.display.height)
        let size = preset.outputSize(points: points, scale: target.scale)

        writer = try AVAssetWriter(outputURL: outputURL, fileType: format == .mov ? .mov : .mp4)
        writer.movieFragmentInterval = CMTime(seconds: 2, preferredTimescale: 600)

        let videoSettings: [String: Any]
        let audioSettings: [String: Any]
        switch format {
        case .mp4:
            videoSettings = [
                AVVideoCodecKey: AVVideoCodecType.h264,
                AVVideoWidthKey: size.width,
                AVVideoHeightKey: size.height,
                AVVideoCompressionPropertiesKey: [
                    AVVideoAverageBitRateKey: preset.videoBitrate,
                    AVVideoExpectedSourceFrameRateKey: Int(preset.fps),
                    AVVideoMaxKeyFrameIntervalKey: Int(preset.fps) * 2,
                    AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel,
                ] as [String: Any],
            ]
            audioSettings = [
                AVFormatIDKey: kAudioFormatMPEG4AAC,
                AVSampleRateKey: 48_000,
                AVNumberOfChannelsKey: 2,
                AVEncoderBitRateKey: 192_000,
            ]
        case .mov:
            // ProRes sets its own data rate from the frame size; no bitrate settings.
            videoSettings = [
                AVVideoCodecKey: AVVideoCodecType.proRes422LT,
                AVVideoWidthKey: size.width,
                AVVideoHeightKey: size.height,
            ]
            audioSettings = [
                AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: 48_000,
                AVNumberOfChannelsKey: 2,
                AVLinearPCMBitDepthKey: 24,
                AVLinearPCMIsFloatKey: false,
                AVLinearPCMIsBigEndianKey: false,
                AVLinearPCMIsNonInterleaved: false,
            ]
        }

        videoInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        videoInput.expectsMediaDataInRealTime = true

        audioInput = AVAssetWriterInput(mediaType: .audio, outputSettings: audioSettings)
        audioInput.expectsMediaDataInRealTime = true

        guard writer.canAdd(videoInput), writer.canAdd(audioInput) else {
            throw RecBarError.writer("Couldn't set up the video file.")
        }
        writer.add(videoInput)
        writer.add(audioInput)
        adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: videoInput, sourcePixelBufferAttributes: nil)

        super.init()

        let config = SCStreamConfiguration()
        config.width = size.width
        config.height = size.height
        config.minimumFrameInterval = CMTime(value: 1, timescale: preset.fps)
        config.queueDepth = 8
        config.showsCursor = true
        config.pixelFormat = kCVPixelFormatType_32BGRA
        config.capturesAudio = true          // system audio only; the microphone is never opened
        config.sampleRate = 48_000
        config.channelCount = 2
        config.excludesCurrentProcessAudio = true

        let scStream = SCStream(filter: target.filter, configuration: config, delegate: self)
        try scStream.addStreamOutput(self, type: .screen, sampleHandlerQueue: queue)
        try scStream.addStreamOutput(self, type: .audio, sampleHandlerQueue: queue)
        stream = scStream
    }

    public func start() async throws {
        guard writer.startWriting() else {
            throw RecBarError.writer(writer.error?.localizedDescription ?? "Couldn't start writing the video file.")
        }
        do {
            try await stream?.startCapture()
        } catch {
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: outputURL)
            throw error
        }

        let timer = DispatchSource.makeTimerSource(flags: .strict, queue: queue)
        timer.schedule(deadline: .now(), repeating: .nanoseconds(Int(1_000_000_000 / Int64(fps))), leeway: .milliseconds(1))
        timer.setEventHandler { [weak self] in self?.tick() }
        timer.resume()
        ticker = timer
    }

    public func stop() async throws -> URL {
        // 1. Close the video side at the last due frame.
        let end: CMTime? = queue.sync {
            tick()
            ticker?.cancel()
            guard let start = startTime else {
                stopped = true
                return nil
            }
            let end = CMTimeAdd(start, CMTime(value: nextIndex, timescale: fps))
            endTime = end
            return end
        }
        // 2. Audio arrives slightly behind video: keep accepting it (up to `end`)
        //    until capture has fully stopped, then close everything.
        try? await stream?.stopCapture()
        queue.sync { stopped = true }

        if writer.status == .failed {
            // The fragmented file up to the failure is still playable; keep it.
            throw RecBarError.writer(writer.error?.localizedDescription ?? "Writing the video file failed.")
        }
        guard let end, writer.status == .writing else {
            writer.cancelWriting()
            try? FileManager.default.removeItem(at: outputURL)
            throw RecBarError.nothingCaptured
        }
        videoInput.markAsFinished()
        audioInput.markAsFinished()
        writer.endSession(atSourceTime: end)
        await writer.finishWriting()
        guard writer.status == .completed else {
            throw RecBarError.writer(writer.error?.localizedDescription ?? "Couldn't finish the video file.")
        }
        return outputURL
    }

    // MARK: Constant frame rate (on `queue`)

    private func tick() {
        guard !stopped, endTime == nil else { return }
        if writer.status == .failed {
            reportFailure(writer.error ?? RecBarError.writer("Writing the video file failed."))
            return
        }
        guard let start = startTime, let frame = latestFrame, writer.status == .writing else { return }

        let now = CMClockGetTime(CMClockGetHostTimeClock())
        let due = Int64(CMTimeGetSeconds(CMTimeSubtract(now, start)) * Double(fps))
        while nextIndex <= due {
            guard videoInput.isReadyForMoreMediaData else { return }  // catch up next tick
            let pts = CMTimeAdd(start, CMTime(value: nextIndex, timescale: fps))
            guard adaptor.append(frame, withPresentationTime: pts) else { return }
            nextIndex += 1
        }
    }

    private func reportFailure(_ error: Error) {
        guard !reportedFailure else { return }
        reportedFailure = true
        onUnexpectedStop?(error)
    }

    // MARK: SCStreamOutput

    public func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard !stopped, sampleBuffer.isValid, writer.status == .writing else { return }

        switch type {
        case .screen:
            guard endTime == nil, Self.isCompleteFrame(sampleBuffer),
                  let pixels = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
            latestFrame = pixels
            if startTime == nil {
                let first = sampleBuffer.presentationTimeStamp
                startTime = first
                writer.startSession(atSourceTime: first)
                tick()
            }

        case .audio:
            let pts = sampleBuffer.presentationTimeStamp
            guard let start = startTime, pts >= start else { return }
            if let endTime, pts >= endTime { return }
            if audioInput.isReadyForMoreMediaData {
                _ = audioInput.append(sampleBuffer)
            }
            // Level for the meter in the box.
            if sampleBuffer.isFloat32PCM {
                let peaks = (try? sampleBuffer.withAudioBufferList { (buffers, _) -> StereoLevel in
                    PCMBuffers(buffers)?.peaks ?? .silent
                }) ?? .silent
                levels.add(peaks) { onAudioLevel?($0) }
            }

        default:
            return
        }
    }

    // MARK: SCStreamDelegate

    public func stream(_ stream: SCStream, didStopWithError error: Error) {
        queue.async { self.reportFailure(error) }
    }

    private static func isCompleteFrame(_ sampleBuffer: CMSampleBuffer) -> Bool {
        guard
            let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: false)
                as? [[SCStreamFrameInfo: Any]],
            let rawStatus = attachments.first?[.status] as? Int,
            let status = SCFrameStatus(rawValue: rawStatus)
        else { return false }
        return status == .complete
    }
}
