import Foundation

/// Reads OBS Studio's settings (read-only) to find the folder it records to,
/// so Rec Bar can start out saving to the same place.
///
/// OBS keeps its settings in ~/Library/Application Support/obs-studio:
///   user.ini (OBS 31+) or global.ini (older)  → [Basic] ProfileDir = the current profile
///   basic/profiles/<ProfileDir>/basic.ini     → [Output] Mode = Simple | Advanced
///                                               [SimpleOutput] FilePath = …
///                                               [AdvOut] RecFilePath = …
enum OBSSettings {
    static func recordingFolder() -> URL? {
        let fm = FileManager.default
        guard let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let obs = support.appendingPathComponent("obs-studio", isDirectory: true)
        let profiles = obs.appendingPathComponent("basic/profiles", isDirectory: true)

        // The current profile first, then any other profile.
        var candidates: [URL] = []
        for name in ["user.ini", "global.ini"] {
            if let ini = INIFile(url: obs.appendingPathComponent(name)),
               let dir = ini.value("Basic", "ProfileDir"), !dir.isEmpty {
                candidates.append(profiles.appendingPathComponent(dir, isDirectory: true))
            }
        }
        if let all = try? fm.contentsOfDirectory(at: profiles, includingPropertiesForKeys: nil) {
            candidates += all.sorted { $0.lastPathComponent < $1.lastPathComponent }
        }

        for profile in candidates {
            guard let ini = INIFile(url: profile.appendingPathComponent("basic.ini")) else { continue }
            let simple = ini.value("SimpleOutput", "FilePath")
            let advanced = ini.value("AdvOut", "RecFilePath")
            let path = ini.value("Output", "Mode") == "Advanced" ? (advanced ?? simple) : (simple ?? advanced)
            guard let path, !path.isEmpty else { continue }
            let url = URL(fileURLWithPath: (path as NSString).expandingTildeInPath, isDirectory: true)
            if Recordings.isUsableFolder(url) { return url }
        }
        return nil
    }
}

/// A minimal reader for OBS's .ini files: [Section] headers and key=value lines.
struct INIFile {
    private var sections: [String: [String: String]] = [:]

    init?(url: URL) {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        var current = ""
        for rawLine in text.components(separatedBy: .newlines) {
            let line = rawLine
                .trimmingCharacters(in: CharacterSet(charactersIn: "\u{FEFF}"))  // byte-order mark
                .trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix(";") || line.hasPrefix("#") { continue }
            if line.hasPrefix("[") && line.hasSuffix("]") {
                current = String(line.dropFirst().dropLast())
                continue
            }
            guard let equals = line.firstIndex(of: "=") else { continue }
            let key = line[..<equals].trimmingCharacters(in: .whitespaces)
            let value = line[line.index(after: equals)...].trimmingCharacters(in: .whitespaces)
            sections[current, default: [:]][key] = value
        }
    }

    func value(_ section: String, _ key: String) -> String? {
        sections[section]?[key]
    }
}
