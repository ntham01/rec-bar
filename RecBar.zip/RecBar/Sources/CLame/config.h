/*
 * config.h for building the LAME 3.100 MP3 encoder (libmp3lame only) inside
 * Rec Bar on macOS, Apple Silicon and Intel.
 *
 * Hand-written equivalent of what LAME's ./configure produces on macOS with
 * --disable-frontend --disable-decoder. No SSE vector code (it is x86-only),
 * so the same settings build on arm64 and x86_64.
 */
#ifndef RECBAR_LAME_CONFIG_H
#define RECBAR_LAME_CONFIG_H

/* Standard headers and functions present on macOS */
#define STDC_HEADERS 1
#define HAVE_ERRNO_H 1
#define HAVE_FCNTL_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_LIMITS_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define HAVE_GETTIMEOFDAY 1
#define HAVE_STRTOL 1
#define TIME_WITH_SYS_TIME 1

/* Fixed-width integer types come from <stdint.h> */
#define HAVE_UINT8_T 1
#define HAVE_INT8_T 1
#define HAVE_UINT16_T 1
#define HAVE_INT16_T 1
#define HAVE_UINT32_T 1
#define HAVE_INT32_T 1
#define HAVE_UINT64_T 1
#define HAVE_INT64_T 1

/* LP64 type sizes */
#define HAVE_LONG_DOUBLE 1
#define SIZEOF_SHORT 2
#define SIZEOF_UNSIGNED_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_LONG 8
#define SIZEOF_UNSIGNED_LONG 8
#define SIZEOF_LONG_LONG 8
#define SIZEOF_UNSIGNED_LONG_LONG 8
#define SIZEOF_FLOAT 4
#define SIZEOF_DOUBLE 8
#define SIZEOF_LONG_DOUBLE __SIZEOF_LONG_DOUBLE__

/* IEEE 754 float types LAME expects (configure adds these typedefs too) */
typedef double ieee754_float64_t;
typedef float ieee754_float32_t;

/* Intel-only speedups configure enables on x86 hosts; off on Apple Silicon */
#if defined(__x86_64__) || defined(__i386__)
#define TAKEHIRO_IEEE754_HACK 1
#define USE_FAST_LOG 1
#endif

#define LAME_LIBRARY_BUILD 1

#define PACKAGE "lame"
#define PACKAGE_NAME "lame"
#define PACKAGE_TARNAME "lame"
#define PACKAGE_VERSION "3.100"
#define PACKAGE_STRING "lame 3.100"
#define PACKAGE_BUGREPORT "lame-dev@lists.sf.net"
#define PACKAGE_URL ""
#define VERSION "3.100"

#endif /* RECBAR_LAME_CONFIG_H */
