#!/bin/bash
# Double-click this file in Finder to build and install Rec Bar.
# A Terminal window opens and does everything; you don't need to type anything.
cd "$(dirname "$0")" || exit 1

pause_then_exit() {
  echo ""
  read -n 1 -s -r -p "Press any key to close this window."
  echo ""
  exit "$1"
}

clear
echo "Rec Bar installer"
echo "─────────────────"
echo ""

# Rec Bar is built on your Mac with Apple's free developer tools.
if ! xcode-select -p >/dev/null 2>&1; then
  echo "First, your Mac needs Apple's free developer tools (one time only)."
  echo ""
  echo "  1. A window will pop up. Click Install, then Agree."
  echo "  2. Wait for it to finish (5–15 minutes)."
  echo "  3. Double-click \"Install Rec Bar\" again."
  echo ""
  xcode-select --install >/dev/null 2>&1
  pause_then_exit 0
fi

if bash ./install.sh; then
  echo ""
  echo "All done. You can close this window."
  pause_then_exit 0
else
  echo ""
  echo "Something went wrong. Copy everything in this window into the chat with Claude."
  pause_then_exit 1
fi
