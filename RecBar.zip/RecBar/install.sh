#!/bin/bash
# Builds Rec Bar and installs it as "Rec Bar.app" in /Applications
# (or ~/Applications if /Applications isn't writable), then opens it.
#
# Each install also:
#   • signs Rec Bar with the same local certificate every time, so macOS keeps
#     the screen-recording permission across updates instead of forgetting it;
#   • finds older copies of Rec Bar anywhere on the Mac and moves them to the Trash;
#   • opens the new copy, which quits any older copy that's still running.
#
# Normally run by double-clicking "Install Rec Bar". By hand:  bash install.sh
set -euo pipefail
cd "$(dirname "$0")"

APP_NAME="Rec Bar"
EXECUTABLE="RecBar"
BUNDLE_ID="com.nathanieltham.recbar"
VERSION="0.7.9"   # Scrolling capture: gentle check at the bottom, finishes sooner
CERT_NAME="Rec Bar Local Signing"
SUPPORT_DIR="${HOME}/Library/Application Support/Rec Bar"
SIGNER_RECORD="${SUPPORT_DIR}/installer-signer.txt"
LSREGISTER="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"

if ! command -v swift >/dev/null 2>&1; then
  echo "Apple's developer tools aren't installed yet. Double-click \"Install Rec Bar\" to set them up."
  exit 1
fi

# ── 1. Build ────────────────────────────────────────────────────────────────
echo "▸ Building Rec Bar ${VERSION}… the first build takes a minute or two."
swift build -c release --product "${EXECUTABLE}"
BIN_DIR="$(swift build -c release --product "${EXECUTABLE}" --show-bin-path)"

echo "▸ Assembling ${APP_NAME}.app"
STAGE_DIR="$(mktemp -d)"
APP="${STAGE_DIR}/${APP_NAME}.app"
mkdir -p "${APP}/Contents/MacOS" "${APP}/Contents/Resources"
cp "${BIN_DIR}/${EXECUTABLE}" "${APP}/Contents/MacOS/${EXECUTABLE}"
cp "Assets/AppIcon.icns" "${APP}/Contents/Resources/AppIcon.icns"

cat > "${APP}/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>${APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>${APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>${BUNDLE_ID}</string>
  <key>CFBundleExecutable</key><string>${EXECUTABLE}</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VERSION}</string>
  <key>CFBundleVersion</key><string>${VERSION}</string>
  <key>LSMinimumSystemVersion</key><string>14.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSPrincipalClass</key><string>NSApplication</string>
</dict>
</plist>
PLIST

# ── 2. Sign with the same identity every time ───────────────────────────────
# macOS ties the screen-recording permission to the app's signature. An
# "ad-hoc" signature changes with every build, so each update looked like a new
# app and the switch in System Settings no longer applied. A certificate that
# stays the same across builds fixes that.
#
# The certificate lives in a small keychain of its own. (In the login keychain,
# codesign wasn't allowed to use the key without a password box that never
# appeared, and signing failed with errSecInternalComponent.) Its password is
# fixed and not secret: the key inside only signs this home-built app.
SIGN_KEYCHAIN="${HOME}/Library/Keychains/recbar-signing.keychain-db"
SIGN_KEYCHAIN_PASS="recbar"

# Notes on how signing went, shown in Rec Bar's "Copy Scrolling Capture Details".
mkdir -p "${SUPPORT_DIR}"
SIGN_LOG="${SUPPORT_DIR}/signing-log.txt"
{ echo "install ${VERSION} $(date)"; /usr/bin/openssl version 2>&1; echo "keychain: ${SIGN_KEYCHAIN}"; } > "${SIGN_LOG}"

signer_hash() {
  security find-certificate -c "${CERT_NAME}" -Z "${SIGN_KEYCHAIN}" 2>/dev/null | awk '/SHA-1 hash:/ { print $3; exit }'
}

# Creates (first time) and unlocks the signing keychain, and adds it to the
# list of keychains macOS searches, without touching the ones already there.
prepare_signing_keychain() {
  if [ ! -f "${SIGN_KEYCHAIN}" ]; then
    security create-keychain -p "${SIGN_KEYCHAIN_PASS}" "${SIGN_KEYCHAIN}" >>"${SIGN_LOG}" 2>&1 || return 1
  fi
  security set-keychain-settings "${SIGN_KEYCHAIN}" >>"${SIGN_LOG}" 2>&1 || true   # never auto-locks
  security unlock-keychain -p "${SIGN_KEYCHAIN_PASS}" "${SIGN_KEYCHAIN}" >>"${SIGN_LOG}" 2>&1 || return 1

  local current=() line listed=0 safe=1
  while IFS= read -r line; do
    line="${line#"${line%%[![:space:]]*}"}"   # leading spaces
    line="${line#\"}"; line="${line%\"}"       # surrounding quotes
    [ -n "${line}" ] || continue
    [ "${line}" = "${SIGN_KEYCHAIN}" ] && listed=1
    [ -e "${line}" ] || safe=0
    current+=("${line}")
  done < <(security list-keychains -d user 2>/dev/null)
  if [ "${listed}" = 0 ]; then
    # Only rewrite the list if it was read back correctly (every entry exists).
    if [ "${safe}" = 1 ] && [ ${#current[@]} -gt 0 ]; then
      security list-keychains -d user -s "${current[@]}" "${SIGN_KEYCHAIN}" >>"${SIGN_LOG}" 2>&1 || true
    else
      echo "keychain list not changed (couldn't read it safely)" >> "${SIGN_LOG}"
    fi
  fi
  return 0
}

create_local_certificate() {
  echo "▸ Creating a signing certificate for Rec Bar (one time only)"
  local tmp; tmp="$(mktemp -d)"
  cat > "${tmp}/cert.cnf" <<CNF
[ req ]
distinguished_name = dn
x509_extensions = ext
prompt = no
[ dn ]
CN = ${CERT_NAME}
[ ext ]
basicConstraints = critical, CA:false
keyUsage = critical, digitalSignature
extendedKeyUsage = critical, codeSigning
CNF
  /usr/bin/openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
    -keyout "${tmp}/key.pem" -out "${tmp}/cert.pem" -config "${tmp}/cert.cnf" >>"${SIGN_LOG}" 2>&1
  /usr/bin/openssl pkcs12 -export -inkey "${tmp}/key.pem" -in "${tmp}/cert.pem" \
    -out "${tmp}/cert.p12" -passout pass:recbar -name "${CERT_NAME}" >>"${SIGN_LOG}" 2>&1
  security import "${tmp}/cert.p12" -k "${SIGN_KEYCHAIN}" -P recbar -A -T /usr/bin/codesign >>"${SIGN_LOG}" 2>&1
  local imported=$?
  rm -rf "${tmp}"
  # Lets codesign use the key without a password box.
  security set-key-partition-list -S apple-tool:,apple:,codesign: -s -k "${SIGN_KEYCHAIN_PASS}" "${SIGN_KEYCHAIN}" >/dev/null 2>>"${SIGN_LOG}" || true
  return ${imported}
}

sign_with_local_certificate() {
  prepare_signing_keychain || { echo "prepare_signing_keychain failed" >> "${SIGN_LOG}"; return 1; }
  [ -n "$(signer_hash)" ] || create_local_certificate || echo "create_local_certificate failed" >> "${SIGN_LOG}"
  HASH="$(signer_hash)"
  echo "certificate hash: ${HASH:-none}" >> "${SIGN_LOG}"
  [ -n "${HASH}" ] || return 1
  codesign --force --keychain "${SIGN_KEYCHAIN}" --sign "${HASH}" "${APP}" 2>>"${SIGN_LOG}"
}

SIGNER=""
HASH=""
DEV_IDENTITY="$(security find-identity -v -p codesigning 2>/dev/null \
  | awk -F'"' '/Apple Development|Developer ID Application/ { print $2; exit }')"
if [ -n "${DEV_IDENTITY}" ]; then
  echo "▸ Signing with \"${DEV_IDENTITY}\""
  codesign --force --sign "${DEV_IDENTITY}" "${APP}" && SIGNER="${DEV_IDENTITY}"
else
  echo "▸ Signing with \"${CERT_NAME}\""
  if sign_with_local_certificate; then
    SIGNER="${HASH}"
  else
    # Start over once with a fresh keychain in case the old one is damaged.
    echo "first attempt failed; recreating the signing keychain" >> "${SIGN_LOG}"
    security delete-keychain "${SIGN_KEYCHAIN}" >>"${SIGN_LOG}" 2>&1 || true
    rm -f "${SIGN_KEYCHAIN}"
    if sign_with_local_certificate; then
      SIGNER="${HASH}"
    else
      echo "codesign with certificate failed" >> "${SIGN_LOG}"
    fi
  fi
fi
if [ -z "${SIGNER}" ]; then
  echo "▸ Couldn't use a certificate; signing ad-hoc instead."
  echo "  macOS may ask for screen-recording permission again after each update."
  codesign --force --sign - "${APP}"
  SIGNER="ad-hoc-$(date +%s)"
fi

# If the signature changed since the last install, clear the old permission
# entries, which belong to builds that no longer exist. You'll allow Rec Bar
# once more, and from then on updates keep the permission.
mkdir -p "${SUPPORT_DIR}"
PREVIOUS_SIGNER="$(cat "${SIGNER_RECORD}" 2>/dev/null || true)"
PERMISSION_RESET=0
if [ "${PREVIOUS_SIGNER}" != "${SIGNER}" ]; then
  if tccutil reset ScreenCapture "${BUNDLE_ID}" >/dev/null 2>&1; then PERMISSION_RESET=1; fi
  # Scrolling capture's switch (Accessibility, plus macOS's separate PostEvent
  # permission behind the same list) is tied to the signature too: clear the old ones.
  tccutil reset Accessibility "${BUNDLE_ID}" >/dev/null 2>&1 || true
  tccutil reset PostEvent "${BUNDLE_ID}" >/dev/null 2>&1 || true
  echo "${SIGNER}" > "${SIGNER_RECORD}"
fi

# ── 3. Find older copies of Rec Bar and move them to the Trash ─────────────
DEST="/Applications"
if [ ! -w "${DEST}" ]; then
  DEST="${HOME}/Applications"
  mkdir -p "${DEST}"
fi

is_rec_bar() {
  [ "$(/usr/bin/defaults read "$1/Contents/Info" CFBundleIdentifier 2>/dev/null)" = "${BUNDLE_ID}" ]
}

OLD_COPIES=()
add_copy() {
  local path="$1"
  case "${path}" in "${HOME}/.Trash"/*|"${STAGE_DIR}"/*) return ;; esac
  [ -d "${path}" ] && is_rec_bar "${path}" || return 0
  local existing
  for existing in "${OLD_COPIES[@]+"${OLD_COPIES[@]}"}"; do [ "${existing}" = "${path}" ] && return 0; done
  OLD_COPIES+=("${path}")
}

# Spotlight finds copies anywhere; the folders below catch ones it hasn't indexed.
while IFS= read -r found; do add_copy "${found}"; done < <(mdfind "kMDItemCFBundleIdentifier == '${BUNDLE_ID}'" 2>/dev/null || true)
for folder in /Applications "${HOME}/Applications" "${HOME}/Desktop" "${HOME}/Downloads"; do
  for candidate in "${folder}"/*.app; do
    [ -e "${candidate}" ] && add_copy "${candidate}"
  done
done

if [ ${#OLD_COPIES[@]} -gt 0 ]; then
  echo "▸ Found ${#OLD_COPIES[@]} older copy/copies of Rec Bar; moving to the Trash:"
  n=0
  for old in "${OLD_COPIES[@]}"; do
    n=$((n + 1))
    old_version="$(/usr/bin/defaults read "${old}/Contents/Info" CFBundleShortVersionString 2>/dev/null || echo "?")"
    echo "    ${old}  (version ${old_version})"
    "${LSREGISTER}" -u "${old}" >/dev/null 2>&1 || true
    mv "${old}" "${HOME}/.Trash/Rec Bar ${old_version} (old copy $(date +%Y%m%d-%H%M%S)-${n}).app" 2>/dev/null \
      || echo "      couldn't move this one; you can drag it to the Trash yourself."
  done
else
  echo "▸ No older copies of Rec Bar found."
fi

# ── 4. Install and open ──────────────────────────────────────────────────────
echo "▸ Installing to ${DEST}/${APP_NAME}.app"
rm -rf "${DEST}/${APP_NAME}.app"
ditto "${APP}" "${DEST}/${APP_NAME}.app"
rm -rf "${STAGE_DIR}"
"${LSREGISTER}" -f "${DEST}/${APP_NAME}.app" >/dev/null 2>&1 || true
touch "${DEST}/${APP_NAME}.app"   # so Finder shows the current icon

# -n starts the new copy even if an old one is still running; the new copy
# then asks the old one to quit (saving any recording in progress).
open -n "${DEST}/${APP_NAME}.app"

echo ""
echo "✓ Rec Bar ${VERSION} is installed and running. Look for the box at the top of your screen."
case "${SIGNER}" in
  ad-hoc-*) echo ""
            echo "  Note: Rec Bar was signed ad-hoc this time, so macOS will ask for its permissions"
            echo "  again after each update. Copy this window into the chat with Claude to fix that." ;;
esac
if [ "${PERMISSION_RESET}" = 1 ]; then
  echo ""
  echo "  One more time: allow screen recording (and Accessibility, for scrolling capture)."
  echo "  1. Click the box (\"Allow screen recording\") and turn on Rec Bar in System Settings."
  echo "  2. Click the box again (\"Restart to finish\")."
  echo "  3. Press the scrolling shortcut and switch Rec Bar on in Accessibility."
  echo "  After this, updates keep the permissions."
fi
