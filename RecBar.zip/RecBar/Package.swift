// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "RecBar",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "RecBar", targets: ["RecBar"]),
    ],
    targets: [
        // LAME 3.100 MP3 encoder (libmp3lame only), bundled as C source. LGPL; see Sources/CLame/COPYING.
        .target(
            name: "CLame",
            path: "Sources/CLame",
            exclude: ["COPYING", "LICENSE", "config.h"],  // config.h is found via headerSearchPath below
            sources: ["libmp3lame"],
            publicHeadersPath: "include",
            cSettings: [
                .define("HAVE_CONFIG_H"),
                .headerSearchPath("."),
                .headerSearchPath("libmp3lame"),
                .unsafeFlags(["-w"]),  // silence LAME's own compiler warnings
            ]
        ),

        // Capture and encoding: MP4 (screen + system audio) and MP3 (system audio only).
        .target(name: "RecBarCore", dependencies: ["CLame"]),

        // The Rec Bar app: the floating box at the top of the screen.
        .executableTarget(name: "RecBar", dependencies: ["RecBarCore"]),

        // Milestone 1: command-line capture spike (no UI).
        .executableTarget(name: "RecBarSpike"),
    ]
)
