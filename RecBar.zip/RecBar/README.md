# Rec Bar

A tiny always-on-top box for macOS that records your screen + desktop audio to MP4, or desktop audio only to MP3. No OBS, no microphone.

Rec Bar also takes Shottr-style screenshots (see **Screenshots** below).

Needs macOS 14 (Sonoma) or later.

## Install (no typing)

1. Double-click **Install Rec Bar** in this folder. A Terminal window opens and does the rest; you don't type anything.
   - If macOS says it can't verify the file: open **System Settings → Privacy & Security**, scroll down, click **Open Anyway** next to "Install Rec Bar", then double-click it again.
   - The very first time, it may ask to install Apple's free developer tools. Click **Install**, wait for it to finish, then double-click **Install Rec Bar** again.
2. When it's done, the box appears at the top of your screen. Click it (**Allow screen recording**), turn on **Rec Bar** in the System Settings window that opens, then click the box again (**Restart to finish**).
   - The installer may show a box asking for your Mac password so it can sign Rec Bar. Type it and click **Always Allow**. This happens once.

To update later, double-click **Install Rec Bar** again. Each install:

- finds older copies of Rec Bar anywhere on your Mac and moves them to the Trash (it lists them in the window);
- opens the new copy, which quits any older copy still running (saving a recording in progress first);
- signs Rec Bar the same way every time, so the screen-recording permission carries over to the new version.

## Use

| You see | What it does |
| --- | --- |
| **Video** / **Audio** | Pick the mode. Video = screen + desktop audio. Audio = desktop audio only. |
| Grey dot | Start recording. |
| Red dot + timer | Recording. Click the dot to stop. The chip shows the file format (MP4, MOV, MP3 or WAV). |
| Two thin lines (L, R) | Desktop audio level while recording, left on top and right below. Both empty = no sound is being captured; reaching the red end = at the limit. |
| **Saved to …** | Click to show the file in Finder. |
| Sliders icon | Video format, video quality, audio format, where recordings are saved, Hide Notifications in Recordings, Open at Login, Quit. |

- **Where recordings go:** at first, the same folder OBS saves to (Rec Bar reads OBS's settings), or Movies if OBS isn't set up. Change it with **Choose Folder…** in the sliders menu. Rec Bar remembers your choice.
- **Formats:** Video saves as **MP4** (H.264, small files) or **MOV** (ProRes 422 LT, smooth to edit in Premiere / Resolve). Audio saves as **MP3** (320 kbps) or **WAV** (24-bit, uncompressed). Pick them in the sliders menu; Rec Bar remembers.
- **Notifications** don't appear in recordings (they still show on your screen). Untick **Hide Notifications in Recordings** if you want them in.
- Files are named `Rec Bar <date time>` plus the format's extension.
- Drag any empty part of the box to move it; it remembers where you put it.
- The box never appears in its own recordings, and it doesn't steal focus from the app you're using.
- Quitting or putting the Mac to sleep mid-recording saves the file first.
- Rec Bar turns on **Open at Login** the first time it runs. Untick it in the sliders menu if you don't want that.

## Screenshots

| Shortcut | What it captures |
| --- | --- |
| **⌃⇧4** (Control-Shift-4) | An area: drag over what you want (just an outline and its size, nothing else on screen). Esc cancels. |
| **⌃⇧2** | The whole screen the pointer is on. |
| **⌃⇧1** | A scrolling (long) capture, like Shottr's: drag over the area, then Rec Bar scrolls it by itself to the bottom and joins everything into one tall image. |

Every screenshot is **copied to the clipboard** straight away and a small preview opens right where your pointer is (for an area, where you let go). Its buttons:

| Button | What it does |
| --- | --- |
| ✏️ Edit | Opens the editor: crop (drag over the part to keep, then Return), rotate left/right, undo. Done keeps the edits and copies the result. |
| Copy | Copies it again (e.g. after copying something else). |
| Save | Saves a PNG to your **Pictures** folder (change it in the sliders menu → Screenshots). |
| Eyedropper | Pick a color right in the preview: hover the picture to see a magnifier and the hex code, click to copy it (e.g. `#1E1E20`). |
| Text | Copies the text in the screenshot (Apple's built-in text recognition). |

- The preview hides itself after 10 seconds unless the pointer is over it. Drag it by its edge to move it, or drag the picture straight into Slack, Mail, etc.
- Rec Bar's own box and previews never appear in screenshots.
- **Scrolling capture needs Accessibility permission** (so Rec Bar can scroll the page). The first time you press ⌃⇧1, a window explains it: click **Open Settings**, switch on Rec Bar, then press ⌃⇧1 again and click **Restart Rec Bar**. If it keeps asking even though Rec Bar is switched on, that switch belongs to an older copy: click **Reset**, switch Rec Bar on again, then restart. While it scrolls, don't touch the mouse; Esc, Return, ⌃⇧1 or Done stop early and keep what's captured, Cancel throws it away. Sticky headers and footers appear once. Videos or animations in the area can make it stop early.
- **Change the shortcuts** in the sliders menu → Screenshots → **Keyboard Shortcuts…**: click one, press the new keys. Use ⌘, ⌃ or ⌥ with a key (F-keys work on their own); ⌫ turns a shortcut off; Reset to Defaults brings back ⌃⇧4, ⌃⇧2 and ⌃⇧1. If another app (e.g. Shottr) already uses your choice, it says so, and Rec Bar tells you at launch if one of your shortcuts is taken. If something goes wrong, a short message appears next to the pointer.

## Good to know

- **Permission after updating.** Updates keep the permission. If you ever see **Allow screen recording** after an update anyway, click it, switch Rec Bar off and on in System Settings, then click **Restart to finish**.
- **File sizes:** MP4 — Low ≈ 45 MB/min, Standard ≈ 90 MB/min, High ≈ 225 MB/min. MOV (ProRes) — Low ≈ 300 MB/min, Standard ≈ 750 MB/min, High several GB/min. MP3 ≈ 2.4 MB/min, WAV ≈ 17 MB/min.
- **Protected video** (some streaming apps and sites) may record as black. That's macOS blocking capture, not Rec Bar.

## In this folder

- `Install Rec Bar.command` — the double-click installer (runs `install.sh`).
- `Sources/RecBar` — the app: the box, plus the screenshot selector, preview, editor and scrolling capture.
- `Sources/RecBarCore` — capture, encoding (MP4/MOV, MP3/WAV), the level meter's readings, reading OBS's save folder, screenshots and the scrolling-capture stitcher.
- `Sources/CLame` — the LAME 3.100 MP3 encoder, bundled as source (LGPL, see `Sources/CLame/COPYING`).
- `Assets` — the app icon (`AppIcon.icns`), made from `logo-source.png` by `make_icon.py`.
- `Sources/RecBarSpike` — the milestone 1 command-line test.
