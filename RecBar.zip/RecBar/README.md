# Rec Bar

A tiny always-on-top box for macOS that records your screen + desktop audio to MP4, or desktop audio only to MP3. No OBS, no microphone.

Needs macOS 13 or later.

## Install (no typing)

1. Double-click **Install Rec Bar** in this folder. A Terminal window opens and does the rest; you don't type anything.
   - If macOS says it can't verify the file: open **System Settings → Privacy & Security**, scroll down, click **Open Anyway** next to "Install Rec Bar", then double-click it again.
   - The very first time, it may ask to install Apple's free developer tools. Click **Install**, wait for it to finish, then double-click **Install Rec Bar** again.
2. When it's done, the box appears at the top of your screen. Click it (**Allow screen recording**), turn on **Rec Bar** in the System Settings window that opens, then click the box again (**Restart to finish**).
   - The installer may show a box asking for your Mac password so it can sign Rec Bar. Type it and click **Always Allow**. This happens once.

To update later, double-click **Install Rec Bar** again. Each install:

- finds older copies of Rec Bar anywhere on your Mac and moves them to the Trash (it lists them in the window);
- opens the new copy, which quits any older copy still running (saving a recording in progress first);
- signs Rec Bar the same way every time, so the screen-recording permission carries over to the new version.

## Use

| You see | What it does |
| --- | --- |
| **Video** / **Audio** | Pick the mode. Video = screen + desktop audio → `.mp4`. Audio = desktop audio only → `.mp3` (320 kbps). |
| Grey dot | Start recording. |
| Red dot + timer | Recording. Click the dot to stop. |
| **Saved to …** | Click to show the file in Finder. |
| Sliders icon | Video quality, where recordings are saved, Open at Login, Quit. |

- **Where recordings go:** at first, the same folder OBS saves to (Rec Bar reads OBS's settings), or Movies if OBS isn't set up. Change it with **Choose Folder…** in the sliders menu. Rec Bar remembers your choice.
- Files are named `Rec Bar <date time>.mp4` or `.mp3`.
- Drag any empty part of the box to move it; it remembers where you put it.
- The box never appears in its own recordings, and it doesn't steal focus from the app you're using.
- Quitting or putting the Mac to sleep mid-recording saves the file first.
- Rec Bar turns on **Open at Login** the first time it runs. Untick it in the sliders menu if you don't want that.

## Good to know

- **Permission after updating.** Updates keep the permission. If you ever see **Allow screen recording** after an update anyway, click it, switch Rec Bar off and on in System Settings, then click **Restart to finish**.
- **File sizes (Video mode):** Low ≈ 45 MB/min, Standard ≈ 90 MB/min, High ≈ 225 MB/min. MP3 ≈ 2.4 MB/min.
- **Protected video** (some streaming apps and sites) may record as black. That's macOS blocking capture, not Rec Bar.

## In this folder

- `Install Rec Bar.command` — the double-click installer (runs `install.sh`).
- `Sources/RecBar` — the app (the box).
- `Sources/RecBarCore` — capture, encoding (MP4 and MP3) and reading OBS's save folder.
- `Sources/CLame` — the LAME 3.100 MP3 encoder, bundled as source (LGPL, see `Sources/CLame/COPYING`).
- `Assets` — the app icon (`AppIcon.icns`), made from `logo-source.png` by `make_icon.py`.
- `Sources/RecBarSpike` — the milestone 1 command-line test.
