"""Build Rec Bar's macOS app icon (red on light) from the halftone film-light drawing.

macOS icon grid: 1024 px canvas, 824 px rounded-square body (corner radius ~185),
soft drop shadow. The drawing is turned into an ink layer (darkness -> opacity)
so its halftone dots sit cleanly on the icon's own background.
"""
import sys
from PIL import Image, ImageChops, ImageDraw, ImageFilter

src_path, out_dir = sys.argv[1], sys.argv[2]

# Colours: light blush-red body, the drawing in dark red.
BG_TOP, BG_BOTTOM = (253, 241, 239), (244, 222, 219)
INK = (128, 14, 20)
EDGE = (110, 10, 14, 46)        # faint dark-red rim so the light body has an edge
USE_GLOW = False                # a light body lets the lens read as lit on its own
GLOW = (255, 132, 112)          # (only used on a dark body)
LENS = (361, 355, 52)           # lens centre x, y and radius in the source drawing (px)

S = 1024
BODY = 824
OFF = (S - BODY) // 2           # 100
RADIUS = 185

# --- ink layer from the drawing --------------------------------------------
src = Image.open(src_path).convert("L")
paper = 244                                   # the drawing's background grey
ink_alpha = src.point(lambda v: max(0, min(255, round((paper - v) * 255 / (paper - 8)))))
bbox = ink_alpha.point(lambda a: 255 if a > 40 else 0).getbbox()
pad = 6
bbox = (bbox[0] - pad, bbox[1] - pad, bbox[2] + pad, bbox[3] + pad)
ink_alpha = ink_alpha.crop(bbox)

target_w = 600                                 # drawing width inside the 824 body
scale = target_w / ink_alpha.width
ink_alpha = ink_alpha.resize((target_w, round(ink_alpha.height * scale)), Image.LANCZOS)
ink = Image.new("RGBA", ink_alpha.size, INK + (255,))
ink.putalpha(ink_alpha)

# --- body: rounded square with a gentle top-to-bottom shade ----------------
mask = Image.new("L", (S, S), 0)
ImageDraw.Draw(mask).rounded_rectangle((OFF, OFF, OFF + BODY - 1, OFF + BODY - 1), RADIUS, fill=255)

grad = Image.new("RGBA", (S, S))
gd = ImageDraw.Draw(grad)
for y in range(S):
    t = y / (S - 1)
    gd.line([(0, y), (S, y)], fill=tuple(round(a + (b - a) * t) for a, b in zip(BG_TOP, BG_BOTTOM)) + (255,))

body = Image.new("RGBA", (S, S), (0, 0, 0, 0))
body.paste(grad, (0, 0), mask)

# Drawing, centred on the body (nudged up a touch for optical balance).
x = (S - ink.width) // 2
y = (S - ink.height) // 2 - 8

# Glow behind the lens: brightest in the middle, fading out at its rim.
lx = x + (LENS[0] - bbox[0]) * scale
ly = y + (LENS[1] - bbox[1]) * scale
lr = LENS[2] * scale
glow_alpha = Image.new("L", (S, S), 0)
gd2 = ImageDraw.Draw(glow_alpha)
for i in range(int(lr), 0, -1):
    a = round(235 * (1 - (i / lr) ** 2.2))
    gd2.ellipse((lx - i, ly - i, lx + i, ly + i), fill=a)
glow_alpha = ImageChops.multiply(glow_alpha.filter(ImageFilter.GaussianBlur(lr * 0.12)), mask)
glow = Image.new("RGBA", (S, S), GLOW + (255,))
glow.putalpha(glow_alpha)
if USE_GLOW:
    body = Image.alpha_composite(body, glow)

layer = Image.new("RGBA", (S, S), (0, 0, 0, 0))
layer.paste(ink, (x, y), ink)
layer.putalpha(ImageChops.multiply(layer.getchannel("A"), mask))
body = Image.alpha_composite(body, layer)

# Hairline edge so the body reads on any background.
edge = Image.new("RGBA", (S, S), (0, 0, 0, 0))
ImageDraw.Draw(edge).rounded_rectangle((OFF, OFF, OFF + BODY - 1, OFF + BODY - 1), RADIUS,
                                       outline=EDGE, width=2)
body = Image.alpha_composite(body, edge)

# --- drop shadow --------------------------------------------------------------
shadow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
sm = Image.new("L", (S, S), 0)
ImageDraw.Draw(sm).rounded_rectangle((OFF, OFF + 12, OFF + BODY - 1, OFF + BODY - 1 + 12), RADIUS, fill=90)
shadow.putalpha(sm.filter(ImageFilter.GaussianBlur(22)))

icon = Image.alpha_composite(shadow, body)
icon.save(f"{out_dir}/AppIcon-1024.png")

# --- .icns with every size macOS asks for ------------------------------------
icon.save(f"{out_dir}/AppIcon.icns", sizes=[(16, 16), (32, 32), (64, 64), (128, 128), (256, 256), (512, 512), (1024, 1024)])
for s in (512, 128, 64, 32, 16):
    icon.resize((s, s), Image.LANCZOS).save(f"{out_dir}/AppIcon-{s}.png")
print("ok")
